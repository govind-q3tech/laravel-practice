<?php
function imageUrlTimThumb($path, $width = NULL, $height = NULL,$quality=NULL,$crop=NULL) {
 
   if(!$width && !$height) {
    $url = env('IMAGE_URL') . $path;
   } else {


    $url = url('/') . '/timthumb.php?src='. url('/') . env('IMAGE_URL') . $path;

    if(isset($width)) {
        $url .= '&w=' . $width; 
    }
    if(isset($height) && $height>0) {
        $url .= '&h=' .$height;
    }
    if(isset($crop))
    {
        $url .= "&zc=".$crop;
    }
    else
    {
        $url .= "&zc=3";
    }
    if(isset($quality))
    {
        '&q='.$quality.'&s=1';
    }
    else
    {
        $url .='&q=95&s=1';
    }
  }
  $url .='&ct=1';
 return $url;
}


function getCorridor($corridor = null){
    $projectCorridor = ['1'=> 'North Corridor', '2'=> 'South Corridor', '3'=> 'East Corridor', '4'=> 'West Corridor'];

    if($corridor == null){
        return $projectCorridor;
    }else{
        if(isset($projectCorridor[$corridor])){
            return $projectCorridor[$corridor];
        }else{
            return null;
        }
    }
}



function getSoil($id = null){
    $landSoil = ['35'=> 'A', '2'=> 'S', '36'=> 'M', '37'=> 'H1','38'=> 'H2', '39'=> 'E1', '40'=> 'E2', '41'=> 'P' ];

    if($id == null){
        return $landSoil;
    }else{
        if(isset($landSoil[$id])){
            return $landSoil[$id];
        }else{
            return null;
        }
    }
}


function getAcusting($id = null){
    $dataArr = ['22'=> '0', '23'=> 'CAT 1', '24'=> 'CAT 2', '25'=> 'CAT 3','26'=> 'CAT 4', '27'=> 'CAT 5'];

    if($id == null){
        return $dataArr;
    }else{
        if(isset($dataArr[$id])){
            return $dataArr[$id];
        }else{
            return null;
        }
    }
}


function getSplitLevel($id = null){
    $dataArr = ['1'=> 'Yes', '2'=> 'No'];

    if($id == null){
        return $dataArr;
    }else{
        if(isset($dataArr[$id])){
            return $dataArr[$id];
        }else{
            return null;
        }
    }
}


function getBuildDesign($id = null){
    $dataArr = ['1'=> 'Single Storey', '2'=> 'Double Storey'];

    if($id == null){
        return $dataArr;
    }else{
        if(isset($dataArr[$id])){
            return $dataArr[$id];
        }else{
            return null;
        }
    }
}

function getAspect($id = null){
    $dataArr = ['1'=> 'North', '2'=> 'East', '3'=> 'South', '4'=> 'West' ];

    if($id == null){
        return $dataArr;
    }else{
        if(isset($dataArr[$id])){
            return $dataArr[$id];
        }else{
            return null;
        }
    }
}


function getMaterBedroom($id = null){
    $dataArr = ['1'=> 'Front', '2'=> 'Middle', '3'=> 'Rear' ];

    if($id == null){
        return $dataArr;
    }else{
        if(isset($dataArr[$id])){
            return $dataArr[$id];
        }else{
            return null;
        }
    }
}


function getBuildCorridor($id = null){
    $dataArr = ['1'=> 'North Corridor', '2'=> 'East Corridor', '3'=> 'South Corridor', '4'=>'West Corridor', '5'=>'
    All Corridor' ];

    if($id == null){
        return $dataArr;
    }else{
        if(isset($dataArr[$id])){
            return $dataArr[$id];
        }else{
            return null;
        }
    }
}


function getAcoustic($id = null){
    $dataArr = ['22'=> '0', '23'=> 'CAT 1', '24'=> 'CAT 2', '25'=> 'CAT 3','26'=> 'CAT 4', '27'=> 'CAT 5'];

    if($id == null){
        return $dataArr;
    }else{
        if(isset($dataArr[$id])){
            return $dataArr[$id];
        }else{
            return null;
        }
    }
}


function getCities($id = null){
    $dataArr = ['1'=> 'Queensland', '2'=> 'New South Wales', '3'=> 'Victoria' ];

    if($id == null){
        return $dataArr;
    }else{
        if(isset($dataArr[$id])){
            return $dataArr[$id];
        }else{
            return null;
        }
    }
}


function getBalAllowance($id = null){
    $dataArr = ['29'=> '12.5', '30'=> '19', '31'=> '29', '32' => '40', '33'=>'FZ' ];

    if($id == null){
        return $dataArr;
    }else{
        if(isset($dataArr[$id])){
            return $dataArr[$id];
        }else{
            return null;
        }
    }

    
}

function createRange($landPrice = 0){
    $lowerPrice = floor(($landPrice/10000))*10000;
    $upperPrice = $lowerPrice + 10000;
    return config('get.CURRENCY_SIGN').number_format($lowerPrice,2).'-'.config('get.CURRENCY_SIGN').number_format($upperPrice,2);

}


function getProjectLot($lots){
    $projectArray['min_price'] = 0 ;
    $projectArray['max_price'] = 0 ;
    $projectArray['min_size'] = 0 ;
    $projectArray['max_size'] = 0 ;
    $projectArray['count'] = count($lots) ;
    foreach($lots as $lotValue){
        if($projectArray['min_price'] == 0 || $projectArray['min_price'] > $lotValue['price']){
            $projectArray['min_price'] = $lotValue['price'];
        }
        if($projectArray['max_price'] == 0 || $projectArray['max_price'] < $lotValue['price']){
            $projectArray['max_price'] = $lotValue['price'];
        }        

        if($projectArray['min_size'] == 0 || $projectArray['min_size'] > $lotValue['size']){
            $projectArray['min_size'] = $lotValue['size'];
        }
        if($projectArray['max_size'] == 0 || $projectArray['max_size'] < $lotValue['size']){
            $projectArray['max_size'] = $lotValue['size'];
        }
    }
    $projectArray['min_price'] =  floor(($projectArray['min_price']/10000))*10000;
    $projectArray['max_price'] =  floor(($projectArray['max_price']/10000))*10000 + 10000;
    return $projectArray;
}