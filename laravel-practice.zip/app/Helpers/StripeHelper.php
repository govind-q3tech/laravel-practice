<?php
namespace App\Helpers;

use App\Models\Record;
use Auth;
use DB;
use Illuminate\Database\Eloquent\Model;
use Request;
use \Stripe\Stripe;

class StripeHelper{

  public static function addCoupon($slug = "", $off = "", $title = "",$type = ""){
   Stripe::setApiKey(config('get.STRIPE_SECRET_KEY'));
    // Set proration date to this moment:
    // Refrence: https://stripe.com/docs/billing/subscriptions/discounts
   if($type==0){
     $coupon = \Stripe\Coupon::create([
      'duration' => 'once',
      'id' => $slug,
      'percent_off' => $off,
    //  'title' => $title,
    ]);
   }else{
    $coupon = \Stripe\Coupon::create([
    'duration' => 'once',
    'id' => $slug,
    'amount_off' => $off,
    "currency" => "gbp",
    ]);
   }
    
   


  }





}