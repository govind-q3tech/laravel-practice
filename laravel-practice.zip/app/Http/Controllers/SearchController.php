<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Advertisement;
use App\Models\BusinessCategory;
use App\Models\City;
use App\Models\Area;
use App\Models\HashTag;
use App\Models\Location;

class SearchController extends Controller
{

    public function autosuggestion(Request $req){

        $requestData = $req->all();
        $categories = BusinessCategory::where('title', 'like', '%'.$requestData['search'].'%')->limit(10)->get();
        $category = [];
        foreach($categories as $categoryData){
            $data['value'] = $categoryData['slug'];
            $data['label'] = $categoryData['title'];
            $category[] = $data;

        }
        echo json_encode($category);
    }

   
    public function index(Request $request)
    {
        try{
            $adsQuery = Advertisement::query();
            $adsQuery->with([
                'user',
                'advertisement_images', 
                'location.area' => function($q){
                    $q->select('id', 'title', 'city_id');
                }, 
                'location.area.city' => function($q){
                    $q->select('id', 'title');
                },
                'location.area.city' => function($q){
                    $q->select('id', 'title');
                },
                'sub_business_category' => function($q){
                    $q->select('id', 'title', 'parent_id');
                }, 
                'sub_business_category.parent' => function($q){
                    $q->select('id', 'title', 'icon');
                }
            ]);
            $activeCategory = [];
            if(isset($request->category))
            {
                if($request->category == 0){
                }else{
                    $activeCategory = BusinessCategory::where('id', $request->category)->status(1)->first();      
                }
                if($activeCategory){
                    $adsQuery->category($activeCategory->id);
                }
            }
            /*Front Filter*/
            if($request->keyword)
            {
                $hashtags = HashTag::where('title','like','%'.$request->keyword.'%')->pluck('id')->toArray();
                // dd($hashtags);
                if($hashtags){
                    $adsQuery->orWhereHas('advertisement_hashtags',function($q) use ($hashtags){
                        $q->whereIn('hashtag_id', $hashtags);
                });
                }
            }
            // dd($adsQuery->get(),'test');
            $adsQuery->frontfilter($request);
            $adsQuery->status(1);


            /*Total Ads count*/
            $totalAdsQuery = Advertisement::query();
            if(isset($request->category))
            {
                if($request->category != 0){
                    $totalAdsQuery->category($activeCategory->id);
                }
            }
            $totalAdvertisement = $totalAdsQuery->status(1)->count();
            

            // dd($adsQuery->toSql());
            $advertisements = $adsQuery->paginate(config('get.FRONT_PAGE_LIMIT'));
            // dd($advertisements);

            /*Total ads count*/

            if(isset($request->location)){
                if($request->l_all == 'allcity'){
                    $location = City::where('id', $request->location)->status(1)->first();
                    $filteredLocation = $location->title;
                }elseif($request->l_all == 'allarea'){
                    $location = Area::where('id', $request->location)->status(1)->first();
                    $filteredLocation = $location->title;
                }else{
                    $location = Location::where('id', $request->location)->status(1)->first();
                    $filteredLocation = $location->title;
                }
            }else{
                $filteredLocation = 'All Kenya';
            }
            
                    
            $title = "Search ads Global";
            if(!empty($activeCategory)){
                if(isset($request->keyword) && isset($request->category)){
                    $title = $activeCategory->title.' Search Keyword : '.$request->keyword;
                }else{
                    $title = $activeCategory->title.' Ads Search';
                }
            }else{
                if(isset($request->keyword)){
                    $title = 'Search Keyword : '.$request->keyword;
                }
            }

            $categories = BusinessCategory::where('parent_id','0')->with('children', function($q){
              $q->withCount(['advertisements' => function($q){
                        $q->status(1);
                    }]);
            })->withCount(['main_advertisements' => function($q){
                        $q->status(1);
                    }])->get();
            
            

            $cities = City::withCount(['advertisements' => function($q) use($activeCategory){
                        if(!empty($activeCategory)){
                            $q->where('business_category_id',$activeCategory->id);
                        }
                        $q->status(1);
                    }])->status(1)->get();
            // dd($cities);
            $cat_slug = '';
            if ($request->ajax()) {
                if($request->type == 'grid'){
                    $html = view('advertisements.gridview', compact('advertisements', 'categories', 'cat_slug', 'activeCategory'))->render();
                }else{
                    $html = view('advertisements.listview', compact('advertisements', 'categories', 'cat_slug', 'activeCategory'))->render();
                }
                return $html;
            }

            return view('search.index',compact('advertisements', 'cat_slug', 'categories', 'activeCategory', 'title', 'cities', 'filteredLocation', 'totalAdvertisement'));
        } catch (\Illuminate\Database\QueryException $e) {
            return redirect()->route('frontend.search.index')->withError($e->getMessage());
        }
    }


    

}
