<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\UserReview;

use Response;

class UserReviewController extends Controller
{
    //
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $requestedData = $request->all();
        $user_review = UserReview::create($requestedData);
        $data = ['status'=>true, 'data'=>$requestedData];

        return Response::json($data);
    }

        /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id)
    {
        try {
            $userReview = UserReview::findOrFail($id);
            $checkReview = UserReview::sortable(['created_at' => 'desc'])->with('listing')->whereHas('listing', function($q){
                $q->where('user_id',  auth()->user()->id);
            })->where('id', $id)->first();

            if(empty($checkReview)){
                return redirect()->route('reviews.index')->with('warning', 'You are not allow to access this location.');
            }
            $requestData = $request->all();
            $userReview->fill($requestData);
            $userReview->save();
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return back()->with('success', 'User Review has been updated successfully.');
    }


        /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {        
        $userreviews = UserReview::sortable(['created_at' => 'desc'])->with('listing')->whereHas('listing', function($q){
            $q->where('user_id',  auth()->user()->id);
        })->where('admin_approve',1)->paginate(config('get.FRONT_PAGE_LIMIT'));
        return view('userreviews.index', compact('userreviews'));
    }   

        /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id = null)
    {    
       
        $userreview = UserReview::where('id',$id)->with('listing')->whereHas('listing', function($q){
            $q->where('user_id',  auth()->user()->id);
        })->first();
       
        
        if(empty($userreview)){
            return redirect()->route('home')->with('error', 'you are not authorized to access it.');
        }
        
        return view('userreviews.show', compact('userreview'));
    }  

}
