<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class PaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('payments.index');
    }
    /**
     * 
     * Not in use test use
     * 
     */
    public function create(Request $request)
    {
        // dd($request->all());
        $PhoneNumber = $request->phone;
        $amount = $request->amount;
        $mpesa = new \Safaricom\Mpesa\Mpesa();
        // $ShortCode = env("MPESA_BUSINESS_SORT_CODE");
        // $CommandID = 'CustomerPayBillOnline';
        // $Amount = $amount;
        // $Msisdn = $PhoneNumber;
        // $BillRefNumber = '00001';
        // $b2bTransaction = $mpesa->c2b($ShortCode, $CommandID, $Amount, $Msisdn, $BillRefNumber);
        // dd($b2bTransaction);
        $BusinessShortCode = env("MPESA_BUSINESS_SORT_CODE");
        $LipaNaMpesaPasskey = env("MPESA_PASS_KEY");
        $TransactionType = 'CustomerPayBillOnline';
        $Amount = $amount;
        $PartyA = $PhoneNumber;
        $PartyB = '174379';
        $PhoneNumber = $PhoneNumber;
        $CallBackURL = route('callback.payment');
        // $CallBackURL = 'https://gitau.24livehost.com/public/payment-callback';
        $AccountReference = 'Subscription Payment';
        $TransactionDesc = 'lipa Na M-PESA';
        $Remarks = '';
        // dd($CallBackURL);

        $stkPushSimulation = $mpesa->STKPushSimulation(
            $BusinessShortCode,
            $LipaNaMpesaPasskey,
            $TransactionType,
            $Amount,
            $PartyA,
            $PartyB,
            $PhoneNumber,
            $CallBackURL,
            $AccountReference,
            $TransactionDesc,
            $Remarks
        );
        $stkPushSimulation = json_decode($stkPushSimulation);
        dump($stkPushSimulation);
        if (!empty($stkPushSimulation) && $stkPushSimulation->ResponseCode == 0) {
            $checkoutRequestID = $stkPushSimulation->CheckoutRequestID;
            $STKPushRequestStatus = $mpesa->STKPushQuery($checkoutRequestID, $BusinessShortCode, $LipaNaMpesaPasskey);
            dd($STKPushRequestStatus);
        }
    }

    public function paymentCallback(Request $request)
    {
        Log::info(json_encode($request->all()));
    }
}
