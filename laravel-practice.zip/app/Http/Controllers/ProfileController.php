<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\ProfileRequest;
use App\Models\User;
use App\Models\Area;
use App\Models\Location;
use App\Models\City;
use DB, Auth, Validator, Session;

class ProfileController extends Controller
{

    /**
     * To handle the comming get 
     *
     * @return View
     */
    public function profile()
    {
        // dump(\URL::current());
        // dump(\URL::previous());
        // if (\URL::current() != \URL::previous()) {
        //     Session::forget('session_otp');
        //     Session::forget('mobile_number');
        //     Session::forget('OTPVerified');
        // }
        $user = Auth::user();
        $user = User::findOrFail($user->id);
        $cities = City::whereHas('areas')->where('country_id', 110)
            ->where('status', 1)
            ->pluck('title', 'id');
        if (old('city_id')) {
            $areas = Area::where('status', 1)->where('city_id', old('city_id'))
                ->pluck('title', 'id');
        } else {
            $areas = Area::where('status', 1)->where('city_id', $user->city_id)
                ->pluck('title', 'id');
        }
        if (old('area_id')) {
            $locations = Location::where('status', 1)->where('area_id', old('area_id'))
                ->pluck('title', 'id');
        } else {
            $locations = Location::where('status', 1)->where('area_id', $user->area_id)
                ->pluck('title', 'id');
        }


        return view('profile.index', compact('user', 'cities', 'locations', 'areas'));
    }

    /**
     * To handle the comming post request
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function updateProfile(ProfileRequest $request)
    {
        try {
            $user = Auth::user();
            $user = User::findOrFail($user->id);
            $requestData = $request->all();
            $is_email = 0;
            if ($user->email != $request->email) {
                $user->sendReverificationMail($request->all());
                $is_email = 1;
                $requestData['email_verified_at'] = null;
                $requestData['email_change'] = 1;
            }
            unset($requestData['_method']);
            unset($requestData['_token']);
            unset($requestData['is_verified']);
            DB::table('users')->where('id', $user->id)->update($requestData);
            Session::forget('session_otp');
            Session::forget('mobile_number');
            Session::forget('OTPVerified');
            if ($is_email) {
                Auth::guard('web')->logout();
                $request->session()->invalidate();
                $request->session()->regenerateToken();
                return redirect()->route('frontend.login')->with('success', 'User modified email need to verify and then log in.');
            }
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->with('error', $e->getMessage())->withInput();
        }

        return redirect()->route('frontend.profile.index')->with('success', 'Profile has been updated successfully.');
    }


    /**
     * To handle the comming post request
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function updateStoreInfo(Request $request)
    {
        if ($request->ajax()) {
            $target_url = route('frontend.dashboard');
            $request->validate([
                'store_name' => 'required|min:5|max:100|string',
                'description' => 'required|min:10|max:100|string',
            ]);
            $user = Auth::user();
            $user = User::findOrFail($user->id);
            $requestData = $request->all();
            $requestData['is_approved'] = 1;
            $user->fill($requestData);
            if ($user->save()) {
                $responce = ['status' => 'success', 'message' => 'Store detail has been updated successfully.', 'target_url' => $target_url];
            } else {
                $responce = ['status' => 'danger', 'message' => 'Store detail has not updated due to technical issue.', 'target_url' => $target_url];
            }
            return $responce;
        } else {
            try {
                $request->validate([
                    'store_name' => 'required|min:5|max:100|string',
                    'description' => 'required|min:10|max:100|string',
                ]);
                $user = Auth::user();
                $user = User::findOrFail($user->id);
                $requestData = $request->all();
                if ($user->is_approved != 1) {
                    $requestData['is_approved'] = 1;
                }
                $user->fill($requestData);
                $user->save();
            } catch (\Illuminate\Database\QueryException $e) {
                return back()->with('error', $e->getMessage())->withInput();
            }
            return redirect()->route('frontend.profile.index')->with('success', 'Store detail has been updated successfully.');
        }
    }


    /**
     * To handle the comming post request
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function saveImageUpload(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'profile_picture' => 'required|image|max:1000',
        ]);

        if ($validator->fails()) {
            return $validator->errors();
        }
        $status = "";
        if ($request->hasFile('profile_picture')) {
            $image = $request->file('profile_picture');
            // Rename image
            $filename = random_int(1000, 9999) . time() . '.' . $image->guessExtension();

            $path = $request->file('profile_picture')->storeAs(
                'public/profile_pictures',
                $filename
            );
            $user = Auth::user();
            $user = User::findOrFail($user->id);
            $requestData['profile_picture'] = $filename;
            $user->fill($requestData);
            $user->save();
            $status = "uploaded";
        }

        return response($status, 200);
    }

    /**
     * To handle the comming post request
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getArea(Request $request)
    {
        if ($request->ajax()) {
            $outrArr = [];
            $innerArr = [];
            // $innerArr[0] = 'Select Area';
            $innera[0]['id'] = '';
            $innera[0]['text'] = 'Select Area';
            $outrArr = $innera;
            if (!empty($request->city_id)) {
                $areas = Area::sortable(['title' => 'desc'])->has('location')->where(['status' => 1, 'city_id' => $request->city_id])->pluck('title', 'id')->toArray();
                if (!empty($areas)) {
                    foreach ($areas as $key => $name) {
                        $innerArr['id'] = $key;
                        $innerArr['text'] = $name;
                        $outrArr[] = $innerArr;
                    }
                }
            }
            return response($outrArr);
        }
    }

    /**
     * To handle the comming post request
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getLocation(Request $request)
    {
        if ($request->ajax()) {
            $outrArr = [];
            $innerArr = [];
            $innera[0]['id'] = '';
            $innera[0]['text'] = 'Select Location';
            $outrArr = $innera;
            if (!empty($request->area_id)) {
                $locations = Location::sortable(['title' => 'desc'])->where(['status' => 1, 'area_id' => $request->area_id])->pluck('title', 'id')->toArray();
                if (!empty($locations)) {
                    foreach ($locations as $key => $name) {
                        $innerArr['id'] = $key;
                        $innerArr['text'] = $name;
                        $outrArr[] = $innerArr;
                    }
                }
            }
            return response($outrArr);
        }
    }
}
