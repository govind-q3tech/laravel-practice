<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Location;
use App\Models\UkTown;
use DB;
class LocationsController extends Controller
{
    //

    public function deleteData(){

        set_time_limit(0);
        $locationRecord = Location::with('parent')->whereNull('slug')->get();
        $duplicated = DB::table('locations')
        ->select('title', DB::raw('count(`title`) as occurences'))
        ->groupBy(['title'])
        ->having('occurences', '>', 1)
        ->pluck(  'title')->toArray();
        
        
        foreach($locationRecord as $record) {
            
            if(isset($record->parent->title) && in_array($record->title, $duplicated)){
                $title = '-'.$record->parent->title;
            }else{
                $title = '';
            }
            $record->slug =  str_replace("'", "", $record->title.$title) ;

            $record->save();
        }

        /*
        $duplicated = DB::table('locations')
        ->select('*','title', DB::raw('count(`title`) as occurences'))
        ->groupBy(['title', 'parent_id'])
        ->having('occurences', '>', 1)
        ->get();

        foreach($duplicated as $record) {
            Location::where('id', $record->id)->delete();
        }
        */
    }

    public function autosuggestion(Request $req){

        $requestData = $req->all();
        $serachData = 0;
        if(isset($requestData['search'])){
            $serachData = $requestData['search'];
        }elseif(isset($requestData['term'])){
            $serachData = $requestData['term'];
        }
        $locations = Location::where('title', 'like', '%'. $serachData .'%')->status()->with('parent')->where('parent_id','>=', 0)->where('type','>',-1)->limit(24)->get();
        $location = [];
        foreach($locations as $locationData){
            $data['value'] = $locationData['slug'];
            $data['label'] = isset($locationData['parent']['title'])?$locationData['title']."(".$locationData['parent']['title'].")":$locationData['title'];
            $location[] = $data;

        }
        echo json_encode($location);
    }

    public function autosuggestlisting(Request $req){

        $requestData = $req->all();
        $serachData = 0;
        if(isset($requestData['search'])){
            $serachData = $requestData['search'];
        }elseif(isset($requestData['term'])){
            $serachData = $requestData['term'];
        }
        $locations = Location::where('title', 'like', '%'. $serachData .'%')->with('parent')->where('parent_id','>', 0)->where('type','>',-1)->get();
        $location = [];
        foreach($locations as $locationData){
            $data['value'] = $locationData['id'];
            $data['label'] = isset($locationData['parent']['title'])?$locationData['title']."(".$locationData['parent']['title'].")":$locationData['title'];
            $location[] = $data;

        }
        echo json_encode($location);
    }
    /*
    // country
    public function createLocation(){
        $ukTown = UkTown::groupBy('country')->get();
        
        $ukTownArr = [];
        foreach($ukTown as $key => $ukTownData){
            $ukTownArr[$key]['title']= $ukTownData['country'];
            $ukTownArr[$key]['parent_id']= -1;
            $ukTownArr[$key]['type']= 1;
            Location::create($ukTownArr[$key]);
        }
        
        dd($ukTownArr);
    }
    */
/*
    // county
    public function createLocation(){
        $ukTown = UkTown::groupBy('county')->get();
        $country = Location::where(["type" => 1])->pluck("id", "title");
        $ukTownArr = [];
        foreach($ukTown as $key => $ukTownData){
            if($ukTownData['county'] == '')
            continue;
            $ukTownArr[$key]['title']= $ukTownData['county'];
            $ukTownArr[$key]['parent_id']= 0;
            $ukTownArr[$key]['type']= 2;
            $ukTownArr[$key]['country_id']=  $country[$ukTownData['country']];
            Location::create($ukTownArr[$key]);
        }
        
       // dd($ukTownArr);
    }

    */

    /*
    public function createLocation(){
        $ukTown = UkTown::groupBy('county')->get();
        
        $ukTownArr = [];
        foreach($ukTown as $key => $ukTownData){
            $ukTownArr[$key]['title']= $ukTownData['county'];
            $ukTownArr[$key]['parent_id']= 0;
            Location::create($ukTownArr[$key]);
        }
        
        dd($ukTownArr);
    }


    
    public function createLocation(){
        $ukTown = UkTown::groupBy('county')->get();
        
        $ukTownArr = [];
        foreach($ukTown as $key => $ukTownData){
            $ukTownArr[$key]['title']= $ukTownData['county'];
            $ukTownArr[$key]['parent_id']= 0;
            Location::create($ukTownArr[$key]);
        }
        
        dd($ukTownArr);
    }

    */

/*
    // town and cities
    public function createLocation(){
        ini_set('max_execution_time', 0); //3 minutes
        $location = Location::where(["parent_id" => 0])->pluck("id", "title");
        $country = Location::where(["type" => 1])->pluck("id", "title");  
        $ukTown = UkTown::get();
        $ukTownArr = [];
        foreach($ukTown as $key => $ukTownData){
            if($ukTownData['county'] == '')
            continue;

            $ukTownArr[$key]['title']= $ukTownData['name'];
            if(!empty($ukTownData['postcode_sector'])){
                $postCode = explode(" ", $ukTownData['postcode_sector']);
                
                $ukTownArr[$key]['postcode']= $postCode[0];
            }
            if( $ukTownData['type'] ==  'City'){
                $ukTownArr[$key]['type']= 3;
            }else{
                $ukTownArr[$key]['type']= 4;
            }
            
            $ukTownArr[$key]['country_id']=  $country[$ukTownData['country']];
            $ukTownArr[$key]['lat']= $ukTownData['latitude'];
            $ukTownArr[$key]['lng']= $ukTownData['longitude'];
            $ukTownArr[$key]['parent_id']=  $location[$ukTownData['county']];


            Location::create($ukTownArr[$key]);
        }
        
        
    }
    */
    
    
    
    
}