<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Faq;

class FaqController extends Controller
{
    //
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   public function index(){
      $faqs = Faq::faqs()->orderBy('ordering', 'ASC')->get();
      // dd($faqs);
      return view('faq',compact('faqs'));
   }
}
