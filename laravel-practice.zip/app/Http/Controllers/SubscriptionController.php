<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\VerifiesEmails;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Support\Facades\Log;
use Illuminate\Auth\Events\Verified;
use App\Models\Membership\Plan;
use App\Models\User;
use App\Models\BusinessCategory;
use App\Models\Membership\Feature;
use App\Models\Membership\PlanFeature;
use App\Models\Membership\Transaction;
use App\Models\Membership\Subscription;
use App\Models\CategoryPlan;
use App\Rules\CheckPhone;
use Session;
use Auth;
use App\Models\Voucher;
use Carbon\Carbon;
use App\Models\EventNotification;
use Mail;


class SubscriptionController extends Controller
{
  /*
    |--------------------------------------------------------------------------
    | Email Verification Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling email verification for any
    | user that recently registered with the application. Emails may also
    | be re-sent if the user didn't receive the original email message.
    |
    */

  /**
   * Where to redirect users after verification.
   *
   * @var string
   */
  protected $redirectTo = "/subscription";

  /**
   * Create a new controller instance.
   *
   * @return void
   */
  public function __construct()
  {
    // $this->middleware('auth');
    // $this->middleware('auth')->except('verify');
    // $this->middleware('signed')->only('verify');
    // $this->middleware('throttle:6,1')->only('verify', 'resend');
  }

  /**
   * Show the email verification notice.
   *
   * @param  \Illuminate\Http\Request  $request
   * 
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request)
  {
    $user_data  = $request->user();
    // dd($user_data);
    $slug = $request->slug;
    $categories = BusinessCategory::select('id', 'title', 'slug')->where('parent_id', '0')->whereHas('children')->status(1)->get();
    $business_category = BusinessCategory::where('slug', $slug)->first();
    if ($business_category) {
      $cat_id = $business_category->id;
      $plans = Plan::with(['business_category_plan' => function ($q) use ($cat_id) {
        $q->where('business_category_id', $cat_id);
      }, 'plan_features', 'plan_features.feature'])
        ->orderBy('ordering', 'ASC')->active()->get();
    } else {
      $business_category = $categories->first();
      $cat_id = $business_category->id;
      $plans = Plan::with(['business_category_plan' => function ($q) use ($cat_id) {
        $q->where('business_category_id', $cat_id);
      }, 'plan_features', 'plan_features.feature'])
        ->orderBy('ordering', 'ASC')->active()->get();
    }
    // dd($plans);
    return view('subscription.index', compact('plans', 'categories', 'user_data'));
  }

  public function payment(Request $request, $category, $slug, $month)
  {
    $plan_type = ['half-yearly', 'quaterly', 'one-month'];
    if (in_array($month, $plan_type)) {
      $business_category = BusinessCategory::where('slug', $category)->first();
      if ($business_category) {
        $cat_id = $business_category->id;
        $planDetail = Plan::with(['business_category_plan' => function ($q) use ($cat_id) {
          $q->where('business_category_id', $cat_id);
        }, 'plan_features', 'plan_features.feature'])
          ->where('slug', $slug)->first();

        if ($planDetail) {
          if ($planDetail->business_category_plan->count() > 0) {
            $plan_business_category = $planDetail->business_category_plan->first();
            if ($month == 'half-yearly') {
              $plan_price = ($plan_business_category) ? $plan_business_category->pivot->half_yearly_price : '0.00';
            } elseif ($month == 'quaterly') {
              $plan_price = ($plan_business_category) ? $plan_business_category->pivot->quaterly_price : '0.00';
            } else {
              $plan_price = ($plan_business_category) ? $plan_business_category->pivot->monthly_price : '0.00';
            }
          }
          if ($plan_price != 0) {
            return view('subscription.payment', compact('planDetail', 'month', 'business_category'));
          } else {
            if ($planDetail->business_category_plan->count() > 0) {
              $plan_business_category = $planDetail->business_category_plan->first();
              if ($month == 'half-yearly') {
                $plan_type = '6';
                $plan_price = ($plan_business_category) ? $plan_business_category->pivot->half_yearly_price : '0.00';
                $newDateTime = Carbon::now()->addMonths(6);
              } elseif ($month == 'quaterly') {
                $plan_type = '3';
                $plan_price = ($plan_business_category) ? $plan_business_category->pivot->quaterly_price : '0.00';
                $newDateTime = Carbon::now()->addMonths(3);
              } else {
                $plan_type = '1';
                $plan_price = ($plan_business_category) ? $plan_business_category->pivot->monthly_price : '0.00';
                $newDateTime = Carbon::now()->addMonths(1);
              }
            }
            $currentDateTime = Carbon::now();
            $activePlan = Subscription::where(["user_id" => $request->user()->id, "category_id" => $cat_id, 'plan_type' => $plan_type, 'status' => 1])->whereDate('end_date', '>=', $currentDateTime)->count();
            if ($activePlan == 0) {
              Subscription::where(["user_id" => $request->user()->id, "category_id" => $cat_id])->update(["status" => 0]);

              $planStatusOne = \App\Helpers\Helper::getActivePlan($cat_id, $planDetail->id, 1);
              $planStatusThree = \App\Helpers\Helper::getActivePlan($cat_id, $planDetail->id, 3);
              $planStatusSix = \App\Helpers\Helper::getActivePlan($cat_id, $planDetail->id, 6);

              $subscription = new Subscription();
              $subscription->user_id = $request->user()->id;
              $subscription->plan_id = $planDetail->id;
              $subscription->category_id = $cat_id;
              $subscription->amount = $plan_price;
              $subscription->plan_type = $plan_type;
              $subscription->start_date = $currentDateTime;
              $subscription->end_date = $newDateTime;
              $subscription->save();



              $notification_status = config('constants.NOTIFICATION_LIST');
              $event_notification_user = [
                'sender_id'     => $request->user()->id,
                'sender_type'   => 'U',
                'receiver_id'   => $request->user()->id,
                'receiver_type' => 'U',
                'advertisement_id' => 0,
                'events'        => ($planStatusOne['subscribe_status'] || $planStatusThree['subscribe_status'] || $planStatusSix['subscribe_status']) ? 'P' : 'O',
                'message'       => ($planStatusOne['subscribe_status'] || $planStatusThree['subscribe_status'] || $planStatusSix['subscribe_status']) ? $notification_status['P']['message'] : $notification_status['O']['message'],
                'is_read'       => 0,
              ];

              EventNotification::create($event_notification_user);
              //For sending mail to user//
              $hook = ($planStatusOne['subscribe_status'] || $planStatusThree['subscribe_status'] || $planStatusSix['subscribe_status']) ? "subscription_plan_updated" : "subscription_plan_purchased";
              $replacement['USER_NAME'] = $request->user()->first_name;
              $replacement['PLAN'] = $planDetail->title;
              $replacement['END_DATE'] = date('d-m-Y', strtotime($subscription->end_date));

              $data = ['template' => $hook, 'hooksVars' => $replacement];
              Mail::to($request->user()->email)->send(new \App\Mail\ManuMailer($data));
              // For sending mail to user//
              return redirect()->route('frontend.plan.history')->with('success', "Subscribed successfully");
            } else {
              return redirect()->back()->with('error', "Free plan already subscribed!");
            }
          }
        } else {
          return redirect()->route('frontend.subscription.plan')->with('error', "Subscribed plan not found!");
        }
      } else {
        return redirect()->route('frontend.subscription.plan')->with('error', "Subscribed plan not found!");
      }
    } else {
      return redirect()->route('frontend.subscription.plan')->with('error', "Subscribed plan not found!");
    }
  }


  public function subscribe(Request $request)
  {
    $request->validate([
      'phone' => ['required', 'numeric', 'min:10', new CheckPhone]
    ]);

    $user_data  = $request->user();

    $PhoneNumber = $request->phone;
    // echo "<pre>";
    // print_r($request->all());
    // die;
    $category_id = $request->category_id;
    $slot = $request->slot;
    $plan_data = Plan::with(['business_category_plan' => function ($query) use ($category_id) {
      $query->where('business_category_id', $category_id);
    }])->where("id", $request->plan_id)->where("status", 1)->first();
    // dd($user_data);
    if (!empty($plan_data)) {
      try {
        if ($plan_data->business_category_plan->count() > 0) {
          $plan_business_category = $plan_data->business_category_plan->first();
          $special_plan_price = '0.00';
          if ($slot == 'half-yearly') {
            if ($plan_business_category) {
              if ($plan_business_category->pivot->special_monthly_price != '0.00') {
                $plan_price = $plan_business_category->pivot->half_yearly_price;
                $special_plan_price = $plan_business_category->pivot->special_monthly_price;
              } else {
                $plan_price = $plan_business_category->pivot->half_yearly_price;
              }
            } else {
              $plan_price = '0.00';
            }
            $plan_type = '6';
            $newDateTime = Carbon::now()->addMonths(6);
          } elseif ($slot == 'quaterly') {
            if ($plan_business_category) {
              if ($plan_business_category->pivot->special_quaterly_price != '0.00') {
                $plan_price = $plan_business_category->pivot->quaterly_price;
                $special_plan_price = $plan_business_category->pivot->special_quaterly_price;
              } else {
                $plan_price = $plan_business_category->pivot->quaterly_price;
              }
            } else {
              $plan_price = '0.00';
            }
            $plan_type = '3';
            $newDateTime = Carbon::now()->addMonths(3);
          } else {
            if ($plan_business_category) {
              if ($plan_business_category->pivot->special_monthly_price != '0.00') {
                $plan_price = $plan_business_category->pivot->monthly_price;
                $special_plan_price = $plan_business_category->pivot->special_monthly_price;
              } else {
                $plan_price = $plan_business_category->pivot->monthly_price;
              }
            } else {
              $plan_price = '0.00';
            }
            $plan_type = '1';
            $newDateTime = Carbon::now()->addMonths(1);
          }
        }
        $currentDateTime = Carbon::now();
        // $activePlan = Subscription::where("user_id",$user_data->id)->whereDate('end_date', '>', $currentDateTime)->count();
        $activePlan = Subscription::where(["user_id" => $user_data->id, "category_id" => $category_id, 'status' => 1])->whereDate('end_date', '>=', $currentDateTime)->count();

        // dd($activePlan);

        // if ($activePlan > 0) {
        //   return redirect()->route('frontend.plan.history')->with('error', 'You have already subscribed plan.');
        // }
        // dd($plan_price);
        $sub_response = [];
        // if ($user_data->is_subscribed && !empty($user_data->subscription_id)) {
        if ($plan_price != 0) {

          $subscription_id = 'test';
          // Subscription::where("user_id", $user_data->id)->update(["status" => 0]);
        } else {


          $subscription_id  = 'free';
        }
        // dd($request->user()->id,$request->all());
        if (Subscription::where(['user_id' => auth()->user()->id, 'status' => 1, "category_id" => $request->category_id])->exists()) {
          Subscription::where(["user_id" => $request->user()->id, "category_id" => $category_id])->update(["status" => 0]);
        }
        $subscription = new Subscription();
        $subscription->user_id = $request->user()->id;
        $subscription->plan_id = $plan_data->id;
        $subscription->category_id = $category_id;
        if ($special_plan_price != '0.00') {
          $subscription->amount = $special_plan_price;
        } else {
          $subscription->amount = $plan_price;
        }
        $subscription->plan_type = $plan_type;
        if ($plan_price != 0) {
          $sub_response = $this->mPesa($plan_price, $PhoneNumber);
          $requestId = '';
          if (!empty($response['stkpushquery'])) {
            $stkPush = json_decode($response['stkpushquery']);
            $requestId = $stkPush->requestId;
          }
          $subscription->subscription_id = $requestId;
          $subscription->subscription_response = json_encode($sub_response);
          $subscription->start_date = $currentDateTime;
          $subscription->end_date = $newDateTime;
        } else {
          $subscription->start_date = $currentDateTime;
          $subscription->end_date = $newDateTime;
        }
        $subscription->save();

        $plans = Plan::find($plan_data->id);

        $notification_status = config('constants.NOTIFICATION_LIST');
        $event_notification_user = [
          'sender_id'     => $request->user()->id,
          'sender_type'   => 'U',
          'receiver_id'   => $user_data->id,
          'receiver_type' => 'U',
          'advertisement_id' => 0,
          'events'        => ($activePlan > 0) ? 'P' : 'O',
          'message'       => ($activePlan > 0) ? $notification_status['P']['message'] : $notification_status['O']['message'],
          'is_read'       => 0,
        ];

        EventNotification::create($event_notification_user);
        //For sending mail to user//
        $hook = ($activePlan > 0) ? "subscription_plan_updated" : "subscription_plan_purchased";
        $replacement['USER_NAME'] = $user_data->first_name;
        $replacement['PLAN'] = $plans->title;
        $replacement['END_DATE'] = date('d-m-Y', strtotime($subscription->end_date));

        $data = ['template' => $hook, 'hooksVars' => $replacement];
        Mail::to($user_data->email)->send(new \App\Mail\ManuMailer($data));
        // For sending mail to user//


        return redirect()->route('frontend.plan.history')->with('success', "Subscribed successfully");
      } catch (Exception $e) {
        return redirect($this->redirectTo)->with('error', $e->getError()->message);
      }
    } else {
      return $request->wantsJson() ? new Response('', 201) : redirect()->back()->with('error', 'Invalid request');
    }
    // return $request->wantsJson() ? new Response('', 201) : redirect($this->redirectTo)->with('error', 'Invalid plan');
  }

  private function mPesa($amount = 00, $PhoneNumber)
  {
    $response = [];
    if (env("MPESA_ENV") == 'sandbox') {
      $PhoneNumber = '254723288236';
      $amountR = 2.00;
    } else {
      $amountR = round($amount, 2);
    }
    if (floor($amountR) == $amountR) {
      $amount = (string)floor($amountR);
    }

    $mpesa = new \Safaricom\Mpesa\Mpesa();
    $BusinessShortCode = env("MPESA_BUSINESS_SORT_CODE");
    $LipaNaMpesaPasskey = env("MPESA_PASS_KEY");
    $TransactionType = 'CustomerPayBillOnline';
    $Amount = $amount;
    $PartyA = $PhoneNumber;
    $PartyB = '174379';
    $PhoneNumber = $PhoneNumber;
    $CallBackURL = route('callback.payment');
    // $CallBackURL = 'https://gitau.24livehost.com/public/payment-callback';
    $AccountReference = 'Subscription Payment';
    $TransactionDesc = 'lipa Na M-PESA';
    $Remarks = '';

    // $Msisdn = $PhoneNumber;
    // $BillRefNumber = '00001';
    // $b2bTransaction = $mpesa->c2b($BusinessShortCode, $TransactionType, $Amount, $Msisdn, $BillRefNumber);
    // $response['b2bTransaction'] = $b2bTransaction;

    $stkPushSimulation = $mpesa->STKPushSimulation(
      $BusinessShortCode,
      $LipaNaMpesaPasskey,
      $TransactionType,
      $Amount,
      $PartyA,
      $PartyB,
      $PhoneNumber,
      $CallBackURL,
      $AccountReference,
      $TransactionDesc,
      $Remarks
    );

    $response['stkpush'] = $stkPushSimulation;
    $stkPushSimulation = json_decode($stkPushSimulation);
    if (!empty($stkPushSimulation) && !isset($stkPushSimulation->errorCode)) {

      if (isset($stkPushSimulation->CheckoutRequestID)) {
        $checkoutRequestID = $stkPushSimulation->CheckoutRequestID;
        $timestamp = '20' . date("ymdhis");
        $password = base64_encode($BusinessShortCode . $LipaNaMpesaPasskey . $timestamp);
        $STKPushRequestStatus = $mpesa->STKPushQuery(env("MPESA_ENV"), $checkoutRequestID, $BusinessShortCode, $password, $timestamp);
        $response['stkpushquery'] = $STKPushRequestStatus;
      }
    }
    Log::info($response);

    return $response;
  }

  public function subscription_checkout($plan_id, Request $request)
  {

    $plan_data = Plan::with(['plan_stripe_plan'])->where("id", $request['plan_id'])->where("status", 1)->first();
    $planDuration = ['1' => 'Monthly', '2' => 'Yearly', "3" => "Quarerly", "4" => "Half Yearly"];
    $planDurationShort = ['1' => 'mo', '2' => 'yr', '3' => 'qtly', '4' => 'hlf'];

    if (!empty($plan_data)) {
      // to check the cost of new subscription
      $cost = 0;
      try {
        $user_data  = $request->user();
        if ($user_data->is_subscribed && !empty($user_data->subscription_id)) {
          \Stripe\Stripe::setApiKey(config('get.STRIPE_SECRET_KEY'));
          // Set proration date to this moment:
          $proration_date = time();
          $subscription = \Stripe\Subscription::retrieve($user_data->subscription_id);
          // See what the next invoice would look like with a price switch
          // and proration set:
          $items = [
            [
              'id' => $subscription->items->data[0]->id,
              'price' => $plan_data->plan_stripe_plan->plan_response_id, # Switch to new price
            ],
          ];
          $invoice = \Stripe\Invoice::upcoming([
            'customer' => $request->user()->stripe_customer_id,
            'subscription' => $user_data->subscription_id,
            'subscription_items' => $items,
            'subscription_proration_date' => $proration_date,
          ]);
          // Calculate the proration cost:
          // $cost = 0;
          $current_prorations = [];

          foreach ($invoice->lines->data as $line) {
            if ($line->period->start - $proration_date <= 1) {
              array_push($current_prorations, $line);
              $cost += $line->amount;
            }
          }
        }
      } catch (\Exception $e) {
        // echo "<pre>"; print_r($e->getError()); die;
      }

      // pending amount is coming in multiple of 100
      if (isset($cost)) {

        $cost = $cost / 100;
      }

      $stripe_publisher_key = config('get.STRIPE_PUBLISHER_KEY');
      $user_data  = $request->user();
      return view("subscription.checkout", compact("stripe_publisher_key", "plan_id", "plan_data", "planDuration", 'planDurationShort', "user_data", "cost"));
    } else {
      return $request->wantsJson() ? new Response('', 201) : redirect($this->redirectTo)->with('error', 'Invalid request');
    }
  }



  public function transaction_history(Request $request)
  {
    $records  = Subscription::with(["business_category", "plans", 'plans.plan_features', 'plans.plan_features.feature'])
      ->where("user_id", $request->user()->id)
      ->orderBy('created_at', 'DESC')
      ->paginate(config('get.ADMIN_PAGE_LIMIT'));
    // dd($records);
    return view("subscription.history", compact("records"));
  }

  public function cancel_subscription(Request $request)
  {
    $record  = Subscription::with(["plans"])->where("user_id", $request->user()->id)->where("id", $request['record_id'])->first();
    // echo "<pre>"; print_r($record); die;
    // Set your secret key. Remember to switch to your live secret key in production!
    // See your keys here: https://dashboard.stripe.com/account/apikeys
    \Stripe\Stripe::setApiKey(config('get.STRIPE_SECRET_KEY'));
    \Stripe\Subscription::update(
      $record->subscription_id,
      ['cancel_at_period_end' => true,]
    );
    $record->status = 0;
    $record->save();
    return redirect()->back()->with('success', "Subscription cancelled successfully");
  }
}
