<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PDF;

class CheckpdfController extends Controller
{
    
    /**
     * Index the form for creating a new resource.
     * @return Response
     */
    public function generatePDF(Request $request)
    {
        $data = ['title' => 'Welcome to ItSolutionStuff.com'];
        $pdf = PDF::loadView('pdf.index', $data);
        return $pdf->download('test.pdf');
    }
}
