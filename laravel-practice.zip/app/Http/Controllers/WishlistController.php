<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Models\Advertisement;
use Auth;

class WishlistController extends Controller
{
    
    /**
     * Index the form for creating a new resource.
     * @return Response
     */
    public function index(Request $request)
    {

        $user = Auth::user();

        $adsQuery = Advertisement::whereHas('user_wishlist', function($q) use($user){
            $q->where('user_id',$user->id);
        })->with([
            'advertisement_images',
            'location' => function($q){
                $q->select('id', 'title', 'area_id');
            }, 
            'location.area' => function($q){
                $q->select('id', 'title', 'city_id');
            }, 
            'location.area.city' => function($q){
                $q->select('id', 'title');
            },
            'location.area.city' => function($q){
                $q->select('id', 'title');
            },
            'sub_business_category' => function($q){
                $q->select('id', 'title', 'parent_id');
            }, 
            'sub_business_category.parent' => function($q){
                $q->select('id', 'title');
            }
        ]);

        $advertisements = $adsQuery->paginate(config('get.FRONT_PAGE_LIMIT'));
        // dd($advertisements);
        if ($request->ajax()) {
            $html = '';
            $html .= view('wishlist.list', compact('advertisements'))->render();
            return $html;
        }
        return view('wishlist.index', compact('advertisements'));
    }
}
