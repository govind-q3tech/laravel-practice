<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FavouritesController extends Controller
{
     /**
     * Index the form for creating a new resource.
     * @return Response
     */
    public function index()
    {  
        return view('favourites.index');
    }
}
