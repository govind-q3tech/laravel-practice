<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\VerifiesEmails;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Auth\Events\Verified;
use App\Models\Membership\Plan;
use App\Models\User;
use App\Models\Membership\Transaction;
use App\Models\Membership\Subscription;
use Session;
use App\Models\Listing;
use Mail;
class WebhookController extends Controller
{
  /*
  |--------------------------------------------------------------------------
  | Email Verification Controller
  |--------------------------------------------------------------------------
  |
  | This controller is responsible for handling email verification for any
  | user that recently registered with the application. Emails may also
  | be re-sent if the user didn't receive the original email message.
  |
  */

  /**
   * Where to redirect users after verification.
   *
   * @var string
   */
  protected $redirectTo = "/subscription";

  /**
   * Create a new controller instance.
   *
   * @return void 
   */
  public function __construct()
  {
  }

  public function webhook(Request $request)
  {
    
    // You can find your endpoint's secret in your webhook settings
    // $endpoint_secret = "whsec_GG1KNyT666PUJgtRN4awRMHkPXz1oVOL";
    $endpoint_secret = config('get.STRIPE_WEBHOOK_SIGNING_SECRET');

    $payload = @file_get_contents('php://input');
    $sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'];
    $event = null;

    try {
      $event = \Stripe\Webhook::constructEvent($payload, $sig_header, $endpoint_secret);
    } catch (\UnexpectedValueException $e) {
      // Invalid payload
      return response()->json([
        'message' => 'Invalid payload',
      ], 200);
    } catch (\Stripe\Exception\SignatureVerificationException $e) {
      // Invalid signature
      return response()->json([
        'message' => 'Invalid signature',
      ], 200);
    }
     
    
    if ($event->type == "invoice.payment_succeeded") {
      $intent = $event->data->object;
      $lines = $event->data->object->lines->data[0];
      $customer = $intent->customer; 
      $user_data = User::where("stripe_customer_id", $customer)->first();
    if (!empty($user_data)) {

        $transaction = new Transaction();
        $transaction->user_id = $user_data->id;
        $transaction->amount = sprintf('%.2f', $intent->amount_paid / 100);
        $transaction->transaction_id = $intent->id;
        $transaction->transaction_response = json_encode($intent);
        $transaction->type = "success";
      //  $transaction->transction_type = '1';
        if(isset($intent->subscription)){
          $transaction->subscription_id = $intent->subscription;  
        } 
       $transaction->save();
      //  $transaction->plans()->attach($user_data->plan_id);
        if(isset($intent->subscription)){
          Subscription::where("user_id",$user_data->id)->update(["status"=>0]);
          $subscription = new Subscription();
          $subscription->user_id = $user_data->id;
          $subscription->plan_id = $user_data->plan_id;
          $subscription->subscription_id = $intent->subscription;
          $subscription->subscription_response = json_encode($event);
          $subscription->start_date = $intent->period_start;
          $subscription->end_date = $intent->period_end;
          $subscription->save();

          // User Subscription cancel
          $user_data->is_subscribed = 1;
          $user_data->plan_id = $user_data->plan_id;
          $user_data->subscription_id = $intent->subscription;
          $user_data->save();
          // User Subscription cancel
        }

          //For sending invoice mail to user//
          $hook = "subscription_invoice"; 
          //$replacement['AMOUNT'] = $lines->amount;
          $replacement['AMOUNT'] =sprintf('%.2f', $intent->amount_paid / 100); 
          $replacement['DESCRIPTION'] = $lines->description;
          $replacement['PERIOD_START'] = date('d M Y H:i:s',$intent->period_start);
          $replacement['PERIOD_END'] = date('d M Y H:i:s',$intent->period_end);
          $replacement['TRANSACTION_ID'] = $intent->id;
          $replacement['SUBSCRIPTION_ID'] = $intent->subscription;
          $replacement['USER_NAME'] = $user_data->name;
          $replacement['USER_EMAIL'] = $user_data->email;
          $data = ['template' => $hook, 'hooksVars' => $replacement];
          Mail::to($user_data->email)->send(new \App\Mail\ManuMailer($data));
          // For sending invoce mail to user//

      }
      return response()->json([
        'intentId' => $intent->id,
        'message' => 'Payment succeded'
      ], 200);
    }elseif ($event->type == "invoice.payment_failed") {
      $intent = $event->data->object;
      $error_message = $intent->last_payment_error ? $intent->last_payment_error->message : "";
      $customer = $intent->customer;
      $user_data = User::where("stripe_customer_id", $customer)->first();
      if (!empty($user_data)) {
        $transaction = new Transaction();
        $transaction->user_id = $user_data->id;
        $transaction->amount = sprintf('%.2f', $intent->amount_paid / 100);
        $transaction->transaction_id = $intent->id;
        $transaction->transaction_response = json_encode($intent);
        $transaction->type = "failed";
        $transaction->transction_type = '1';
        $transaction->save();
        $transaction->plans()->attach($user_data->plan_id);
        // User Subscription cancel
        $user_data->is_subscribed = 0;
        $user_data->plan_id = NULL;
        $user_data->subscription_id = NULL;
        $user_data->save();
        // User Subscription cancel
        Subscription::where("user_id", $user_data->id)->update(["status" => 0]);
      }
      return response()->json([
        'intentId' => $intent->id,
        'message' => 'Payment failed: ' . $error_message
      ], 400);
    }elseif (($event->type == "customer.subscription.deleted")||($event->type == "subscription_schedule.canceled")||($event->type == "subscription_schedule.aborted")) {
      $intent = $event->data->object;
      $customer = $intent->customer;
      $user_data = User::where("stripe_customer_id", $customer)->first();
      if (!empty($user_data)) {
        // User Subscription cancel
        $user_data->is_subscribed = 1;
        $user_data->plan_id = 5;
        $user_data->subscription_id = NULL;
        $user_data->save();
        // User Subscription cancel
       Advertisement::where("user_id", $user_data->id)->update(["status" => 0]);
        Subscription::where("user_id", $user_data->id)->update(["status" => 0]);
        $free_subscription = Subscription::Create(['plan_id' => 5,'user_id' => $user_data->id,'start_date' => time(),'end_date' => NULL]);

      }
      return response()->json([
        'intentId' => $intent->id,
        'message' => 'Subscription Cancelled'
      ], 200);
    }

    /* Subscription Events
    * customer.subscription.created //Occurs whenever a customer is signed up for a new plan.
    * customer.subscription.deleted //Occurs whenever a customer's subscription ends.
    * customer.subscription.pending_update_applied //Occurs whenever a customer's subscription's pending update is applied, and the subscription is updated.
    * customer.subscription.pending_update_expired //Occurs whenever a customer's subscription's pending update expires before the related invoice is paid.
    * customer.subscription.trial_will_end //Occurs three days before a subscription's trial period is scheduled to end, or when a trial is ended immediately (using trial_end=now).
    * customer.subscription.updated //Occurs whenever a subscription changes (e.g., switching from one plan to another, or changing the status from trial to active).
    */
  }
}
