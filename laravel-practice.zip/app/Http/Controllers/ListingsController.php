<?php

namespace App\Http\Controllers;

use App\Helpers\Helper;
use Illuminate\Http\Request;
use App\Http\Requests\ListingRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
//Models
use App\Models\Listing;
use App\Models\Location;
use App\Models\Metatag;
use App\Models\User;
use App\Models\Category;
use App\Models\Service;
use App\Models\Opening;
use App\Models\Membership\PlanFeature;
use Auth;
use Illuminate\Support\Facades\App;

class ListingsController extends Controller
{

    /**
     *  Image upload path.
     *
     * @var string
     */
    protected $image_upload_path;

    /**
     * Storage Class Object.
     *
     * @var \Illuminate\Support\Facades\Storage
     */
    protected $storage;

    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->image_upload_path = 'listing/profile' . DIRECTORY_SEPARATOR;
        $this->storage = Storage::disk('public');
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //

        $listings = Listing::sortable(['created_at' => 'desc'])->with(array('categories' => function ($query) {
            $query->select('title');
        }))->where('user_id',auth()->user()->id )->paginate(config('get.FRONT_PAGE_LIMIT'));



        return view('listings.index', compact('listings'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {   
        $user = auth()->user();
        if(empty($user->plan_id)){
          return redirect()->route('user.subscription')->with('error', 'Please Upgrade  Your Subscription Plan to Add Listing ');  
        }


        $locations  = [];
        $categories = Category::status()/*->get()*/->pluck('title', 'id');
        $services = Service::status()/*->get()*/->pluck('title', 'id');
        $plan = \App\Models\Membership\Plan::with('plan_features')->where('id',auth()->user()->plan_id)->first();
        $planFeatures = [];
        if(isset($plan->plan_features)){
            foreach($plan->plan_features as $features){
                $planFeatures[$features->feature_id] = $features;
            }
        }
        /****Openings *******/
        
        $openingData = [];
        
        $days = \App\Helpers\Helper::getDays();

        /***Openings******/   
        
        $openingData = [];
        return view('listings.createOrUpdate', compact('locations', 'categories', 'openingData', 'days', 'services', 'planFeatures'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ListingRequest $request)
    {  
        $user = auth()->user();
        $listingsusedCount = Listing::where('status',1)->where('user_id',$user->id)->count();
        $maxlistingsno = PlanFeature::where('plan_id',$user->plan_id)->where('feature_id',2)->first()->value;
        if($maxlistingsno<=$listingsusedCount){
          return back()->with('error','You have reached Your maximum limit of listing Please Upgrade Your Plan to add new listing');
        }
        
        try {
            $requestData = $request->all();
            $requestData['user_id'] = $user->id;
            $requestData['short_description'] = $requestData['title'] ;
            if ($request->hasFile('image')) {
                $image_name = $this->uploadImage(null, $request->file('image'));
                $requestData['image'] = $image_name;
            }
            
            $listing = Listing::create($requestData);
            // add gallery Data

            app('App\Http\Controllers\GalleriesController')->uploadData($request, $listing->id);
            $listing->locations()->sync($requestData['locations']);
            $listing->categories()->sync($requestData['categories']);
    //        $listing->services()->sync($requestData['services']);            
            $openings = [];
            foreach($requestData['openings'] as $opening){
                $opening['status'] = 1;
                $openings[] = new  Opening($opening);
            }
            $listing->openings()->saveMany($openings);
        } catch (\Illuminate\Database\QueryException $e) {
           // dd($e->getMessage());
            return back()->withError($e->getMessage())->withInput();
        }
        // check users first listing just after registration
        if(\App\Helpers\Helper::checkFirstPost() ){
            return redirect()->route('user.subscribe', Auth::user()->plan_id)->with('success', 'Listing has been saved successfully');
        }else{
            return redirect()->route('listings.index')->with('success', 'Listing has been saved successfully');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $listing = Listing::with('locations')->findOrFail($id);
        
        if($listing->user_id != auth()->user()->id){
            return redirect()->route('listings.index')->with('error', 'you are not authorized to access it.');
        }
        $locations  =$listing->locations->pluck('title','id');
        $categories = Category::status()/*->get()*/->pluck('title', 'id');
        $services = Service::status()/*->get()*/->pluck('title', 'id');

        /****Openings *******/
        $openings = Opening::where('listing_id',$id)->get();
        $openingData = [];
        foreach($openings as $opening){
            $openingData[$opening->day] = $opening;
        }
        
        $days = \App\Helpers\Helper::getDays();

        /***Openings******/

        // Plans
        $plan = \App\Models\Membership\Plan::with('plan_features')->where('id',auth()->user()->plan_id)->first();
        $planFeatures = [];
        if(isset($plan->plan_features)){
            foreach($plan->plan_features as $features){
                $planFeatures[$features->feature_id] = $features;
            }
        }

        
        return view('listings.createOrUpdate', compact('id', 'listing',  'locations', 'categories', 'openingData', 'days', 'services', 'planFeatures'));    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ListingRequest $request, $id)
    {   
        $user = auth()->user();
        $listingsusedCount = Listing::where('status',1)->where('user_id',$user->id)->count();
        $maxlistingsno = PlanFeature::where('plan_id',$user->plan_id)->where('feature_id',2)->first()->value;
       
        try {
            $listing = Listing::findOrFail($id);
           
            if($listing->user_id != auth()->user()->id){
                return redirect()->route('listings.index')->with('error', 'you are not authorized to access it.');
            }
            $requestData = $request->all();
                if($maxlistingsno<=$listingsusedCount){
                $requestData['status'] =  $listing->status;
                }else{
                $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;  
                }
            
            if ($request->hasFile('image')) {
                $image_name = $this->uploadImage($listing, $request->file('image'));
                $requestData['image'] = $image_name;
            }else{
                $requestData['image'] = $listing->image;
            }
            $listing->fill($requestData);
            $listing->save();
            
            $listing->locations()->sync($requestData['locations']);
            $listing->categories()->sync($requestData['categories']);

             // add gallery Data

             app('App\Http\Controllers\GalleriesController')->uploadData($request,$id);
         //   $listing->services()->sync($requestData['services']);
            
            $updates =  Opening :: where('listing_id',$listing->id);
            $updates->delete();
            $openings = [];
            foreach($requestData['openings'] as $opening){
                $opening['status'] = 1;
                $openings[] = new  Opening($opening);
            }
            $listing->openings()->saveMany($openings);

        } catch (\Illuminate\Database\QueryException $e) {
            
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('listings.index')->with('success', 'Listing has been updated successfully.');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /*
     * upload image
     */
    public function uploadImage($model = null, $image)
    {
        if ($model != null) {
            if ($model->image != null) {
                $this->removeBannerImage($model);
            }
        }

        $path = $this->image_upload_path;

        $image_name = time() . $image->getClientOriginalName();

        // dd($path);

        $this->storage->put($this->image_upload_path . $image_name, file_get_contents($image->getRealPath()));

        return $image_name;
    }

    /*
     * remove image
     */
    public function removeBannerImage($model)
    {
        $path = $this->image_upload_path;
        if ($this->storage->exists($path)) {
            $this->storage->delete($path . $model->image);
            return true;
        }

        throw new \Exception(trans('There is some error in processing this request.'));
    }
  
   public function location(Request $req, $location=null, $char = 'a'){
    
    $searchcategory ='';
    if(!empty($req->query('category'))){
        $searchcategory = $req->query('category');
    }

   $locationData = Location::where('slug', $location)->orwhere('postcode', $location)->status()->with('parent')->first();
   
    if(empty($locationData)){
        $category = $location;
        $categoryData = Category::where('slug', $category)->status()->first();
        if(empty($categoryData)){
        abort(404);
        }
        $searchLocaiton = '';
        $parentId = 0;
        $locationdata = Location::status();
        $char='a';
       
      if(!empty($req->query('s'))){
        $char = $req->query('s');
       }
        
        if(!empty($char)){
        $locationdata = $locationdata->where("title", "like", $char."%");

        }
        $locationValue = $locationdata->where('parent_id', '>',0)->with('parent')->get();  

        return view('listings.category', compact('locationValue', 'category', 'searchLocaiton', 'categoryData')); 
        
    }
    $categoryData = Category::status()->orderBy('title', 'asc');    
   if($searchcategory != ''){
       $categoryData = $categoryData->where("title", "like", "%$searchcategory%");
    }
    $categoryData = $categoryData->get();
    return view('listings.location', compact('categoryData', 'location','searchcategory', 'locationData'));  
   }


   public function allLocationold(Request $req){
    $searchLocaiton = '';
    $parentId = 0;
    if(!empty($req->query('locations'))){
        $searchLocaiton = $req->query('locations');
        $locationData = Location::where('slug', $searchLocaiton )->first();
        $parentId = $locationData->parent_id;
        if($locationData->parent_id == 0){
            $parentId =  $locationData->id;
        }
    }
 
    
    if($parentId != 0){
        $locationdata = Location::status()->where('id', $parentId)->orWhere('parent_id', $parentId)->get();
    }else{
        $locationdata = Location::status()->get();
    }    

    $locationValue = [];
    foreach($locationdata as $location){
        if($location->parent_id == -1){
            continue;
        }

        $parent = $location->parent_id != 0 ?$location->parent_id:  $location->id;
        
        $locationValue[$parent][$location->id]['title'] = $location->title;
        $locationValue[$parent][$location->id]['slug'] = $location->slug;
        $locationValue[$parent][$location->id]['parent_id'] = $location->parent_id;
        
    }

    // for postcode Searching
    $postcodes = Location::status()->groupBy('postcode')->orderBy("postcode", "ASC")->pluck("postcode", "postcode");
    
   
    return view('listings.all_location', compact('locationValue', 'postcodes'));  
   }



   public function allLocation(Request $req){

    $searchLocaiton = '';
    $parentId = 0;
    if(!empty($req->query('locations'))){
        $searchLocaiton = $req->query('locations');
       
       
    }
 
    
   
    $counties = Location::status()->where('type', 2);
    if($searchLocaiton != ''){
        $counties = $counties->where("title", "like", "%$searchLocaiton%");
    }
    $counties = $counties->orderBy("title", "ASC")->pluck("title", "slug");
    $cities = Location::status()->where('type', 3);
    if($searchLocaiton != ''){
        $cities = $cities->where("title", "like", "%$searchLocaiton%");
    }
    $cities = $cities->orderBy("title", "ASC")->pluck("title", "slug");
    
    // for postcode Searching
    $postcodes = Location::status();
    if($searchLocaiton != ''){
        $postcodes = $postcodes->where("postcode", "like", "%$searchLocaiton%");
    }
    $postcodes = $postcodes->groupBy('postcode')->orderBy("postcode", "ASC")->pluck("postcode", "postcode"); 
    
 
    return view('listings.all_location', compact('counties', 'postcodes', 'cities', 'searchLocaiton'));  
   }


   public function allTown(Request $req, $char = 'a'){

    
    $searchLocaiton = '';
    if(!empty($req->query('locations'))){
        $searchLocaiton = $req->query('locations');
    }    
    
    $towns = Location::status()->where('type', 4);
    if($searchLocaiton != ''){
        $towns = $towns->where("title", "like", "%$searchLocaiton%");
    }else{
        $towns = $towns->where("title", "like", $char."%");
    }

    $towns =  $towns->with('parent')->orderBy("title", "ASC")->get();
    
   
    return view('listings.all_towns', compact('char', 'towns', 'searchLocaiton'));  
   }

   



   public function category(Request $req, $category=null, $char ='a'){
  /*  $listings = Listing::with('user.sponsor','locations', 'categories')->whereHas('categories',function ($query)  use($category){
        $query->where('slug', $category);
    })->status()->paginate(config('get.FRONT_PAGE_LIMIT'));

    $metaTags = Category::where('slug', $category)->status()->first();
    return view('listings.category', compact('listings','metaTags'));   
*/
    $categoryData = Category::where('slug', $category)->status()->first();
    if(empty($categoryData)){
        abort(404);
    }
    $searchLocaiton = '';
    $parentId = 0;
    $locationdata = Location::status();
    if(!empty($req->query('locations'))){
        $searchLocaiton = $req->query('locations');
       $locationdata = $locationdata->where("title", "like", "%".$searchLocaiton."%");
        
    }
 
    
     
      
    if(!empty($char)){
            $locationdata = $locationdata->where("title", "like", $char."%");

    }
    $locationValue = $locationdata->where('parent_id', '>',0)->with('parent')->get();  
   
    
   
    return view('listings.category', compact('locationValue', 'category', 'searchLocaiton', 'categoryData'));  
   }

   public function search($location=null, $category=null){


      /*
    $listings = Listing::with('user.sponsor','locations', 'categories')->whereHas('locations',function ($query)  use($location){
        $query->where('slug', $location);
    })->whereHas('categories',function ($query)  use($category){
        $query->where('slug', $category);
    })->status()->paginate(config('get.FRONT_PAGE_LIMIT'));
    $categoryData = Category::where('slug', $category)->status()->first();
    $locationData = Location::where('slug', $location)->status()->first();
 
    $connected_cat = Category::status()->whereIn('id', explode(',', $categoryData->connected_cat))->pluck('title', 'slug')->toArray();
    $metaTags = Metatag::filter(['location_id'=>$locationData->id,'category_id' => $categoryData->id])->first();

    */

    $locationData = Location::where('slug', $location)->status()->first();
  
    if(empty($locationData)){
        abort(404);
    }
    $locationCount  = Location::where('title', $locationData->title)->count();
    
    if($locationCount > 1){
        $locationData = Location::where('slug', $location)->parent()->first();
        
        $locationString =  $locationData->title." ".(isset($locationData->parent->title)?$locationData->parent->title:'');
    }else{
        $locationString =  $locationData->title;
    }
    
    $searchData = $this->getListingData($location, $category);
    extract( $searchData);
   // dd($metaTags);
    $metaTitle = '';
    $metaDescription = '';
    if($categoryData->meta_title != ''){
        $metaTitle = str_replace("XXX", $locationString, $categoryData->meta_title );
    }
    
    if($categoryData->meta_description != ''){
        $metaDescription = str_replace("XXX", $locationString, $categoryData->meta_description );
    }
    return view('listings.listing', compact('listings', 'metaTags', 'connected_cat', 'location', 'categoryData', 'locationData', 'category', "metaDescription", "metaTitle", "locationString"));   
   }
   
    public function map_view($location=null, $category=null){
        $searchData = $this->getListingData($location, $category);
        extract( $searchData);
        $mapArr = [];
        foreach($listings as $listing){
            $map = [];
            $map[0] = $listing->title;
            $map[1] = $listing->location;
            $map[2] = route("listings.detail",array($listing->slug));
            $map[3] = $listing->lat;
            $map[4] = $listing->lng;
            $mapArr[] = $map;

        }
        return view('listings.map_view', compact('listings', 'metaTags', 'connected_cat', 'location', 'categoryData', 'locationData', 'category', 'mapArr'));   
    }

    private function getListingData($location=null, $category=null){

        
        $locationArr =  Location::where('slug', $location)->first();
        $categoryArr = Category::where('slug', $category)->status()->first();
        if(empty($locationArr)){
            // check postcode;
            $locations = Location::where('postcode', $location)->pluck( "id")->toArray();
        }elseif($locationArr->parent_id == 0 ){
            // in case if location is County get all towns
            $locations = Location::where('parent_id', $locationArr->id)->pluck( "id")->toArray();
         //   $locations[$locationArr->id] = $locationArr->slug;
                    }else{
            // in case of town
            $locations = [$locationArr->id];
        ///    $locationsid = [$locationArr->id];
        }

        if(empty($locations)){
            abort(404);
        }   
       
        if(empty($categoryArr)){
            abort(404);
        } 
        
        /*$return['listings'] = Listing::with('locations', 'categories','services')->whereHas('locations',function ($query)  use($locations){
            
            $query->whereIn('slug', $locations);
        })->whereHas('categories',function ($query)  use($category){
            $query->where('slug', $category);
        })->status()->orderBy('title','asc')->paginate(config('get.FRONT_PAGE_LIMIT'));*/
        
       /* $return['listings'] = [];*/
        $return['categoryData'] = $categoryArr;
        $return['locationData'] = $locationArr;


        
        $return['connected_cat'] = Category::status()->whereIn('id', explode(',', $return['categoryData']->connected_cat))->pluck('title', 'slug')->toArray();
        $return['metaTags']  = [] ;
        if(isset($return['locationData']->id))
        $return['metaTags']  = Metatag::filter(['location_id'=>$return['locationData']->id,'category_id' => $return['categoryData']->id])->first();
    
       $listing_location= DB::table('listing_location')->whereIn('location_id',$locations)->pluck('listing_id')->toArray();
     
        $listing_category= DB::table('category_listing')->where('category_id',$categoryArr->id)->pluck('listing_id')->toArray();
        

        $result = array_intersect($listing_location,$listing_category);

        $return['listings'] = Listing::with('user.sponsor','avgRating')->whereIn('id',$result)->orderBy('sort_order','desc')->paginate(config('get.FRONT_PAGE_LIMIT')); 

        return $return;
    }
    /**
     * Display the specified resource.
     *
     * @param  string  $slug
     * @return \Illuminate\Http\Response
     */
    public function detail($slug = null)
    {
        //
        $listing = Listing::with('user.sponsor','locations', 'categories', 'galleries', 'approveReview', 'avgRating', 'openings')->status()->slug($slug)->first();
        
        if(empty($listing)){
            abort(404);
            /*return redirect()->route('home')->with('error', 'you are not authorized to access it.');*/
        }
        
        \App\Helpers\Helper::saveRecord($listing->id, 1);
        return view('listings.show',compact('listing'));
    
    }

    /**
     * Display the specified resource.
     *
     * @param  Request  $req
     * @return \Illuminate\Http\Response
     */

    
    
    public function autosuggestion(Request $req){

        $requestData = $req->all();
        $listings = Listing::where('title', 'like', '%'.$requestData['search'].'%')->status()->get();
        $listing = [];
        foreach($listings as $listingData){
            $data['value'] = $listingData['slug'];
            $data['label'] = $listingData['title'];
            $listing[] = $data;

        }
        echo json_encode($listing);
    }
    


    
}