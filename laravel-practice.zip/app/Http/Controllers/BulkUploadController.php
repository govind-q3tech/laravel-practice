<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use App\Models\Advertisement;
use App\Models\AdvertisementImage;
use App\Models\BusinessCategory;
use App\Models\City;
use Storage, Auth;
use App\Models\Membership\Subscription;

class BulkUploadController extends Controller
{

    /**
     * index .
     *
     * @param  Request  $request
     *
     */
    public function index(Request $request)
    {
        //Check Active Plan
        $active_plan_categories =  Subscription::where(['user_id' => Auth::user()->id, 'status' => 1])
            ->whereDate('start_date', '<=', date("Y-m-d"))
            ->whereDate('end_date', '>=', date("Y-m-d"))
            // ->with('plans.plan_features')
            ->whereHas('plans.plan_features', function ($q) {
                $q->where(['plan_features.feature_id' => 5, 'plan_features.value' => 1]);
            })
            ->pluck('category_id')->toArray();
        // dd($active_plan_categories);
        $categories = BusinessCategory::whereIn('id', $active_plan_categories)->where('parent_id', '0')->whereHas('children')
            ->status(1)
            ->pluck('title', 'id');
        $cities = City::whereHas('areas.location')->where('country_id', 110)
            ->where('status', 1)
            ->pluck('title', 'id');
        $sub_categories = [];
        $areas = [];
        $locations = [];
        return view('bulkuplods.index', compact('categories', 'sub_categories', 'cities', 'areas', 'locations'));
    }

    /**
     * sote import CSV.
     *
     * @param  Request  $request
     *
     */
    public function store(Request $request)
    {
        DB::beginTransaction();
        try {

            $this->validate(
                request(),
                [
                    'file' => ['required', function ($attribute, $value, $fail) {
                        if (!in_array($value->getClientOriginalExtension(), ['csv'])) {
                            $fail('Incorrect :attribute type choose.');
                        }
                    }],
                    'business_category_id' => 'required',
                    'sub_business_category_id' => 'required',
                    'city_id' => 'required',
                    'area_id' => 'required',
                    'location_id' => 'required',
                ],
                [
                    'file.required' => 'You have to choose the file!',
                    'business_category_id.required' => 'The category field is required!',
                    'sub_business_category_id.required' => 'The sub category field is required!',
                    'city_id.required' => 'The city field is required!',
                    'area_id.required' => 'The area field is required!',
                    'location_id.required' => 'The location field is required!',
                ]
            );
            // dd($request->all());
            if ($request->hasFile('file')) {
                $uplaodfile = $request->file('file');
                // Rename image
                $filename = random_int(1000, 9999) . time() . '.' . $uplaodfile->getClientOriginalExtension();
                if (!Storage::exists('/public/csvfile')) {
                    Storage::makeDirectory('/public/csvfile', 0775, true); //creates directory
                }
                $path = $request->file('file')->storeAs(
                    'public/csvfile',
                    $filename
                );
                $fileUrl = asset('storage/csvfile/' . $filename);
                $filePath = Storage::path('/public/csvfile/' . $filename);

                $fileExists = Storage::disk('public')->exists('csvfile/' . $filename);
                $error = 0;
                if ($fileExists) {
                    if (($handle = fopen($filePath, "r")) !== FALSE) {
                        $row = 0;
                        $recored = 0;
                        $imageFirstKey = 0;
                        while (($data = fgetcsv($handle)) !== FALSE) {
                            $row++;
                            if ($row == 1) {
                                if (count($data) > 10) {
                                    $error = 1;
                                    break;
                                }
                                if (
                                    $data[0] == 'Title' &&
                                    $data[1] == 'Description' &&
                                    $data[2] == 'Price Type(Fixed = 1 or Range = 2)' &&
                                    $data[3] == 'Actual Price' &&
                                    $data[4] == 'Min Price' &&
                                    $data[5] == 'Max Price' &&
                                    $data[6] == 'Image 1 Path' &&
                                    $data[7] == 'Image 2 Path' &&
                                    $data[8] == 'Image 3 Path' &&
                                    $data[9] == 'Image 4 Path'
                                ) {
                                } else {
                                    $error = 1;
                                    break;
                                }
                            }

                            if ($row > 1) {
                                $recored++;
                                $advertisement = [];
                                $advertisement['user_id'] = auth()->user()->id;
                                $advertisement['business_category_id'] = $request->business_category_id;
                                $advertisement['sub_business_category_id'] = $request->sub_business_category_id;
                                $advertisement['city_id'] = $request->city_id;
                                $advertisement['area_id'] = $request->area_id;
                                $advertisement['location_id'] = $request->location_id;
                                // dd($data);
                                if (!empty($data[0])) {
                                    $advertisement['title'] = $data[0];
                                }
                                if (!empty($data[1])) {
                                    $advertisement['description'] = $data[1];
                                }
                                if (!empty($data[2])) {
                                    if ($data[2] == '1') {
                                        $advertisement['price_type'] = 2;
                                        if (!empty($data[3])) {
                                            $advertisement['fixed_price'] = $data[3];
                                        }
                                    } elseif ($data[2] == '2') {
                                        if (!empty($data[4]) || !empty($data[5])) {
                                            $advertisement['price_type'] = 1;
                                            $advertisement['min_price'] = $data[4];
                                            $advertisement['max_price'] = $data[5];
                                            $advertisement['fixed_price'] = $data[5];
                                        }
                                    }
                                }
                                $uploadedImages = [];
                                if (!empty($data[6])) {
                                    $imagePath6 = $data[6];
                                    if ($imageP6 = $this->storeImage($imagePath6)) {
                                        $uploadedImages[0] = $imageP6;
                                    }
                                }
                                if (!empty($data[7])) {
                                    $imagePath7 = $data[7];
                                    if ($imageP7 = $this->storeImage($imagePath7)) {
                                        $uploadedImages[1] = $imageP7;
                                    }
                                }
                                if (!empty($data[8])) {
                                    $imagePath8 = $data[8];
                                    if ($imageP8 = $this->storeImage($imagePath8)) {
                                        $uploadedImages[2] = $imageP8;
                                    }
                                }
                                if (!empty($data[9])) {
                                    $imagePath9 = $data[9];
                                    if ($imageP9 = $this->storeImage($imagePath9)) {
                                        $uploadedImages[3] = $imageP9;
                                    }
                                }
                                $advertisement['status'] = 0;
                                $advertisement = Advertisement::create($advertisement);

                                if (!empty($uploadedImages)) {
                                    $uploaded_images = $uploadedImages;
                                    $uploadedImagesObj = [];
                                    foreach ($uploaded_images as $imageKey => $imageValue) {
                                        $adImage = [];
                                        $adImage['image_name'] = (string)$imageValue;
                                        $adImage['main'] = $imageKey == 0 ? 1 : 0;
                                        $uploadedImagesObj[] = new AdvertisementImage($adImage);
                                    }
                                    if (!empty($uploadedImagesObj)) {
                                        $advertisement->advertisement_images()
                                            ->saveMany($uploadedImagesObj);
                                    }
                                }
                            }
                        }
                    }
                }
                if ($error == 1) {
                    return back()->with('error', 'Uploaded file format is invalid. please use sample format for reference!');
                }
                if ($recored == 0) {
                    return back()->with('error', 'Uploaded file is empty!');
                }
            }
            DB::commit();
            return redirect()->route('frontend.bulkupload.index')->with('success', $recored . ' Record has been imported successfully');
        } catch (\Illuminate\Database\QueryException $e) {
            DB::rollBack();
            return back()->with('error', $e->getMessage())->withInput();
        }
    }

    /**
     * Download image upload ads.
     *
     * @param  str  $url
     * @return filename
     */
    public function storeImage($url)
    {
        //The URL of the file that you want to download.
        $extension = pathinfo($url, PATHINFO_EXTENSION);
        //Download the file using file_get_contents.
        $downloadedFileContents = @file_get_contents($url);
        // dd($downloadedFileContents);
        //Check to see if file_get_contents failed.
        if ($downloadedFileContents === false) {
            return false;
            // throw new Exception('Failed to download file at: ' . $url);
        }

        $fileName = Str::random(20) . '.' . $extension;
        //The path and filename that you want to save the file to.
        $path = storage_path('app/public') . '/advertisements/';
        if (!Storage::exists('/public/advertisements')) {
            Storage::makeDirectory('/public/advertisements', 0777, true); //creates directory
        }

        //Save the data using file_put_contents.
        $storePath = $path . $fileName;
        $save = @file_put_contents($storePath, $downloadedFileContents);

        //Check to see if it failed to save or not.
        if ($save === false) {
            return false;
            // throw new Exception('Failed to save file to: ', $fileName);
        }
        return $fileName;
    }

    /**
     * Download sample csv file for upload ads.
     *
     * @param  []  $request
     * @return file download
     */
    public function sempleFile(Request $request)
    {
        header('Content-Type: application/excel');
        header('Content-Disposition: attachment; filename="sample-bulkupload.csv"');

        $second_row_1 = "Title,Description,Price Type(Fixed = 1 or Range = 2),Actual Price,Min Price,Max Price,Image 1 Path,Image 2 Path,Image 3 Path,Image 4 Path";
        $second_row_2 = '';
        $second_row_3 = '';
        $second_row_4 = '';
        $second_row_5 = '';
        $header_row = $second_row_1 . $second_row_2 . $second_row_3 . $second_row_4 . $second_row_5;

        $final_arr = array($header_row);
        $fp = fopen('php://output', 'rw');
        foreach ($final_arr as $line) {
            $val = explode(",", $line);
            fputcsv($fp, $val);
        }
        fclose($fp);
        die();
    }
}
