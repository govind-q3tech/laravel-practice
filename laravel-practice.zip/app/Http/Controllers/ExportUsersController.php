<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Rules\MatchOldPassword;
use App\Rules\CheckEmail;
use Illuminate\Contracts\Auth\StatefulGuard;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use App\Models\User;
use App\Models\BusinessCategory;
use App\Models\City;
use App\Models\Area;
use App\Models\Advertisement;
use DB, Auth, Validator, Session;
use Config;
use Carbon\Carbon;
use App\Models\AdvertisementImage;
use App\Models\AttributeBusinessCategory;
use App\Models\AdvertisementAttribute;
use App\Models\Attribute;
use Illuminate\Support\Facades\Storage;

class ExportUsersController extends Controller
{

    /**
     * The guard implementation.
     *
     * @var \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected $guard;

    /**
     * Create a new controller instance.
     *
     * @param  \Illuminate\Contracts\Auth\StatefulGuard  $guard
     * @return void
     */
    public function __construct(StatefulGuard $guard)
    {
        $this->guard = $guard;
    }
    /**
     * Create a new controller instance.
     *
     * @param  \Illuminate\Contracts\Auth\StatefulGuard  $guard
     * @return void
     */
    public function index(Request $request)
    {
        return view('pages.import');
    }
    /**
     * Export Users From Third Party
     *
     * @return void
     */
    public function importUsers(Request $request)
    {
        set_time_limit(30000);
        $apiUrl = Config::get('constants.WP_URL').Config::get('constants.WP_USER_API_URL');
        $resArr = $retResArr = array();
        try {
            $pageCount = 1;
            $data = array('role' => 'Subscriber', 'limit' => '50', 'page' => 1);

            $response = $this->getAPiData($apiUrl, $data);
            $resArr = json_decode($response);
            // echo "<pre>"; print_r($resArr); exit;
            if(isset($resArr) && !empty($resArr) > 0 && isset($resArr->data) && !empty($resArr->data))
            {
                $totalRecordCount = $resArr->totalPages;
                for ($pageCount = 1; $pageCount <= $totalRecordCount; $pageCount++) {
                    $retData = array('role' => 'Subscriber', 'limit' => '50', 'page' => $pageCount);
                    $retResponse = $this->getAPiData($apiUrl, $retData); // Loop According page
                    $retResArr = json_decode($retResponse);
                    foreach ($retResArr->data as $key => $value) 
                    {
                        $firstname = $value->first_name ?? '';
                        $lastName = $value->last_name ?? '';
                        $phone = $value->_rtcl_phone ?? '';
                        $description = $value->description ?? '';
                        $firstname = ($firstname!='') ? $firstname : $value->user_nicename; 
                        if($value->user_email!='')
                        {
                           $userExists = User::where('wp_id', $value->ID)->where('email', $value->user_email)->first();
                            if(!$userExists)
                            {   
                                /*create record*/
                                $user = DB::table('users')->insert([
                                    'wp_id' => $value->ID,
                                    'first_name' => $firstname,
                                    'last_name' => $lastName,
                                    'phone' => $phone,
                                    'email' => $value->user_email,
                                    'description' => $description,
                                    'status' => 1,
                                    'password' => Hash::make($value->user_pass),
                                    'created_at' => Carbon::now(),
                                    'updated_at' => Carbon::now(),
                                ]);

                            }  else {
                                /*Update record*/
                                $user = DB::table('users')->where('wp_id',$value->ID)->update([
                                    'wp_id' => $value->ID,
                                    'first_name' => $firstname,
                                    'last_name' => $lastName,
                                    'phone' => $phone,
                                    'description' => $description,
                                    //'email' => $value->user_email,
                                    'status' => 1,
                                    'updated_at' => Carbon::now(),
                                ]);
                            }  
                        }    
                                                 
                    }
                }
            }
        } catch (\Illuminate\Database\QueryException $e) {
            echo "<pre>";
            print_r($e->getMessage());
            exit;
        }
        echo 'Successfully import user list';
        exit;
    }

    /**
     * Export Users From Third Party
     *
     * @return void
     */
    public function importCatgeory(Request $request)
    {
        set_time_limit(30000);
        $apiUrl = Config::get('constants.WP_URL').Config::get('constants.WP_CATEGORY_API_URL');
        $resArr = $retResArr = array();
        try 
        {
            $pageCount = 1;
            $data = array( 'limit' => '50','page' => 1);
            $response = $this->getAPiData($apiUrl,$data);
            $resArr = json_decode($response);
            if(isset($resArr) && !empty($resArr) > 0 && isset($resArr->data) && !empty($resArr->data))
            {                
                $totalRecordCount = $resArr->total_page;
                for ($pageCount=1; $pageCount <= $totalRecordCount ; $pageCount++) 
                { 
                    $retData = array('limit' => '50','page' => $pageCount);
                    $retResponse = $this->getAPiData($apiUrl,$retData); // Loop According page
                    $retResArr = json_decode($retResponse);
                    foreach ($retResArr->data as $key => $value) 
                    {
                        if($value->title!='')
                        {
                            $title = $value->title ?? '';
                            $slug = $value->slug ?? '';
                            $description = $value->description ?? '';
                            $icon = 'cat-no-image.png';
                            /*Check FOr icon */                                
                            if($value->icon && !empty($value->icon))
                            {
                                $url = $value->icon;
                                $contents = file_get_contents($url);
                                $icon = $name = substr($url, strrpos($url, '/') + 1);
                                file_put_contents(public_path('icons/'.$name), $contents); 
                            } 
                            $categoryExists = BusinessCategory::where('wp_cat_id', $value->id)->where('slug', $value->slug)->first();

                            if(!$categoryExists)
                            {   
                                
                                /*create record*/
                                $category = DB::table('business_categories')->insertGetId([
                                    'wp_cat_id' => $value->id,'title' => $title,'slug' => $slug,
                                    'icon' => $icon,'parent_id' => $value->term_parent,'description' => $description,'status' => 1,'created_at' => Carbon::now(),'updated_at' => Carbon::now(),
                                ]);
                                /*For child insert in db  */
                                if($value->child && !empty($value->child) && count($value->child) > 0)
                                {
                                    foreach ($value->child as $key => $childValue) 
                                    {
                                        /*Check FOr icon */
                                        if($childValue->icon && !empty($childValue->icon))
                                        {
                                            $url = $childValue->icon;
                                            $contents = file_get_contents($url);
                                            $icon = $name = substr($url, strrpos($url, '/') + 1);
                                            file_put_contents(public_path('icons/'.$name), $contents); 
                                        } 
                                        /*create child record*/
                                        $childcategory = DB::table('business_categories')->insert([
                                            'wp_cat_id' => $childValue->id,'title' => $childValue->title,'slug' => $childValue->slug,
                                            'icon' => $icon,'parent_id' => $category,'wp_parent_id' => $childValue->term_parent,'description' => $childValue->desc,'status' => 1,'created_at' => Carbon::now(),'updated_at' => Carbon::now(),
                                        ]);
                                    }    
                                }
                                    

                            }  else {
                                /*Update record*/
                                $category = BusinessCategory::where('wp_cat_id',$value->id)->first();
                                if($category)
                                {
                                    $category->title = $title;
                                    $category->icon = $icon;
                                    $category->updated_at = Carbon::now();
                                    $category->description = $description;
                                    $category->save();   
                                }    
                                
                                /*For child insert in db  */
                                if($value->child && !empty($value->child) && count($value->child) > 0)
                                {
                                    foreach ($value->child as $key => $childValue) 
                                    {
                                        /*Check FOr icon */
                                        if($childValue->icon && !empty($childValue->icon))
                                        {
                                            $url = $childValue->icon;
                                            $contents = file_get_contents($url);
                                            $icon = $name = substr($url, strrpos($url, '/') + 1);
                                            file_put_contents(public_path('icons/'.$name), $contents); 
                                        } 
                                        /*create child record*/
                                        $childcategory = DB::table('business_categories')->where('wp_cat_id',$childValue->id)->update([
                                            'wp_cat_id' => $childValue->id,'title' => $childValue->title,'slug' => $childValue->slug,
                                            'icon' => $icon,'parent_id' => $category->id,'wp_parent_id' => $childValue->term_parent,'description' => $childValue->desc,'status' => 1,'created_at' => Carbon::now(),'updated_at' => Carbon::now(),
                                        ]);
                                    }    
                                }
                            }  
                        }    
                                                 
                    }
                    
                }
    
            }    
            
            
        } catch (\Illuminate\Database\QueryException $e) {
            echo "<pre>"; print_r($e->getMessage()); exit;
        }
        echo 'Successfully import category list'; exit;
    }
     /**
     * Export Users From Third Party
     *
     * @return void
     */
    public function importLocation(Request $request)
    {
        set_time_limit(30000);
        $apiUrl = Config::get('constants.WP_URL').Config::get('constants.WP_LOCATION_API_URL');
        $countryID = Config::get('constants.DEFAULT_COUNTRY');
        $resArr = $retResArr = array();
        try 
        {
            $pageCount = 1;
            $data = array( 'limit' => '500','page' => 1);
            $response = $this->getAPiData($apiUrl,$data);
            $resArr = json_decode($response);
            if(isset($resArr) && !empty($resArr) > 0 && isset($resArr->data) && !empty($resArr->data))
            {                
                $totalRecordCount = $resArr->total_page;
                for ($pageCount=1; $pageCount <= $totalRecordCount ; $pageCount++) 
                { 
                    $retData = array('limit' => '50','page' => $pageCount);
                    $retResponse = $this->getAPiData($apiUrl,$retData); // Loop According page
                    $retResArr = json_decode($retResponse);
                    foreach ($retResArr->data as $key => $value) 
                    {
                        if($value->title!='')
                        {
                            $title = $value->title ?? '';
                            $slug = $value->slug ?? '';                            
                            $cityExists = City::where('wp_id', $value->id)->where('slug', $value->slug)->first();

                            if(!$cityExists)
                            {  
                                
                                /*create record*/
                                $city = DB::table('cities')->insertGetId([
                                    'wp_id' => $value->id,'title' => $title,'slug' => $slug,'status' => 1,'country_id'=>0,'created_at' => Carbon::now(),'updated_at' => Carbon::now(),'country_id'=> $countryID
                                ]);
                                /*For child insert in db  */
                                if($value->child && !empty($value->child) && count($value->child) > 0)
                                {
                                    foreach ($value->child as $key => $childValue) 
                                    {                                       
                                        /*create child record*/
                                        $childcategory = DB::table('areas')->insert(['wp_area_id' => $childValue->id,
                                            'title' => $childValue->title,'slug' => $childValue->slug,'city_id' => $city,'wp_city_id' => $childValue->term_parent,'status' => 1,'created_at' => Carbon::now(),'updated_at' => Carbon::now(),
                                        ]);
                                    }    
                                }
                                    

                            }  else {
                                /*Update record*/
                                $city = City::where('wp_id',$value->id)->first();
                                if($city)
                                {
                                    $city->title = $title;
                                    $city->country_id = $countryID;
                                    $city->updated_at = Carbon::now();
                                    $city->save();   
                                }    
                                
                                /*For child insert in db  */
                                if($value->child && !empty($value->child) && count($value->child) > 0)
                                {
                                    foreach ($value->child as $key => $childValue) 
                                    {                                       
                                        /*create child record*/
                                        $childcity = DB::table('areas')->where('wp_area_id',$childValue->id)->update([
                                            'wp_area_id' => $childValue->id,'title' => $childValue->title,'slug' => $childValue->slug,'city_id' => $city->id,'wp_city_id' => $childValue->term_parent,'status' => 1,'created_at' => Carbon::now(),'updated_at' => Carbon::now(),
                                        ]);
                                    }    
                                }
                            }  
                        }    
                                                 
                    }
                    
                }
    
            }    
            
            
        } catch (\Illuminate\Database\QueryException $e) {
            echo "<pre>"; print_r($e->getMessage()); exit;
        }
        echo 'Successfully import location list'; exit;
    }
     /**
     * Export Users From Third Party
     *
     * @return void
     */
    public function importPost(Request $request)
    {
        set_time_limit(30000);
        $apiUrl = Config::get('constants.WP_URL').Config::get('constants.WP_POST_API_URL');
        $resArr = $retResArr = array();
        try 
        {
            $pageCount = 1;
            $data = array( 'limit' => '50','page' => 1);
            $response = $this->getAPiData($apiUrl,$data);
            $resArr = json_decode($response);
            // echo "<pre>"; print_r($resArr); exit; 

            if(isset($resArr) && !empty($resArr) > 0 && isset($resArr->data) && !empty($resArr->data))
            {                
                $totalRecordCount = $resArr->total_pages;
                for ($pageCount=1; $pageCount <= $totalRecordCount ; $pageCount++) 
                { 
                    $retData = array('limit' => '50','page' => $pageCount);
                    $retResponse = $this->getAPiData($apiUrl,$retData); // Loop According page
                    $retResArr = json_decode($retResponse);
                    foreach ($retResArr->data as $key => $value) 
                    {
                        if($value->title!='')
                        {
                            $title = $value->title ?? '';
                            $slugCreate = strtolower(preg_replace('/[^A-Za-z0-9-]+/', '-', $title));
                            $slug = ($value->slug!='') ? $value->slug : $slugCreate;                            
                            $description = $value->description ?? '';                            
                            $meta_description = $value->_yoast_wpseo_metadesc ?? '';                            
                            $meta_title = $value->_yoast_wpseo_title ?? '';                            
                            $meta_keywords = $value->_yoast_wpseo_focuskeywords ?? '';   
                            $max_price = $value->_rtcl_max_price ?? NULL;   
                            $min_price = $value->price ?? NULL;   
                            $fixed_price = $value->price ?? NULL; 
                            $price_type  = ($value->_rtcl_listing_pricing == "range") ? 1 : 2; 
                            $icon = 'cat-no-image.png';
                            $status = ($value->status == "publish") ? 1 : 0;

                            $category = (($value->category_id) && count($value->category_id) > 0) ? array_reverse($value->category_id) : [];
                            $location_id = (($value->location_id) && count($value->location_id) > 0) ? ($value->location_id) : [];
                            $listing_gallery = (($value->listing_gallery) && count($value->listing_gallery) > 0) ? ($value->listing_gallery) : [];
                            $extraCustomField = (($value->extra_custom_field) && count($value->extra_custom_field) > 0) ? ($value->extra_custom_field) : [];
                            $parentcat = 0;
                            $city = 0;
                            $area = 0;
                            $childCat = 0;
                            $userId = 0;
                            /*Get Category Id And subcategory ID*/
                            if($category && count($category) > 0)
                            {
                                $parentcat = BusinessCategory::where('wp_cat_id', $category[0])->select('id','wp_cat_id')->first();
                                $parentcat = @$parentcat->id;
                                if(isset($category[1]) && !empty($category[1]))
                                {
                                    $childCatRecord = BusinessCategory::where('wp_cat_id', $category[1])->select('id','wp_cat_id')->first();
                                    $childCat = @$childCatRecord->id; 
                                }    
                            }  
                            /*Get location Id And subcategory ID*/
                            if($location_id && count($location_id) > 0)
                            {
                                $city = City::where('wp_id', $location_id[0])->select('id','wp_id')->first();
                                $city = @$city->id;
                                if(isset($location_id[1]) && !empty($location_id[0]))
                                {
                                    $childCatRecord = Area::where('wp_area_id', $location_id[1])->select('id','wp_area_id')->first();
                                    $area = @$childCatRecord->id;
                                }    
                            }    
                            /*Get Category Id And subcategory ID*/
                            if($value->author_id && !empty($value->author_id))
                            {
                                $userData = User::where('wp_id', $value->author_id)->select('id','wp_id')->first();
                                $userId = @$userData->id;
                                  
                            } 
                            $advertisementExists = Advertisement::where('wp_post_id', $value->id)->first();
                            if(count($category) < 2 || count($location_id) < 2 )
                            {
                                $status = 0;
                            }    
                            if(!$advertisementExists)
                            {                                  
                                /*create record*/
                                $advertisements = DB::table('advertisements')->insertGetId([
                                    'wp_post_id' => $value->id,
                                    'title' => $title,
                                    'slug' => $slug,'status' => $status,
                                    'business_category_id'=>0,
                                    'sub_business_category_id'=>0,
                                    'created_at' => Carbon::now(),
                                    'updated_at' => Carbon::now(),
                                    'description'=> $description,
                                    'meta_description'=> $meta_description,
                                    'meta_title'=> $meta_title,
                                    'meta_keywords'=> $meta_keywords,
                                    'max_price'=> $max_price,
                                    'min_price'=> $min_price,
                                    'fixed_price'=> $fixed_price,
                                    'price_type'=> $price_type,
                                    'business_category_id'=> $parentcat,
                                    'sub_business_category_id'=> $childCat,
                                    'city_id'=> $city,
                                    'area_id'=> $area,
                                    'user_id'=> $userId ?? 0,
                                ]);
                                /*For child insert in db  */
                                if($listing_gallery && !empty($listing_gallery) && count($listing_gallery) > 0)
                                {   
                                    $uploadedImagesObj = [];
                                    foreach ($listing_gallery as $imageKey => $imageValue) 
                                    {                                       
                                        /*create gallery image  record*/
                                        if(!empty($imageValue))
                                        {   
                                            $handle = @fopen($imageValue, 'r');
                                            if($handle)
                                            {
                                                $adImage = [];
                                                $url = $imageValue;
                                                $icon = $name = substr($url, strrpos($url, '/') + 1);
                                                $adImage['image_name'] = (string) $name;
                                                $adImage['main'] = $imageKey == 0 ? 1 : 0;
                                                $adImage['advertisement_id'] = $advertisements;
                                                $adImage['created_at'] = Carbon::now();
                                                $adImage['updated_at'] = Carbon::now();
                                                $contents = file_get_contents($url);
                                                file_put_contents(storage_path('app/public'). '/advertisements/' . $name, $contents);
                                                // $uploadedImagesObj[] = new AdvertisementImage($adImage);   
                                                DB::table('advertisement_images')->insertGetId($adImage);  
                                            }    
                                              

                                        }    
                                                                               
                                             
                                    }  
                                     
                                }
                                if($extraCustomField && !empty($extraCustomField) && count($extraCustomField) > 0)
                                { 
                                    $this->postAttribute($extraCustomField,$parentcat,$advertisements);
                                }    
                                    

                            }  else {
                                /*Update record*/
                                $advertisements = Advertisement::where('wp_post_id',$value->id)->first();
                                if($advertisements)
                                {
                                    $advertisements->title = $title;
                                    $advertisements->description = $description;
                                    $advertisements->city_id = $city;
                                    $advertisements->area_id = $area;
                                    $advertisements->sub_business_category_id = $childCat;
                                    $advertisements->business_category_id = $parentcat;
                                    $advertisements->meta_description = $meta_description;
                                    $advertisements->meta_title = $meta_title;
                                    $advertisements->meta_keywords = $meta_keywords;
                                    $advertisements->max_price = $max_price;
                                    $advertisements->min_price = $min_price;
                                    $advertisements->fixed_price = $fixed_price;
                                    $advertisements->price_type = $price_type;
                                    $advertisements->user_id = $userId;
                                    $advertisements->status = $status;
                                    $advertisements->updated_at = Carbon::now();
                                    $advertisements->save();   
                                }    
                                
                                /*For listing_gallery in db  */
                                if($listing_gallery && !empty($listing_gallery) && count($listing_gallery) > 0)
                                {   
                                    $uploadedImagesObj = [];
                                    /*if($advertisements->advertisement_images->count() > 0){
                                         $advertisements->advertisement_images()->delete();
                                    }*/
                                    foreach ($listing_gallery as $imageKey => $imageValue) 
                                    {   

                                        if(!empty($imageValue))
                                        {                                     
                                            /*create gallery image  record*/
                                            $adImage = [];
                                            $url = $imageValue;
                                            $handle = @fopen($imageValue, 'r');
                                            $icon = $name = substr($url, strrpos($url, '/') + 1);
                                            $existsImage = AdvertisementImage::where('advertisement_id',$advertisements->id)->where('image_name',$name)->first();
                                            if(!$existsImage && $handle)
                                            {    
                                                $adImage['image_name'] = (string) $name;
                                                $adImage['main'] = $imageKey == 0 ? 1 : 0;
                                                $adImage['advertisement_id'] = $advertisements->id;
                                                $adImage['created_at'] = Carbon::now();
                                                $adImage['updated_at'] = Carbon::now();
                                                $contents = file_get_contents($url);
                                                file_put_contents(storage_path('app/public'). '/advertisements/' . $name, $contents);
                                                // $uploadedImagesObj[] = new AdvertisementImage($adImage);   
                                                DB::table('advertisement_images')->insertGetId($adImage);
                                            }    

                                        }                                       
                                             
                                    }  
                                     
                                }
                                if($extraCustomField && !empty($extraCustomField) && count($extraCustomField) > 0)
                                { 
                                        $this->postAttribute($extraCustomField,$parentcat,$advertisements->id);
                                }   
                            }  
                        }    
                                                 
                    }
                    
                }
    
            }    
            
            
        } catch (\Illuminate\Database\QueryException $e) {
            echo "<pre>"; print_r($e->getMessage()); exit;
        }
        echo 'Successfully import Post list'; exit;
    }

    public function postAttribute($extraCustomField,$parentcat=0,$advertisement_id)
    {
        foreach ($extraCustomField as $key => $value) 
        {
                $attributeExists = Attribute::where('name',$extraCustomField[$key]->label)->first();
                if(!$attributeExists)
                {
                    $requestData = [];
                    $requestData['status'] = 1;
                    $requestData['name'] = $extraCustomField[$key]->label;
                    $requestData['label'] = $extraCustomField[$key]->label;
                    $requestData['placeholder'] = $extraCustomField[$key]->label;
                    $requestData['type'] = 'text';
                    $requestData['status'] = 1;
                    $requestData['requried'] = 1;
                    $requestData['ordering'] = $key+1;
                    $saveattribute = Attribute::create($requestData);
                    if($saveattribute){
                        if(!empty($parentcat)){
                                $saveid= new AttributeBusinessCategory;
                                $saveid->attribute_id = $saveattribute->id;
                                $saveid->category_id = $parentcat;
                                $saveid->save();
                        }
                    }
                    if($saveattribute && isset($extraCustomField[$key]->value) && $extraCustomField[$key]->value!=''){
                        $attributeAttrExists = AdvertisementAttribute::where('advertisement_id',$advertisement_id)->where('attribute_id',$saveattribute->id)->first();
                        if(!empty($parentcat) && !$attributeAttrExists){
                                $saveid= new AdvertisementAttribute;
                                $saveid->advertisement_id = $advertisement_id;
                                $saveid->attribute_id = $saveattribute->id;
                                $saveid->value = $extraCustomField[$key]->value;
                                $saveid->save();
                        }
                    }
                }  else {
                    $attributeExists->name = $extraCustomField[$key]->label;
                    $attributeExists->label = $extraCustomField[$key]->label;
                    $attributeExists->placeholder = $extraCustomField[$key]->label;
                    $attributeExists->type = 'text';
                    $attributeExists->save();
                    if($attributeExists){
                        $attributeAttrExistsCat = AttributeBusinessCategory::where('category_id',$parentcat)->where('attribute_id',$attributeExists->id)->first();
                        if(!empty($parentcat) && !($attributeAttrExistsCat)){
                                $saveid= new AttributeBusinessCategory;
                                $saveid->attribute_id = $attributeExists->id;
                                $saveid->category_id = $parentcat;
                                $saveid->save();
                        }
                    }
                     if($attributeExists && isset($extraCustomField[$key]->value) && $extraCustomField[$key]->value!=''){
                        $attributeAttrExists = AdvertisementAttribute::where('advertisement_id',$advertisement_id)->where('attribute_id',$attributeExists->id)->first();
                        if(!empty($parentcat) && !$attributeAttrExists){
                                $saveid= new AdvertisementAttribute;
                                $saveid->advertisement_id = $advertisement_id;
                                $saveid->attribute_id = $attributeExists->id;
                                $saveid->value = $extraCustomField[$key]->value;
                                $saveid->save();
                        }
                    }
                }    
                
        }
    }
    /**
     * get Users From Third Party Using CURL
     *
     * @return void
     */
    public function getAPiData($url, $array = [])
    {
        $data = $array;
        $payload = json_encode($data);
        // Prepare new cURL resource
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        // Set HTTP Header for POST request 
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($payload))
        );

        // Submit the POST request
        $result = curl_exec($ch);
        // Close cURL session handle
        curl_close($ch);

        return $result;
    }
}
