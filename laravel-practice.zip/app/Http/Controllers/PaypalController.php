<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;

class PaypalController extends Controller
{
    /**
     * Creates a new product on stripe system
     * @param $planData
     * @return Response
     */
    public static function createProduct($planData)
    {
        /** Create A Stripe Product Work Start **/
        try {
            $stripe = new \Stripe\StripeClient( config('get.STRIPE_SECRET_KEY') );
            $stripe_product_array = [
                'name' => $planData->title,
                'description' => $planData->description,
            ];
            $product_response = $stripe->products->create($stripe_product_array);
            return ["status" => 1, "message" => "Success", "product_id" => $product_response->id, "response" => $product_response];
        } catch (Exception $e) {
            return ["status" => 0, "message" => $e->getError()->message];
        }
        /** Create A Stripe Product Work End **/
    }

    /**
     * Update the specified product on stripe system.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public static function updateProduct($planData,$product_id)
    {
        /** Update A Stripe Product Work Start **/
        try {
            $stripe = new \Stripe\StripeClient( config('get.STRIPE_SECRET_KEY') );
            $stripe_product_array = [
                'name' => $planData->title,
                'description' => $planData->description,
            ];
            $response = $stripe->products->update($product_id,$stripe_product_array);
            return ["status" => 1, "message" => "Success", "product_id" => $product_id , "response" => $response];
        } catch (Exception $e) {
            return ["status" => 0, "message" => $e->getError()->message];
        }
        /** Update A Stripe Product Work End **/
    }

    /**
     * Creates a new plan on stripe account
     * @param $planData
     * @return Response
     */
    public static function createPlan($planData,$product_id)
    {
        /** Create A Stripe Plan Work Start **/
        try {
            $stripe = new \Stripe\StripeClient( config('get.STRIPE_SECRET_KEY') );
            $plan_amount = $planData->amount;
            if(strpos($plan_amount,".")){ $plan_amount = str_replace(".","",$plan_amount);
            }else{ $plan_amount = $plan_amount."00"; }
            $stripe_plan_array = [
                'amount' => $plan_amount,
                'currency' => 'AUD',
                'interval' => ($planData->duration == 1) ? "month" : "year",
                'product' => $product_id,
            ];
            if(isset($planData->trial_days)){
                $stripe_plan_array['trial_period_days'] = $planData->trial_days;
            }else{
                unset($planData->trial_days);
            }
            $response = $stripe->plans->create($stripe_plan_array);
            return ["status" => 1, "message" => "Success", "plan_id" => $response->id, "response" => $response];
        } catch (Exception $e) {
            return ["status" => 0, "message" => $e->getError()->message];
        }
        /** Create A Stripe Plan Work End **/
    }

    /**
     * Remove the specified plan and product from stripe system
     * @param int $id
     * @return Response
     */
    public static function destroy($planData)
    {
        /** Stripe Plan Delete Work Start **/
        try{
            $stripe = new \Stripe\StripeClient(config('get.STRIPE_SECRET_KEY'));
            if($planData->plan_stripe_plan){
                $stripe->plans->delete(
                    $planData->plan_stripe_plan->plan_response_id,
                    []
                );
            }
            if($planData->plan_stripe_product){
                $stripe->products->delete(
                    $planData->plan_stripe_product->plan_response_id,
                    []
                );
            }
            return ['status' => 1,'message' => "Success"];
        } catch (Exception $e) {
            return ['status' => 0,'message' => $e->getError()->message];
        }
        /** Stripe Plan Delete Work End **/
    }
}
