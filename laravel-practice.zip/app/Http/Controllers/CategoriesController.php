<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Advertisement;
use App\Models\BusinessCategory;
use App\Models\City;
use App\Models\Area;
use App\Models\Location;

class CategoriesController extends Controller
{


    public function index(Request $request, $cat_slug = '')
    {
        $activeCategory = [];
        if (!empty($cat_slug)) {
            $activeCategory = BusinessCategory::where(['slug' => $cat_slug, 'parent_id' => 0])->status(1)->first();
            if (empty($activeCategory)) {
                $activeCategory = BusinessCategory::where(['slug' => $cat_slug])->status(1)->first();
            }
        }
        // if($activeCategory->parent){
        //     dd($activeCategory->parent->attributs);
        // }else{
        //     dd($activeCategory->attributs);
        // }
        // dd($request->attribute_options);
        if (!empty($activeCategory)) {
            $adsQuery = Advertisement::query();
            $adsQuery->with([
                'user',
                'advertisement_images',
                'city' => function ($q) {
                    $q->select('id', 'title');
                },
                'area' => function ($q) {
                    $q->select('id', 'title', 'city_id');
                },
                'location' => function ($q) {
                    $q->select('id', 'title');
                },
                'sub_business_category' => function ($q) {
                    $q->select('id', 'title', 'parent_id', 'color');
                },
                'sub_business_category.parent' => function ($q) {
                    $q->select('id', 'title', 'icon', 'color');
                }
            ]);
            if ($request->attribute_options) {
                $adsQuery->whereHas('advertisement_attributes', function ($q) use ($request) {
                    $q->whereIn('value', $request->attribute_options);
                });
            }
            /*Category Child and main category Filter*/
            if (!empty($activeCategory)) {
                if ($activeCategory->parent_id == 0) {
                    $adsQuery->where('business_category_id', $activeCategory->id);
                } else {
                    $adsQuery->where('business_category_id', $activeCategory->parent_id);
                    $adsQuery->where('sub_business_category_id', $activeCategory->id);
                }
            }

            /*Front Filter*/
            $adsQuery->frontfilter($request);

            /*Status Check*/
            $adsQuery->status(1);

            // dd($adsQuery->toSql());
            $advertisements = $adsQuery->paginate(config('get.FRONT_PAGE_LIMIT'));
            // echo "<pre>"; print_r($advertisements); exit; 
            // dd($advertisements);

            /*Total ads count*/
            //$totalAdvertisement = $adsQuery->count();
            /*Total Ads count*/
            $totalAdsQuery = Advertisement::query();
            if (!empty($activeCategory)) {
                if ($activeCategory->parent_id == 0) {
                    $totalAdsQuery->where('business_category_id', $activeCategory->id);
                } else {
                    $totalAdsQuery->where('sub_business_category_id', $activeCategory->id);
                }
            }
            $totalAdvertisement = $totalAdsQuery->status(1)->count();

            if (isset($request->location)) {
                if ($request->l_all == 'allcity') {
                    $location = City::where('id', $request->location)->status(1)->first();
                    $filteredLocation = $location->title;
                } elseif ($request->l_all == 'allarea') {
                    $location = Area::where('id', $request->location)->status(1)->first();
                    $filteredLocation = $location->title;
                } else {
                    $location = Location::where('id', $request->location)->status(1)->first();
                    $filteredLocation = $location->title;
                }
            } else {
                $filteredLocation = 'All Kenya';
            }


            if (!empty($activeCategory)) {
                $title = $activeCategory->title;
            } else {
                $title = 'Search Keyword : ' . $request->keyword;
            }

            $categories = BusinessCategory::where('parent_id', '0')->with('children', function ($q) {
                $q->withCount(['advertisements' => function ($q) {
                    $q->status(1);
                }]);
            })->withCount(['main_advertisements' => function ($q) {
                $q->status(1);
            }])->get();

            $cities = City::withCount(['advertisements' => function ($q) use ($activeCategory) {
                if (!empty($activeCategory)) {
                    if ($activeCategory->parent_id == 0) {
                        $q->where('business_category_id', $activeCategory->id);
                    } else {
                        $q->where('business_category_id', $activeCategory->parent_id);
                        $q->where('sub_business_category_id', $activeCategory->id);
                    }
                }
                $q->status(1);
            }])->status(1)->get();

            if (!empty($activeCategory)) {
                if ($activeCategory->parent_id == 0) {
                    $business_category_id = $activeCategory->id;
                } else {
                    $business_category_id = $activeCategory->parent_id;
                }
            }

            $attributes = \App\Helpers\Helper::getAttributes($business_category_id);
            //dd($attributes);
            if ($request->ajax()) {
                if ($request->type == 'grid') {
                    $html = view('advertisements.gridview', compact('advertisements', 'categories', 'cat_slug', 'activeCategory'))->render();
                } else {
                    $html = view('advertisements.listview', compact('advertisements', 'categories', 'cat_slug', 'activeCategory'))->render();
                }
                return $html;
            }

            return view('categories.index', compact('advertisements', 'cat_slug', 'categories', 'activeCategory', 'title', 'cities', 'filteredLocation', 'totalAdvertisement', 'attributes'));
        } else {
            return redirect()->route('frontend.home')->with('error', "Selected category not found.");
        }
    }

    /**
     * 
     * Show the getArea page data.
     *
     */

    public function getArea(Request $request)
    {
        if ($request->ajax()) {
            if ($request->type == 'city') {
                $type = 'area';
                $category = $request->category_id;
                $childcategory_id = $request->childcategory_id;
                /*Total Ads count*/
                $totalAdsQuery = Advertisement::query();
                if (!empty($category)) {
                    $totalAdsQuery->where('business_category_id', $category);
                }
                if (!empty($childcategory_id)) {
                    $totalAdsQuery->where('sub_business_category_id', $childcategory_id);
                }
                $totalAdvertisement = $totalAdsQuery->status(1)->count();
                $datas = City::withCount(['advertisements' => function ($q) use ($category, $childcategory_id) {
                    if (!empty($category)) {
                        $q->where('business_category_id', $category);
                    }
                    if (!empty($childcategory_id)) {
                        $q->where('sub_business_category_id', $childcategory_id);
                    }
                    $q->status(1);
                }])->status(1)->get();
                $response['status'] = true;
                $response['html'] = view('categories.modal', compact('datas', 'type'))->render();
                $response['title'] = '<b>All Kenya </b><span class="ads-ount">' . $totalAdvertisement . ' ads</span>';
            } elseif ($request->type == 'area') {
                $type = 'location';
                $allType = 'allcity';
                $category = $request->category_id;
                $childcategory_id = $request->childcategory_id;
                $currentSelected = City::withCount(['advertisements' => function ($q) use ($category, $childcategory_id) {
                    if (!empty($category)) {
                        $q->where('business_category_id', $category);
                    }
                    if (!empty($childcategory_id)) {
                        $q->where('sub_business_category_id', $childcategory_id);
                    }
                    $q->status(1);
                }])->where('id', $request->id)->status(1)->first();
                $response = [];
                if ($currentSelected) {
                    $datas = Area::withCount(['advertisements' => function ($q) use ($category, $childcategory_id) {
                        if (!empty($category)) {
                            $q->where('business_category_id', $category);
                        }
                        if (!empty($childcategory_id)) {
                            $q->where('sub_business_category_id', $childcategory_id);
                        }
                        $q->status(1);
                    }])->where('city_id', $request->id)->status(1)->get();
                    $response['status'] = true;
                    $response['html'] = view('categories.modal', compact('datas', 'type', 'currentSelected', 'allType'))->render();
                    $title = '<a href="javascript:void(0)" class="selectedLocation" data-id="' . $currentSelected->id . '" data-type="city">< Back</a>  ';
                    // $title .= $currentSelected->title.' '.$currentSelected->advertisements_count.' ads';
                    $response['title'] = $title;
                } else {
                    $response['status'] = false;
                }
            } elseif ($request->type == 'location') {
                $type = 'reload';
                $allType = 'allarea';
                $category = $request->category_id;
                $childcategory_id = $request->childcategory_id;
                $currentSelected = Area::withCount(['advertisements' => function ($q) use ($category, $childcategory_id) {
                    if (!empty($category)) {
                        $q->where('business_category_id', $category);
                    }
                    if (!empty($childcategory_id)) {
                        $q->where('sub_business_category_id', $childcategory_id);
                    }
                    $q->status(1);
                }])->where('id', $request->id)->status(1)->first();
                $response = [];
                if ($currentSelected) {
                    $datas = Location::withCount(['advertisements' => function ($q) use ($category, $childcategory_id) {
                        if (!empty($category)) {
                            $q->where('business_category_id', $category);
                        }
                        if (!empty($childcategory_id)) {
                            $q->where('sub_business_category_id', $childcategory_id);
                        }
                        $q->status(1);
                    }])->where('area_id', $request->id)->status(1)->get();
                    $response['status'] = true;
                    $response['html'] = view('categories.modal', compact('datas', 'type', 'currentSelected', 'allType'))->render();
                    $title = '<a href="javascript:void(0)" class="selectedLocation" data-id="' . $currentSelected->id . '" data-type="area">< Back</a>  ';
                    // $title .= $currentSelected->title.' '.$currentSelected->advertisements_count.' ads';
                    $response['title'] = $title;
                } else {
                    $response['status'] = false;
                }
            }
            return response($response);
        }
    }

    /**
     * 
     * Show the searchLocation page data.
     *
     */

    public function searchLocation(Request $request)
    {
        if ($request->ajax()) {
            $response = [];
            $response['status'] = false;
            if ($request->type == 'city') {
                $type = 'area';
                $category = $request->category_id;
                $childcategory_id = $request->childcategory_id;
                $datas = City::withCount(['advertisements' => function ($q) use ($category, $childcategory_id) {
                    if (!empty($category)) {
                        $q->where('business_category_id', $category);
                    }
                    if (!empty($childcategory_id)) {
                        $q->where('sub_business_category_id', $childcategory_id);
                    }
                    $q->status(1);
                }])
                    ->Where('title', 'like', '%' . $request->keyword . '%')
                    ->status(1)->get();
                $response['status'] = true;
                $response['html'] = view('categories.modal', compact('datas', 'type'))->render();
            } elseif ($request->type == 'area') {
                $type = 'location';
                $allType = 'allcity';
                $category = $request->category_id;
                $childcategory_id = $request->childcategory_id;
                $currentSelected = City::withCount(['advertisements' => function ($q) use ($category, $childcategory_id) {
                    if (!empty($category)) {
                        $q->where('business_category_id', $category);
                    }
                    if (!empty($childcategory_id)) {
                        $q->where('sub_business_category_id', $childcategory_id);
                    }
                    $q->status(1);
                }])->where('id', $request->id)->status(1)->first();
                $datas = Area::withCount(['advertisements' => function ($q) use ($category, $childcategory_id) {
                    if (!empty($category)) {
                        $q->where('business_category_id', $category);
                    }
                    if (!empty($childcategory_id)) {
                        $q->where('sub_business_category_id', $childcategory_id);
                    }
                    $q->status(1);
                }])
                    ->where('city_id', $request->id)
                    ->Where('title', 'like', '%' . $request->keyword . '%')
                    ->status(1)->get();
                $response['status'] = true;
                $response['html'] = view('categories.modal', compact('datas', 'type', 'currentSelected', 'allType'))->render();
            } elseif ($request->type == 'location') {
                $type = 'reload';
                $allType = 'allarea';
                $category = $request->category_id;
                $childcategory_id = $request->childcategory_id;
                $currentSelected = Area::withCount(['advertisements' => function ($q) use ($category, $childcategory_id) {
                    if (!empty($category)) {
                        $q->where('business_category_id', $category);
                    }
                    if (!empty($childcategory_id)) {
                        $q->where('sub_business_category_id', $childcategory_id);
                    }
                    $q->status(1);
                }])->where('id', $request->id)->status(1)->first();
                $datas = Location::withCount(['advertisements' => function ($q) use ($category, $childcategory_id) {
                    if (!empty($category)) {
                        $q->where('business_category_id', $category);
                    }
                    if (!empty($childcategory_id)) {
                        $q->where('sub_business_category_id', $childcategory_id);
                    }
                    $q->status(1);
                }])
                    ->where('area_id', $request->id)
                    ->Where('title', 'like', '%' . $request->keyword . '%')
                    ->status(1)->get();
                $response['status'] = true;
                $response['html'] = view('categories.modal', compact('datas', 'type',  'currentSelected', 'allType'))->render();
            }
            return response($response);
        }
    }

    public function getSubCategory(Request $request)
    {
        if ($request->ajax()) {
            if (!empty($request->cat_id)) {
                $subCategories = BusinessCategory::sortable(['title' => 'desc'])->where(['status' => 1, 'parent_id' => $request->cat_id])->pluck('title', 'id')->toArray();
                $option = '<option value="">Select Sub Category</option>';
                if (!empty($subCategories)) {
                    foreach ($subCategories as $key => $title) {
                        $option .= '<option value="' . $key . '">' . $title . '</option>';
                    }
                }
            }
            return response($option);
        }
    }
}
