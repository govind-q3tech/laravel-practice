<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Models\UserReview;
use Gate,DB;

class UserReviewController extends Controller
{
   /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $response = Gate::inspect('reviews-index', "reviews");
        // if (!$response->allowed()) {
        //     return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        // }
        $user_reviews = UserReview::sortable(['created_at' => 'desc'])->with('user','advertisement')->paginate(config('get.ADMIN_PAGE_LIMIT'));
        
        return view('Admin.reviews.index', compact('user_reviews'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function show(UserReview $review)
    {
        // $response = Gate::inspect('user-index', "reviews");
        // if (!$response->allowed()) {
        //     return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        // }
        return view('Admin.reviews.show', compact('review'));
    }

   

    public function reviewApprove(Request $request, $id){
        
        DB::beginTransaction();
        try {
            $reviewData = UserReview::findOrFail($id);
            if($request->type == 'accepted'){
                $message = 'accepted';
                $reviewData->admin_approve = 1;
                $reviewData->status = 1;
            }else{
                $message = 'declined';
                $reviewData->status = 3;
                $reviewData->admin_approve = 0;
            }
            $reviewData->save();
            DB::commit();
            $responce = ['status' => true, 'message' => 'This review has been '.$message.' successfully.', 'data' => []];
        } catch (\Exception $e) {
            DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

}
