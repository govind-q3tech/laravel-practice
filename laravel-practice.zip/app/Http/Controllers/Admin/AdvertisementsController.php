<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\ListingRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
//Models
use App\Models\Advertisement;
use App\Models\Location;
use App\Models\User;
use App\Models\Category;
use App\Models\City;
use App\Models\Area;
use App\Models\BusinessCategory;
use App\Models\AdvertisementImage;
use App\Models\Membership\Subscription;
use App\Models\AdvertisementHashtag;
use Illuminate\Support\Str;
use Gate;
use App\Models\EventNotification;
use Mail;
use App\Traits\ApiGlobalFunctions;

class AdvertisementsController extends Controller
{

    use ApiGlobalFunctions;
         /**
     *  Image upload path.
     *
     * @var string
     */
    protected $image_upload_path;

    /**
     * Storage Class Object.
     *
     * @var \Illuminate\Support\Facades\Storage
     */
    protected $storage;

    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->image_upload_path = 'listing/profile' . DIRECTORY_SEPARATOR;
        $this->storage = Storage::disk('public');
    }



    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        
        $response = Gate::inspect('check-user', "advertisements-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }        
        //
        $advertisements = Advertisement::sortable(['created_at'=>'desc']);
        if($request->query('searchkeyword')){
            $advertisements = $advertisements->where('title', 'like', '%' . $request->query('searchkeyword') . '%');
        }
       
        if($request->query('keyword')==5){
            $currentdate=date('Y-m-d');
            $start_date = date("Y-m-d", strtotime($currentdate)) . ' 00:00:00';
            $end_date = date("Y-m-d", strtotime($currentdate)) . ' 23:59:59';
            $subscription =Subscription::where('end_date' ,'<=', $start_date)->where('end_date' ,'>=',$end_date)/*->get()*/->pluck('user_id')->toarray();
           
         $advertisements = $advertisements->whereIn('user_id',$subscription);
        }else{
          $advertisements = $advertisements->with('user')->filter($request->query('keyword'));   
        }
        if($request->keyword=='0')
        {
            $advertisements->orwhere('status',0);
        }
       $advertisements = $advertisements->paginate(config('get.ADMIN_PAGE_LIMIT')); 
       // dd($advertisements);
        return view('Admin.advertisements.index', compact('advertisements'));
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function featured(Request $request)
    {
        
        $response = Gate::inspect('check-user', "advertisements-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }        
        //
        $advertisements = Advertisement::sortable(['created_at'=>'desc']);
        if($request->query('searchkeyword')){
            $advertisements = $advertisements->where('title', 'like', '%' . $request->query('searchkeyword') . '%');
        }
       
        if($request->query('keyword')==5){
            $advertisements = $advertisements->whereIn('user_id',$subscription);
        }else{
          $advertisements = $advertisements->with('user')->filter($request->query('keyword'));   
        }
        $advertisements->whereIn('is_featured',[1,2]);
       $advertisements = $advertisements->paginate(config('get.ADMIN_PAGE_LIMIT')); 
       
        return view('Admin.advertisements.featured', compact('advertisements'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $response = Gate::inspect('check-user', "advertisements-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }        
        $users = User::select(
            DB::raw("CONCAT(name,' ',last_name,'(',email,')') AS full_name"),'id')->sortable(['full_name'=>'desc'])->pluck('full_name', 'id');
            $locations  = [];
            $categories = Category::status()/*->get()*/->pluck('title', 'id');
    
        return view('Admin.advertisements.createOrUpdate', compact('users', 'locations', 'categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ListingRequest $request)
    {
        $response = Gate::inspect('check-user', "advertisements-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }        
        try {
            $requestData = $request->all();
            $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
            $requestData['admin_approve'] = (isset($requestData['admin_approve'])) ? 1 : 0;
            $requestData['show_at_home'] = (isset($requestData['show_at_home'])) ? 1 : 0;
            $requestData['sponsored'] = (isset($requestData['sponsored'])) ? 1 : 0;
            if ($request->hasFile('image')) {
                $image_name = $this->uploadImage(null, $request->file('image'));
                $requestData['image'] = $image_name;
            }
            $advertisement = Advertisement::create($requestData);
            
            $advertisement->locations()->sync($requestData['locations']);
            $advertisement->categories()->sync($requestData['categories']);


        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.advertisements.index')->with('success', 'Advertisement has been saved successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function show(Advertisement $advertisement)
    {
       
        $response = Gate::inspect('check-user', "advertisements-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $advertisementData = Advertisement::with([
            'user',
            'advertisement_images', 
            'advertisement_attributes', 
            'advertisement_attributes.attribute',
            'location',
           
        ])->find($advertisement->id);

        // dd($advertisementData);
        return view('Admin.advertisements.show', compact('advertisement','advertisementData'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $response = Gate::inspect('check-user', "advertisements-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }        
        // $advertisement = Advertisement::findOrFail($id);
        $advertisement = Advertisement::with([
            'location',
            'business_category',
            'advertisement_images',
            'sub_business_category',
        ])->findOrFail($id);

        if($advertisement->status == 0)
        {
            return redirect()->route('admin.advertisements.index')->with('error', 'Advertisement is not editable.');
        }
        
        $auctionImages = [];
        if($advertisement->advertisement_images->count() > 0){
            foreach($advertisement->advertisement_images as $keyImage => $advertisement_image){
                $auctionImages[$keyImage]['Url'] = asset('storage/advertisements/' . $advertisement_image->image_name);
                $auctionImages[$keyImage]['Name'] = "Images ".$keyImage;
            }
        }
        // dd($auctionImages);
        
        // $cities = City::whereHas('areas.location')->where('country_id',110)->where('status',1)->pluck('title','id');
        $cities = City::whereHas('areas')->where('country_id',110)->where('status',1)->pluck('title','id');
        $areas = Area::where('status',1)->where('city_id',$advertisement->city_id)->pluck('title','id');
        $locations = Location::where('status', 1)->where('area_id', $advertisement->area_id);
        
        $locations = Location::where('status', 1)->where('area_id', $advertisement->area_id)
                ->pluck('title', 'id');

        // $categories = BusinessCategory::where('parent_id','0')->status(1)->pluck('title', 'id');
        $categories = BusinessCategory::where('parent_id','0')->whereHas('children')->status(1)->pluck('title', 'id');
        $sub_categories = BusinessCategory::where('parent_id',$advertisement->business_category_id)->status(1)->pluck('title', 'id');

        return view('Admin.advertisements.createOrUpdate', compact('advertisement', 'categories', 'sub_categories', 'auctionImages', 'cities','areas','locations'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id)
    {
        // dd($request,$id);

        $request->validate([
            'title'                     =>'required',
            'description'               =>'required',
            'business_category_id'      =>'required',
            'sub_business_category_id'  =>'required',
            'city_id'                   =>'required',
            'area_id'                   =>'required',
            'fixed_price'               => 'numeric',
            'hashtags'                  => 'required',
            // 'meta_title'                =>'required',
            // 'meta_keywords'             =>'required',
            // 'meta_description'          =>'required',
        ]);

        $response = Gate::inspect('check-user', "advertisements-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }        
        try {
            $advertisement = Advertisement::findOrFail($id);
            // dd($advertisement);
            $requestData = $request->all();

            // dd($request->file('uploaded_images'));
            if (!empty($request->uploaded_images)) {
                $uploadedImages = $this->uploadImage($request->uploaded_images);
                if(!empty($uploadedImages)){
                    if($advertisement->advertisement_images->count() > 0){
                        $advertisement->advertisement_images()->delete();
                    }
                    $uploadedImagesObj = [];
                    foreach($uploadedImages as $imageKey => $imageValue){
                        $adImage = [];
                        $adImage['image_name'] = (string) $imageValue;
                        $adImage['main'] = $imageKey == 0 ? 1 : 0;
                        $uploadedImagesObj[] = new AdvertisementImage($adImage);
                    }
                    if (!empty($uploadedImagesObj)) {
                        $advertisement->advertisement_images()->saveMany($uploadedImagesObj);
                    }
                }
            }

            // $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
            // $requestData['admin_approve'] = (isset($requestData['admin_approve'])) ? 1 : 0;
            // $requestData['show_at_home'] = (isset($requestData['show_at_home'])) ? 1 : 0;
            // $requestData['sponsored'] = (isset($requestData['sponsored'])) ? 1 : 0;
            
            // $advertisement->fill($requestData);
            $price_range = explode(';', $request->rangePrimary);
            // dd($price_range);
            $advertisement->title                       = $request->title;
            $advertisement->description                 = $request->description;
            $advertisement->business_category_id        = $request->business_category_id;
            $advertisement->sub_business_category_id    = $request->sub_business_category_id;
            $advertisement->city_id                     = $request->city_id;
            $advertisement->area_id                     = $request->area_id;
            $advertisement->price_type               = $request->radio_payment;
            if ($request->radio_payment == 1) {
                $priceRange = explode(";", $request->rangePrimary);
                $minPrice = $priceRange[0];
                $maxPrice = $priceRange[1];
                $advertisement->min_price   = $minPrice;
                $advertisement->max_price = $maxPrice;
                $advertisement->fixed_price = $maxPrice;
            } else {
                $advertisement->fixed_price = $request->fixed_price;
            }
            // $advertisement->min_price                   = $price_range[0];
            // $advertisement->max_price                   = $price_range[1];
            $advertisement->meta_title                  = !empty($request->meta_title)?$request->meta_title:'';
            $advertisement->meta_keywords               = !empty($request->meta_keywords)?$request->meta_keywords:'';
            $advertisement->meta_description            = !empty($request->meta_description)?$request->meta_description:'';

            $advertisement->save();
            
            if ($request->hashtags) {
                $advertisement->advertisement_hashtags()->delete();
                $hashtagsObj = [];
                foreach ($request->hashtags as $value) {
                    $hashtagsObj[] = new AdvertisementHashtag(['hashtag_id' => $value]);
                }
                if (!empty($hashtagsObj)) {
                    $advertisement->advertisement_hashtags()
                        ->saveMany($hashtagsObj);
                }
            }
            

        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.advertisements.index')->with('success', 'Advertisement has been updated successfully.');
    }

    public function uploadImage($iData = [])
    {
        $imageNames = [];
        foreach($iData as $imageData){
            // dd($imageData);
            $image = $imageData;  // your base64 encoded
            $image = str_replace('data:image/png;base64,', '', $image);
            $image = str_replace(' ', '+', $image);
            $imageName = Str::random(20).'.'.'png';
            \File::put(storage_path('app/public'). '/advertisements/' . $imageName, base64_decode($image));
            $imageNames[] = $imageName;
        }

        return $imageNames;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Advertisement $advertisement)
    {
        $response = Gate::inspect('check-user', "advertisements-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }  
            DB::beginTransaction();
            try {
                $advertisement->delete();
                DB::commit();
                $responce = ['status' => true, 'message' => 'This advertisement has been deleted successfully.', 'data' => $advertisement];
            } catch (\Exception $e) {
                DB::rollBack();
                $responce = ['status' => false, 'message' => $e->getMessage()];
            }
            return $responce;
    }

     /*
     * upload image
     */
    // public function uploadImage($model = null, $image)
    // {
    //     if($model != null) {
    //         if ($model->image != null) {
    //             $this->removeBannerImage($model);
    //         }
    //     }

    //     $path = $this->image_upload_path;

    //     $image_name = time() . $image->getClientOriginalName();

    //     // dd($path);

    //     $this->storage->put($this->image_upload_path . $image_name, file_get_contents($image->getRealPath()));

    //     return $image_name;
    // }

    /*
     * remove image
     */
    public function removeBannerImage($model)
    {
        $path = $this->image_upload_path;
        if ($this->storage->exists($path)) {
            $this->storage->delete($path . $model->image);
            return true;
        }

        throw new \Exception(trans('There is some error in processing this request.'));
    }

    public function listApprove(Request $request, $id)
    {
        $response = Gate::inspect('check-user', "advertisements-create");
        if (!$response->allowed()) {
            $responce = ['status' => false, 'message' => $response->message()];
        }
        DB::beginTransaction();
        try {
            $advertisementData = Advertisement::findOrFail($id);
            $notification_status = config('constants.NOTIFICATION_LIST');

            if($request->type == 'accepted'){
                $message = 'accepted';
                $advertisementData->admin_approve = 1;
                $advertisementData->status = 1;
                $advertisementData->is_publish = 1;

                $event_notification_user = [
                    'sender_id'     => 1,
                    'sender_type'   => 'A',
                    'receiver_id'   => $advertisementData->user_id,
                    'receiver_type' => 'U',
                    'advertisement_id' => $advertisementData->id,
                    'events'        => 'K',
                    'message'       => $notification_status['K']['message'],
                    'is_read'       => 0,
                ];

                EventNotification::create($event_notification_user);
                //For sending mail to user//
                $hook = "advertisement_accepted"; 
                $replacement['USER_NAME'] = $advertisementData->user->first_name;
                $replacement['AD_TITLE'] = $advertisementData->title;
                $data = ['template' => $hook, 'hooksVars' => $replacement];
                Mail::to($advertisementData->user->email)->send(new \App\Mail\ManuMailer($data));
                // For sending mail to user//

            }else{
                $message = 'declined';
                $advertisementData->status = 3;
                $advertisementData->admin_approve = 2;

                $event_notification_user = [
                    'sender_id'     => 1,
                    'sender_type'   => 'A',
                    'receiver_id'   => $advertisementData->user_id,
                    'receiver_type' => 'U',
                    'advertisement_id' => $advertisementData->id,
                    'events'        => 'L',
                    'message'       => $notification_status['L']['message'],
                    'is_read'       => 0,
                ];

                EventNotification::create($event_notification_user);
                //For sending mail to user//
                $hook = "advertisement_declined"; 
                $replacement['USER_NAME'] = $advertisementData->user->first_name;
                $replacement['AD_TITLE'] = $advertisementData->title;
                $data = ['template' => $hook, 'hooksVars' => $replacement];
                Mail::to($advertisementData->user->email)->send(new \App\Mail\ManuMailer($data));
                // For sending mail to user//
            }
            $advertisementData->save();
            DB::commit();
             $this->sendNotificationForAdvertisementStatus($advertisementData->user_id,$message,$advertisementData->id);
            $responce = ['status' => true, 'message' => 'This advertisement has been '.$message.' successfully.', 'data' => []];
        } catch (\Exception $e) {
            DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }


    public function listDeclined(Request $request, $id)
    {
        $response = Gate::inspect('check-user', "advertisements-create");
        if (!$response->allowed()) {
            $responce = ['status' => false, 'message' => $response->message()];
        }
        DB::beginTransaction();
        try {
            $advertisementData = Advertisement::findOrFail($id);
            $notification_status = config('constants.NOTIFICATION_LIST');

            $message = 'declined';
            $advertisementData->status = 3;
            $advertisementData->admin_approve = 2;
            $advertisementData->declined_reason = $request['reason'];

            $event_notification_user = [
                'sender_id'     => 1,
                'sender_type'   => 'A',
                'receiver_id'   => $advertisementData->user_id,
                'receiver_type' => 'U',
                'advertisement_id' => $advertisementData->id,
                'events'        => 'L',
                'message'       => $notification_status['L']['message'] . ' '.'The reason is '. $request['reason'] .'.',
                'is_read'       => 0,
            ];

            EventNotification::create($event_notification_user);
            //For sending mail to user//
            $hook = "advertisement_declined"; 
            $replacement['USER_NAME'] = $advertisementData->user->first_name;
            $replacement['AD_TITLE'] = $advertisementData->title;
            $replacement['REASON'] = $request['reason'];
            
            $data = ['template' => $hook, 'hooksVars' => $replacement];
            Mail::to($advertisementData->user->email)->send(new \App\Mail\ManuMailer($data));
            // For sending mail to user//
            
            $advertisementData->save();
            DB::commit();
            $this->sendNotificationForAdvertisementStatus($advertisementData->user_id,$message,$advertisementData->id);
            $responce = ['status' => true, 'message' => 'This advertisement has been '.$message.' successfully.', 'data' => []];
        } catch (\Exception $e) {
            DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }

        return response()->json($responce);

    }

    public function featuredApprove(Request $request){
        $response = Gate::inspect('check-user', "advertisements-create");
        if (!$response->allowed()) {
            $responce = ['status' => false, 'message' => $response->message()];
        }
        DB::beginTransaction();
        try {
            
            $advertisementData = Advertisement::findOrFail($request->id);
            if($request->type == "accepted"){
                $advertisementData->is_featured = 1;
                $message = 'This advertisement has been accepted as featured successfully.';
            }elseif($request->type == "removed"){
                $advertisementData->is_featured = 0;
                $message = 'This advertisement has been removed from featured successfully.';
            }else{
                $advertisementData->is_featured = 0;
                $message = 'This advertisement has been declined as featured successfully.';
            }
            $advertisementData->save();
            DB::commit();
            $responce = ['status' => true, 'message' => $message, 'data' => []];
        } catch (\Exception $e) {
            DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }
}
