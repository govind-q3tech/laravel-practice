<?php

namespace App\Http\Controllers\Admin\Membership;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Routing\Controller;
use App\Http\Requests\PlanRequest;
use App\Models\Membership\Plan;
use App\Models\Membership\Product;
use App\Models\Membership\Subscription;
use App\Models\Membership\Feature;
use App\Models\Membership\PlanFeature;
use App\Models\Voucher;
use App\Models\CategoryPlan;
use App\Models\BusinessCategory;
// use Modules\MembershipManager\Http\Controllers\StripeController as StripeController;
 
class PlanController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index(Request $request)
    {
        $plans = Plan::filter($request->query('keyword'))->sortable(["ordering" => "ASC"])->paginate(config('get.ADMIN_PAGE_LIMIT'));
        return view('Admin.plans.index', compact('plans'));
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create(Request $request)
    {
        $extsting = Plan::active()->count();
        if($extsting == 4){
             return redirect()->route('admin.plans.index')->withError('Maximum 4 active plans can be added.');
        }
        $categories= BusinessCategory::where('parent_id','0')->get();
        $features = Feature::status(1)->get();
        return view('Admin.plans.create', compact('features', 'categories'));
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(PlanRequest $request)
    {
        try {
            $requestData = $request->all();
            $status = (isset($requestData['status'])) ? 1 : 0;
            $extsting = Plan::active()->count();
            
            if($extsting == 4){
                
                 return redirect()->route('admin.plans.index')->with('error', 'Maximum 4 active plans can be added.');
                
            }
            // dd($requestData);
            $requestData['status'] = $status;
            $plan = Plan::create($requestData);
            /** Plan feature create work Start **/
            if (isset($requestData['feature'])) {
                foreach ($requestData['feature'] as $feature) {
                    $value = isset($feature['value']) ? $feature['value'] : 0;
                    PlanFeature::updateOrCreate(
                        ['plan_id' => $plan->id, 'feature_id' => $feature['feature_id']],
                        ['value' => $value, 'description' => $feature['description']]
                    );
                }
            }
            if(!empty($request->category)){
          
                foreach($request->category as $category) {
                    // if(!empty($category['monthly_price']) || !empty($category['quaterly_price']) || !empty($category['half_yearly_price'])){
                    CategoryPlan::updateOrCreate(['plan_id' => $plan->id, 'business_category_id' => $category['category_id']],[
                        'monthly_price' => !empty($category['monthly_price']) ? $category['monthly_price'] : 0, 
                        'quaterly_price' => !empty($category['quaterly_price']) ? $category['quaterly_price'] : 0,
                        'half_yearly_price' => !empty($category['half_yearly_price']) ? $category['half_yearly_price'] : 0],
                    );
                    // }
                }
            }    
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }   
            /** Plan feature create work End **/
            return redirect()->route('admin.plans.index')->with('success', 'Plan has been saved successfully');
    
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show(Plan $plan)
    {        
        $plan = Plan::with('business_category_plan')->findOrFail($plan->id);        
        // dd($plan);
        $features = Feature::status(1)->get();
        $categories=CategoryPlan::where('plan_id',$plan->id)->where('monthly_price','!=','')->get();        
        return view('Admin.plans.show', compact('plan', 'features','categories'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id)
    {
        
        $plan = Plan::with('business_category_plan')->findOrFail($id);       
        $categories= BusinessCategory::where('parent_id','0')->status(1)->get();
        $features = Feature::status(1)->get();         
        return view('Admin.plans.edit', compact('plan', 'features', 'categories'));
    
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(PlanRequest $request, $id)
    {
            DB::beginTransaction();
            try {
                $data = $request->input();
                $plan = Plan::findOrFail($id);
                $plan->fill($data);
                $plan->save();
                /** Plan feature create work Start **/
                if (isset($data['feature'])) {
                    foreach ($data['feature'] as $feature) {
                        // $value = isset($feature['value'])? 1 : 0;
                        $value = isset($feature['value']) ? $feature['value'] : 0;
                        PlanFeature::updateOrCreate(
                            ['plan_id' => $plan->id, 'feature_id' => $feature['feature_id']],
                            ['value' => $value, 'description' => $feature['description']]
                        );
                    }
                }
                if(!empty($request->category)){                
                    CategoryPlan::where('plan_id',$plan->id)->delete();
                    foreach($request->category as $category) {
                        // if(!empty($category['monthly_price']) || !empty($category['quaterly_price']) || !empty($category['half_yearly_price'])){
                            CategoryPlan::updateOrCreate(['plan_id' => $plan->id, 'business_category_id' => $category['category_id']],[
                                'monthly_price' => !empty($category['monthly_price']) ? $category['monthly_price'] : 0, 
                                'quaterly_price' => !empty($category['quaterly_price']) ? $category['quaterly_price'] : 0,
                                'half_yearly_price' => !empty($category['half_yearly_price']) ? $category['half_yearly_price'] : 0,
                                'special_monthly_price' => !empty($category['special_monthly_price']) ? $category['special_monthly_price'] : 0,
                                'special_quaterly_price' => !empty($category['special_quaterly_price']) ? $category['special_quaterly_price'] : 0,
                                'special_half_yearly_price' => !empty($category['special_half_yearly_price']) ? $category['special_half_yearly_price'] : 0]

                            );
                        // }
                    }          
                }
                DB::commit();
                return redirect()->route('admin.plans.index', app('request')->query())->with('success', 'Plan has been updated successfully.');
            
                /** Update Plan Sync Stripe Product End **/
            } catch (\Illuminate\Database\QueryException $e) {
                DB::rollBack();
                return back()->withError($e->getMessage())->withInput();
            }
            
        
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        DB::beginTransaction();
        $plan   =  Plan::findOrFail($id);
        $active_subscriptions   =   Subscription::where("plan_id", $plan->id)->where("status", 1)->get()->count();
        if ($active_subscriptions > 0) {
            return ['status' => false, 'message' => "This plan has active user subscriptions."];
        }
        try {
         //   $response = StripeController::destroy($plan);
            if ($response['status'] == 1) {
                $plan->plan_stripe_plan()->delete();
                $plan->plan_stripe_product()->delete();
                if (!empty($plan)) $plan->delete();
                DB::commit();
                return ['status' => true, 'message' => 'This plan has been deleted Successfully!', 'data' => $plan];
            } else {
                return ['status' => false, 'message' => $response['message']];
            }
        } catch (\Exception $e) {
            DB::rollBack();
            $responce =  ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }
}
