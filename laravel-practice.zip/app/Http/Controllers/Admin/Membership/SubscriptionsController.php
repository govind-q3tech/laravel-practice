<?php

namespace App\Http\Controllers\Admin\Membership;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Routing\Controller;
use Modules\MembershipManager\Entities\Subscription;

class SubscriptionsController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index(Request $request)
    {
        $records = Subscription::sortable(['created_at'=>'desc'])->with('users','plans')->WhereHas('users')->filter(request('keyword'))->paginate(config('get.ADMIN_PAGE_LIMIT'));
		
        return view('membershipmanager::Admin.subscriptions.index', compact('records'));
    }

   

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id)
    {
      
    }
}
