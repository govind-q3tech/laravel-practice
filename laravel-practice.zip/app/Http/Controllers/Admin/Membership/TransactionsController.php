<?php

namespace App\Http\Controllers\Admin\Membership;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Modules\UserManager\Entities\User;
use Modules\UserManager\Entities\Role;
use Illuminate\Routing\Controller;
use Modules\UserManager\Http\Requests\UsersRequest;
use App\Country;
use App\State;
use App\City;
use App\Models\Location;
use App\Models\Membership\Transaction;

class TransactionsController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index(Request $request)
    {
        $records = Transaction::sortable(['created_at'=>'desc'])->with('user')->WhereHas('user')->status(request('status'))->filter(request('keyword'))->paginate(config('get.ADMIN_PAGE_LIMIT'));
		
        return view('membershipmanager::Admin.transactions.index', compact('records'));
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create(Request $request)
    {
       $ofType = $request->get('role') ? $request->get('role') : 1;
        if($ofType == 2 ){            
            $userType = 'Land Partner';
        }elseif($ofType == 3){            
            $userType = 'Build Partner';       
        }else{
            $userType = 'Customer';
        }
        return view('membershipmanager::Admin.transactions.createOrUpdate' , compact( 'ofType','userType'));
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(UsersRequest $request)
    {
        \DB::beginTransaction();
        try{
           $data=$request->input();
           $data['password']=bcrypt($data['password']);
           $user = User::create($data);
           $user->save();
           $roleIds = $request->input('roles');
           $user->roles()->attach($roleIds);
           \DB::commit();
        }
        catch (\Illuminate\Database\QueryException $e) {
            \DB::rollBack();
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.transactions.index', app('request')->query())->with('success', 'User has been saved successfully.');
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show(User $user, Request $request,$id)
    {
        $ofType = $request->get('role') ? $request->get('role') : 1;
        $userType = 'Transactions';
        $records = Transaction::sortable(['created_at'=>'desc'])->with('user')->WhereHas('user')->status(request('status'))->where('id','=',$id)->first();
        return view('membershipmanager::Admin.transactions.show', compact('user', 'userType', 'ofType','records'));
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function refund($id)
    {
        $userType = 'Transactions Refund';
        $records = Transaction::sortable(['created_at'=>'desc'])->with('user')->WhereHas('user')->status(request('status'))->where('id','=',$id)->first();
        return view('membershipmanager::Admin.transactions.refund', compact('userType', 'records'));
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function refundpay(Request $request)
    {
        $requestData = $request->all();
        $records = Transaction::sortable(['created_at'=>'desc'])->with('user')->WhereHas('user')->status(request('status'))->where('id','=',$requestData['tran_id'])->first();
        $totalAmount = $requestData['amount'];
        if($totalAmount != 0)
        {
            \Stripe\Stripe::setApiKey(config('get.STRIPE_SECRET_KEY'));
            if(strpos($totalAmount,".")){ $totalAmount = str_replace(".","",$totalAmount);
            }else{ $totalAmount = $totalAmount."00"; }

            $sub_response = \Stripe\Refund::create([
                'amount' => $totalAmount,
                'charge' => $records->transaction_id,
            ]);
            
            $transaction = new Transaction();
            $transaction->user_id = 1;
            $transaction->amount = $requestData['amount'];
            $transaction->transaction_id = $sub_response->id;
            $transaction->transaction_response = json_encode($sub_response);
            $transaction->type = $sub_response->status;
            $transaction->transction_type = '4';
            $transaction->save();

            return redirect()->route('admin.transactions.index', app('request')->query())->with('success', 'Refund successfully.');
        }
        return redirect()->route('admin.transactions.index', app('request')->query())->with('error', 'Please enter valid amount.');
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id,Request $request)
    {
        $ofType = $request->get('role') ? $request->get('role') : 1;
        $user = User::findOrFail($id);
        if($ofType == 2 ){            
            $userType = 'Land Partner';
        }elseif($ofType == 3){            
            $userType = 'Build Partner';       
        }else{
            $userType = 'Customer';
        }
        return view('membershipmanager::Admin.transactions.createOrUpdate', compact('user', 'ofType', 'userType'));
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(UsersRequest $request, $id)
    {
        DB::beginTransaction();
        try{
            $user = User::findOrFail($id);
            $data=$request->input();
            if(!empty($data['password'])){
                $data['password']=bcrypt($data['password']);
            }else{
                unset($data['password']);
            }
            $user->fill($data);
            $roleIds = $request->input('roles');
            $user->roles()->sync($roleIds);
            $user->save();
            DB::commit();
          }
          catch (\Illuminate\Database\QueryException $e) {
            DB::rollBack();
            return back()->withError($e->getMessage())->withInput();
          }
        return redirect()->route('admin.transactions.index', app('request')->query())->with('success', 'User has been updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id)
    {
        DB::beginTransaction();
        $user = User::findOrFail($id);
        $user->roles()->detach();
        try{
            $user->delete();
            DB::commit();
            $responce =  ['status' => true,'message' => 'This user has been deleted Successfully!','data' => $user];
        }
        catch (\Exception $e)
        {
            DB::rollBack();
            $responce =  ['status' => false,'message' => $e->getMessage()];
        }
        return $responce;
    }
}
