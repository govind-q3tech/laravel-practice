<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\ListingRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
//Models
use App\Models\Listing;
use App\Models\Location;
use App\Models\User;
use App\Models\Category;
use App\Models\Membership\Subscription;
use Gate;

class ListingsController extends Controller
{
         /**
     *  Image upload path.
     *
     * @var string
     */
    protected $image_upload_path;

    /**
     * Storage Class Object.
     *
     * @var \Illuminate\Support\Facades\Storage
     */
    protected $storage;

    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->image_upload_path = 'listing/profile' . DIRECTORY_SEPARATOR;
        $this->storage = Storage::disk('public');
    }



    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $response = Gate::inspect('user-index', "listings");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }        
        //
        $listings = Listing::sortable(['created_at'=>'desc']);
        if($request->query('searchkeyword')){
            $listings = $listings->where('title', 'like', '%' . $request->query('searchkeyword') . '%');
        }
       
        if($request->query('keyword')==5){
            $currentdate=date('Y-m-d');
            $start_date = date("Y-m-d", strtotime($currentdate)) . ' 00:00:00';
            $end_date = date("Y-m-d", strtotime($currentdate)) . ' 23:59:59';
            $subscription =Subscription::where('end_date' ,'<=', $start_date)->where('end_date' ,'>=',$end_date)/*->get()*/->pluck('user_id')->toarray();
           
         $listings = $listings->whereIn('user_id',$subscription);
        }else{
          $listings = $listings->with('user')->filter($request->query('keyword'));   
        }
       $listings = $listings->paginate(config('get.ADMIN_PAGE_LIMIT')); 
       
        return view('Admin.listings.index', compact('listings'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $response = Gate::inspect('user-index', "listings");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }        
        $users = User::select(
            DB::raw("CONCAT(name,' ',last_name,'(',email,')') AS full_name"),'id')->sortable(['full_name'=>'desc'])->pluck('full_name', 'id');
            $locations  = [];
            $categories = Category::status()/*->get()*/->pluck('title', 'id');
    
        return view('Admin.listings.createOrUpdate', compact('users', 'locations', 'categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ListingRequest $request)
    {
        $response = Gate::inspect('user-index', "listings");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }        
        try {
            $requestData = $request->all();
            $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
            $requestData['admin_approve'] = (isset($requestData['admin_approve'])) ? 1 : 0;
            $requestData['show_at_home'] = (isset($requestData['show_at_home'])) ? 1 : 0;
            $requestData['sponsored'] = (isset($requestData['sponsored'])) ? 1 : 0;
            if ($request->hasFile('image')) {
                $image_name = $this->uploadImage(null, $request->file('image'));
                $requestData['image'] = $image_name;
            }
            $listing = Listing::create($requestData);
            
            $listing->locations()->sync($requestData['locations']);
            $listing->categories()->sync($requestData['categories']);


        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.listings.index')->with('success', 'Listing has been saved successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function show(Listing $listing)
    {
        return view('Admin.listings.show', compact('listing'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $response = Gate::inspect('user-index', "listings");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }        
        $listing = Listing::with('locations')->findOrFail($id);
       
        $locations  =$listing->locations->pluck('title','id');
        $categories = Category::status()/*->get()*/->pluck('title', 'id');
        $users = User::select(
            DB::raw("CONCAT(name,' ',last_name,'(',email,')') AS full_name"),'id')->sortable(['full_name'=>'desc'])->pluck('full_name', 'id');
        return view('Admin.listings.createOrUpdate', compact('listing', 'users', 'locations', 'categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(ListingRequest $request, $id)
    {

        $response = Gate::inspect('user-index', "listings");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }        
        try {
            $listing = Listing::findOrFail($id);
            $requestData = $request->all();
            $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
            $requestData['admin_approve'] = (isset($requestData['admin_approve'])) ? 1 : 0;
            $requestData['show_at_home'] = (isset($requestData['show_at_home'])) ? 1 : 0;
            $requestData['sponsored'] = (isset($requestData['sponsored'])) ? 1 : 0;
            if ($request->hasFile('image')) {
                $image_name = $this->uploadImage($listing, $request->file('image'));
                $requestData['image'] = $image_name;
            }else{
                $requestData['image'] = $listing->image;
            }
            $listing->fill($requestData);
            $listing->save();
            $listing->locations()->sync($requestData['locations']);
            $listing->categories()->sync($requestData['categories']);

        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.listings.index')->with('success', 'Listing has been updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Listing $listing)
    {
        $response = Gate::inspect('user-index', "listings");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }  
        // $response = Gate::inspect('lender-delete', $lender);
        // if (!$response->allowed()) {
        //     return ['status' => false, 'message' =>  $response->message()];
        // }
            DB::beginTransaction();
            try {
                $listing->delete();
                DB::commit();
                $responce = ['status' => true, 'message' => 'This listing been deleted successfully.', 'data' => $listing];
            } catch (\Exception $e) {
                DB::rollBack();
                $responce = ['status' => false, 'message' => $e->getMessage()];
            }
            return $responce;
    }

     /*
     * upload image
     */
    public function uploadImage($model = null, $image)
    {
        if($model != null) {
            if ($model->image != null) {
                $this->removeBannerImage($model);
            }
        }

        $path = $this->image_upload_path;

        $image_name = time() . $image->getClientOriginalName();

        // dd($path);

        $this->storage->put($this->image_upload_path . $image_name, file_get_contents($image->getRealPath()));

        return $image_name;
    }

    /*
     * remove image
     */
    public function removeBannerImage($model)
    {
        $path = $this->image_upload_path;
        if ($this->storage->exists($path)) {
            $this->storage->delete($path . $model->image);
            return true;
        }

        throw new \Exception(trans('There is some error in processing this request.'));
    }
}
