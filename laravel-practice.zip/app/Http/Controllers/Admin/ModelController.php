<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Modal;
use App\Models\Make;
use Illuminate\Support\Str;
use App\Http\Requests\ModelValidation;
use Mail;
use Gate, DB;

class ModelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $response = Gate::inspect('check-user', "enquries-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $model = Modal::paginate(10);
   
        return view('Admin.model.index', compact('model'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $response = Gate::inspect('check-user', "enquries-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $maketitle = Make::get();
        return view('Admin.model.createOrUpdate',compact('maketitle'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ModelValidation $request)
    {
        $response = Gate::inspect('check-user', "enquries-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        try {

            $requestData = $request->all();
          
            $requestData['slug'] = Str::slug($requestData['name'],'-');
           
            $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
            $requestData['make_id'] = $requestData['make_name'];
            $requestData['title'] = $requestData['name'];
            Modal::create($requestData);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.models.index')->with('success', 'Model has been saved successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $response = Gate::inspect('check-user', "enquries-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }

        $modal=Modal::with('MakeCategory')->find($id);
        return view('Admin.model.show', compact('modal'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $response = Gate::inspect('check-user', "enquries-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $maketitle = Make::get();
        $modal = Modal::findOrFail($id);

        return view('Admin.model.createOrUpdate', compact('maketitle','modal'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $response = Gate::inspect('check-user', "enquries-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        try {
            $modal = Modal::findOrFail($id);
            $modal['slug'] = Str::slug($request['name'],'-');
           
            $modal['status'] = (isset($request['status'])) ? 1 : 0;
            $modal['make_id'] = $request['make_name'];
            $modal['title'] = $request['name'];
            $modal->save();
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.model.index')->with('success', 'model has been updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $response = Gate::inspect('check-user', "enquries-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        DB::beginTransaction();
        try {
            $model = Modal::findOrFail($id)->delete();
            DB::commit();
            $responce = ['status' => true, 'message' => 'This model has been deleted successfully.', 'data' => ['id' => $id]];
        } catch (\Exception $e) {
            DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }
    
}
