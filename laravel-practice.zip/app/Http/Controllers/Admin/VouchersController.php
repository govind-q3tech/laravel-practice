<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\VoucherRequest;
use App\Models\Voucher;
use Illuminate\Support\Facades\DB;
use Gate;

class VouchersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $response = Gate::inspect('check-user', "vouchers-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $vouchers = Voucher::sortable(['created_at' => 'desc'])->filter($request->query('keyword'))->paginate(config('get.ADMIN_PAGE_LIMIT'));

        return view('Admin.vouchers.index', compact('vouchers'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $response = Gate::inspect('check-user', "vouchers-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $vouchers = Voucher::sortable(['title' => 'desc'])->status()->pluck('title', 'id');

        return view('Admin.vouchers.createOrUpdate', compact('vouchers'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(VoucherRequest $request)
    {
        $response = Gate::inspect('check-user', "vouchers-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        try {
            $requestData = $request->all();

            $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
            $requestData['from_date'] = date('Y-m-d', strtotime($requestData['from_date']));
            $requestData['to_date'] = date('Y-m-d', strtotime($requestData['to_date']));
            Voucher::create($requestData);
            \App\Helpers\StripeHelper::addCoupon($requestData['vouchercode'], $requestData['value'], $requestData['title'], $requestData['type']);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.vouchers.index')->with('success', 'Voucher has been saved successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function show(Voucher $voucher)
    {
        $response = Gate::inspect('check-user', "vouchers-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        return view('Admin.vouchers.show', compact('voucher'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $response = Gate::inspect('check-user', "vouchers-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $voucher = Voucher::findOrFail($id);

        return view('Admin.vouchers.createOrUpdate', compact('voucher'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(VoucherRequest $request, $id)
    {
        $response = Gate::inspect('check-user', "vouchers-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        try {
            $voucher = Voucher::findOrFail($id);
            $requestData = $request->all();
            $requestData['from_date'] = date('Y-m-d', strtotime($requestData['from_date']));
            $requestData['to_date'] = date('Y-m-d', strtotime($requestData['to_date']));
            $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;

            $voucher->fill($requestData);
            $voucher->save();
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.vouchers.index')->with('success', 'Voucher has been updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Voucher $voucher)
    {
        $response = Gate::inspect('check-user', "vouchers-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        DB::beginTransaction();
        try {
            $voucher->delete();
            DB::commit();
            $responce = ['status' => true, 'message' => 'This voucher been deleted successfully.', 'data' => $voucher];
        } catch (\Exception $e) {
            DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }
}
