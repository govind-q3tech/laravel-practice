<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\BusinessCategoryRequest;
use App\Models\BusinessCategory;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use App\Models\Advertisement;
use Gate;
use File;

class BusinessCategoriesController extends Controller
{


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
        $response = Gate::inspect('check-user', "categories-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $businesscategories = BusinessCategory::with('parent')
            ->sortable(['created_at' => 'desc'])
            ->filter($request->query('keyword'))
            ->paginate(config('get.ADMIN_PAGE_LIMIT'));

        return view('Admin.businesscategories.index', compact('businesscategories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $response = Gate::inspect('check-user', "categories-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }

        $parentIds = BusinessCategory::select('id', 'title', 'parent_id')->with('children')->where(['status' => 1, 'parent_id' => 0])->get();
        $categories = $this->makeTree($parentIds);
        return view('Admin.businesscategories.createOrUpdate', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(BusinessCategoryRequest $request)
    {
        // dd($request->all());

        try {
            $requestData = $request->all();
            $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
            if (empty($requestData['parent_id'])) {
                $requestData['parent_id'] = 0;
            }
            if ($request->hasFile('icon')) {
                $filename = time() . '.' . request()->icon->getClientOriginalExtension();
                request()->icon->move(public_path('/category_icons'), $filename);
                $requestData['icon'] = $filename;
            }
            BusinessCategory::create($requestData);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.business-categories.index')->with('success', 'Business category has been saved successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function show($id)
    {
        $response = Gate::inspect('check-user', "categories-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $businesscategory = BusinessCategory::with('parent')->findOrFail($id);
        return view('Admin.businesscategories.show', compact('businesscategory'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $response = Gate::inspect('check-user', "categories-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }

        $parentIds = BusinessCategory::select('id', 'title', 'parent_id')->with('children', function ($q) use ($id) {
            return $q->where('id', '!=', $id);
        })->where(['status' => 1, 'parent_id' => 0])->where('id', '!=', $id)->get();

        $businesscategory = BusinessCategory::findOrFail($id);
        $categories = $this->makeTree($parentIds, $businesscategory->parent_id);
        return view('Admin.businesscategories.createOrUpdate', compact('businesscategory', 'categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(BusinessCategoryRequest $request, $id)
    {
        try {
            $businesscategory = BusinessCategory::findOrFail($id);
            $requestData = $request->all();

            $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
            if (empty($requestData['parent_id'])) {
                $requestData['parent_id'] = 0;
            }
            if ($request->hasFile('icon')) {
                $image_path = public_path("/category_icons/" . $businesscategory->icon);
                if (File::exists($image_path)) {
                    File::delete($image_path);
                }
                $filename = time() . '.' . request()->icon->getClientOriginalExtension();
                request()->icon->move(public_path('/category_icons'), $filename);
                $requestData['icon'] = $filename;
            }
            $businesscategory->fill($requestData);
            $businesscategory->save();
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->business - categorieswithInput();
        }
        return redirect()->route('admin.business-categories.index')->with('success', 'Business category has been updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id = null)
    {
        DB::beginTransaction();
        try {
            $businesscategory = BusinessCategory::findOrFail($id);
            $adsQuery = Advertisement::query();
            if (!empty($businesscategory)) {
                if ($businesscategory->parent_id == 0) {
                    $adsQuery->where('business_category_id', $businesscategory->id);
                } else {
                    $adsQuery->where('business_category_id', $businesscategory->parent_id);
                    $adsQuery->where('sub_business_category_id', $businesscategory->id);
                }
            }
            $adsCount = $adsQuery->count();
            if ($adsCount) {
                $responce = ['status' => false, 'message' => "Business category not able to delete due to some associated data."];
            } else {
                $businesscategory->delete();
                DB::commit();
                $responce = ['status' => true, 'message' => 'Business category has been deleted successfully.', 'data' => ''];
            }
        } catch (\Exception $e) {
            DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }


    function makeTree($categories, $selected = '0')
    {
        $data = [];
        $k = 0;
        /* First Lavel */
        foreach ($categories as $category) {
            $data[$k]['id'] = $category->id;
            $data[$k]['text'] = $category->title;
            $data[$k]['prefix'] = "";
            $data[$k]['position'] = "";
            if ($selected == $category->id) {
                $data[$k]['selected'] = true;
            }
            /*if ($category->children) {
                $data[$k]['expanded'] = true;
                $o = 0;
                // Second Lavel 
                foreach ($category->children as $cat_child) {
                    $data[$k]['items'][$o]['id'] = $cat_child->id;
                    $data[$k]['items'][$o]['text'] = $cat_child->title;
                    $data[$k]['items'][$o]['prefix'] = '';
                    $data[$k]['items'][$o]['position'] = '';
                    if ($selected == $cat_child->id) {
                        $data[$k]['selected'] = true;
                    }
                    if ($cat_child->children) {
                        $data[$k]['expanded'] = true;
                        $s = 0;
                        // Thired Lavel 
                        foreach ($cat_child->children as $cat_subchild) {
                            $data[$k]['items'][$o]['items'][$s]['id'] = $cat_subchild->id;
                            $data[$k]['items'][$o]['items'][$s]['text'] = $cat_subchild->title;
                            $data[$k]['items'][$o]['items'][$s]['prefix'] = '';
                            $data[$k]['items'][$o]['items'][$s]['position'] = '';
                            if ($selected == $cat_subchild->id) {
                                $data[$k]['selected'] = true;
                            }
                            if ($cat_subchild->children) {
                                $data[$k]['expanded'] = true;
                                $ss = 0;
                                // Fourth Lavel 
                                foreach ($cat_subchild->children as $cat_sub_child) {
                                    $data[$k]['items'][$o]['items'][$s]['items'][$ss]['id'] = $cat_sub_child->id;
                                    $data[$k]['items'][$o]['items'][$s]['items'][$ss]['text'] = $cat_sub_child->title;
                                    $data[$k]['items'][$o]['items'][$s]['items'][$ss]['prefix'] = '';
                                    $data[$k]['items'][$o]['items'][$s]['items'][$ss]['position'] = '';
                                    if ($selected == $cat_sub_child->id) {
                                        $data[$k]['selected'] = true;
                                    }
                                    $ss++;
                                }
                            } else {
                                $data[$k]['expanded'] = false;
                            }
                            $s++;
                        }
                    } else {
                        $data[$k]['expanded'] = false;
                    }
                    $o++;
                }
            } else {
                $data[$k]['expanded'] = false;
            }*/
            $k++;
        }
        return $data;
    }



    function getCategoryTree($parent_id = 0, $tree_array = array())
    {
        $categories = BusinessCategory::select('id', 'title', 'parent_id')->with('children')->where('parent_id', '=', $parent_id)->orderBy('parent_id')->get();
        foreach ($categories as $item) {
            $tree_array[] = $item;
            $tree_array = $this->getCategoryTree($item->id, $tree_array);
        }
        return $tree_array;
    }
}
