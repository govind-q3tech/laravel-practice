<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Make;
use App\Models\Category;
use Illuminate\Support\Str;
use App\Http\Requests\MakeValidation;
use Mail;
use Gate, DB;

class MakeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $response = Gate::inspect('check-user', "enquries-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $make = Make::with('BusinessCategory')->paginate(10);
   
        return view('Admin.make.index', compact('make'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $response = Gate::inspect('check-user', "enquries-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $categories = Category::where('parent_id','0')->get();
        return view('Admin.make.createOrUpdate',compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(MakeValidation $request)
    {
        $response = Gate::inspect('check-user', "enquries-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        try {

            $requestData = $request->all();
          
            $requestData['slug'] = Str::slug($requestData['name'],'-');
           
            $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
            $requestData['category_id'] = $requestData['category_name'];
            $requestData['title'] = $requestData['name'];
            Make::create($requestData);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.make.index')->with('success', 'make has been saved successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $response = Gate::inspect('check-user', "enquries-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }

        $make=Make::with('BusinessCategory')->find($id);
        return view('Admin.make.show', compact('make'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $response = Gate::inspect('check-user', "enquries-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $categories = Category::where('parent_id','0')->get();
        $make = Make::findOrFail($id);

        return view('Admin.make.createOrUpdate', compact('make','categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $response = Gate::inspect('check-user', "enquries-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        try {
            $make = Make::findOrFail($id);
            $make['slug'] = Str::slug($request['name'],'-');
           
            $make['status'] = (isset($request['status'])) ? 1 : 0;
            $make['category_id'] = $request['category_name'];
            $make['title'] = $request['name'];
            $make->save();
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.make.index')->with('success', 'Make has been updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $response = Gate::inspect('check-user', "enquries-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        DB::beginTransaction();
        try {
            $make = Make::findOrFail($id)->delete();
            DB::commit();
            $responce = ['status' => true, 'message' => 'This make has been deleted successfully.', 'data' => ['id' => $id]];
        } catch (\Exception $e) {
            DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }
}
