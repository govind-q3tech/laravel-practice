<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Comment;
use Gate;
use DB;

class CommentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $response = Gate::inspect('check-user', "pages-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $comments = Comment::where('parent_id','0')->sortable(['created_at' => 'desc'])->paginate(config('get.ADMIN_PAGE_LIMIT'));

        return view('Admin.comments.index', compact('comments'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $response = Gate::inspect('check-user', "pages-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        try {
            $comment= new Comment();
            $comment->message=$request->reply_text;
            $comment->parent_id=$request->blogname;
            $comment->user_id=$request->name;
            $comment->blog_id=$request->blogname;
            $comment->save();
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.comments.index')->with('success', 'Comment reply has been send successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $sahowcommenr=Comment::find($id);
        return view('Admin.comments.show',compact('sahowcommenr'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $editcomment=Comment::where('id',$id)->first();
        return view('Admin.comments.contact_reply',compact('editcomment'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $response = Gate::inspect('check-user', "pages-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        try {
            $comment = Comment::findOrFail($id);
            $comment->message=$request->reply_text;

            // dd($id);
            // $requestData = $request->all();
            
            // $requestData['blog_id'] = $requestData['blogname'];
            // $requestData['user_id'] = $requestData['name']; 
            // $requestData['parent_id'] = $requestData['blogname'];      
            // $requestData['message'] = $requestData['reply_text'];    
            // $comment->fill($requestData);
            $comment->save();
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.comments.index')->with('success', 'Comment reply has been send successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::beginTransaction();
        try {
            $comment = Comment::findOrFail($id)->delete();
            DB::commit();
            $responce = ['status' => true, 'message' => 'This comment has been deleted successfully.', 'data' => $comment];
        } catch (\Exception $e) {
            DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

    public function status(Request $request){
        $comment = Comment::find($request->user_id);
        $comment->status = $request->status;
        $comment->save();
  
        return response()->json(['success'=>'Status change successfully.']);
    }
}
