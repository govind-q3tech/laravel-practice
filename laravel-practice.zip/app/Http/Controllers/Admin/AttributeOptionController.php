<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AdminUser;
use App\Models\Attribute;
use App\Models\AttributeOption;
use DB;

class AttributeOptionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if(!empty(app('request')->query('attr_id'))){
            $attr_id = app('request')->query('attr_id');
            // $response = Gate::inspect('check-user', "admin-users-index");
            // if (!$response->allowed()) {
            //     return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
            // }
            $ifExisteData = Attribute::where(['id'=>$attr_id])->count();
            if(!empty($ifExisteData)){
                $query = AttributeOption::with(['parent','parent.attribute', 'businessCategory','attribute'])
                ->status(app('request')->query('status'))
                ->filter(app('request')->query('keyword'))
                ->where('attr_id',$attr_id);
                $attributeOptions = $query->sortable(['created_at' => 'DESC'])->paginate(10);
                // dd($attributeOptions);
                return view('Admin.attrOption.index', compact('attributeOptions', 'attr_id'));
            }else{
                return redirect()->route('admin.attributes.index');
            }
        }else{
            return redirect()->route('admin.attributes.index');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        if(!empty(app('request')->query('attr_id'))){
            $attr_id = app('request')->query('attr_id');
            // $response = Gate::inspect('check-user', "enquries-create");
            // if (!$response->allowed()) {
            //     return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
            // }        
            
            $existData = Attribute::with('businessCategory')->where(['id'=>$attr_id])->first();
            if(!empty($existData)){
                $categories = [];
                if(!empty($existData->businessCategory)){
                    foreach($existData->businessCategory  as $category){
                        $categories[$category->id] = $category->title;
                    }
                }
                $options = AttributeOption::where(['parent_id' => 0])->pluck('name', 'id')->toArray();
                return view('Admin.attrOption.createOrUpdate',compact('categories', 'options'));
            }else{
                return redirect()->route('admin.attributes.index');
            }
        }else{
            return redirect()->route('admin.attributes.index');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(!empty(app('request')->query('attr_id'))){
            $attr_id = app('request')->query('attr_id');
            // $response = Gate::inspect('check-user', "enquries-create");
            // if (!$response->allowed()) {
            //     return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
            // }
            $existData = Attribute::with('businessCategory')->where(['id'=>$attr_id])->first();
            if(!empty($existData)){
                try {
                    $request->validate([
                        'name' => 'required|regex:/^[a-zA-Z0-9\s]+$/|min:2|max:100',
                        'category_id' => 'required',
                    ]);
                    $requestData = $request->all();
                    $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
                    if (empty($requestData['parent_id'])) {
                        $requestData['parent_id'] = 0;
                    }
                    AttributeOption::create($requestData);
                } catch (\Illuminate\Database\QueryException $e) {
                    return back()->withError($e->getMessage())->withInput();
                }
                return redirect()->route('admin.attribute-options.index', ['attr_id' =>$attr_id])->with('success', 'Attribute Option has been saved successfully');
            }else{
                return redirect()->route('admin.attributes.index');
            }
        }else{
            return redirect()->route('admin.attributes.index');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\AdminUser  $adminUser
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if(!empty(app('request')->query('attr_id'))){
            
            // $response = Gate::inspect('check-user', "enquries-create");
            // if (!$response->allowed()) {
            //     return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
            // }        
            $option = AttributeOption::findOrFail($id);
            $attr_id = app('request')->query('attr_id');
            
            $existData = Attribute::with('businessCategory')->where(['id'=>$attr_id,'type'=> 'dropdown'])->first();
            if(!empty($existData)){
                $categories = [];
                if(!empty($existData->businessCategory)){
                    foreach($existData->businessCategory  as $category){
                        $categories[$category->id] = $category->title;
                    }
                }
                $options = AttributeOption::where(['parent_id' => 0])->where('id', '!=', $id)->pluck('name', 'id')->toArray();
                return view('Admin.attrOption.createOrUpdate',compact('option', 'categories', 'options'));
            }else{
                return redirect()->route('admin.attributes.index');
            }
        }else{
            return redirect()->route('admin.attributes.index');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\AdminUser  $adminUser
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if(!empty(app('request')->query('attr_id'))){
            $attr_id = app('request')->query('attr_id');
            // $response = Gate::inspect('check-user', "enquries-create");
            // if (!$response->allowed()) {
            //     return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
            // }
            $existData = Attribute::with('businessCategory')->where(['id'=>$attr_id,'type'=> 'dropdown'])->first();
            if(!empty($existData)){
                try {
                    $request->validate([
                        'name' => 'required|regex:/^[a-zA-Z0-9\s]+$/|min:2|max:100',
                        'category_id' => 'required',
                    ]);
                    $option = AttributeOption::findOrFail($id);
                    $requestData = $request->all();
                    $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
                    if (empty($requestData['parent_id'])) {
                        $requestData['parent_id'] = 0;
                    }
                    $option->fill($requestData);
                    $option->save();
                } catch (\Illuminate\Database\QueryException $e) {
                    return back()->withError($e->getMessage())->withInput();
                }
                return redirect()->route('admin.attribute-options.index', ['attr_id' =>$attr_id])->with('success', 'Attribute Option has been Update successfully');
            }else{
                return redirect()->route('admin.attributes.index');
            }
        }else{
            return redirect()->route('admin.attributes.index');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id = null)
    {
        DB::beginTransaction();
        try {
            $attributeOption = AttributeOption::findOrFail($id);
            $attributeOption->delete();
            DB::commit();
            $responce = ['status' => true, 'message' => 'Attribute Option has been deleted successfully.', 'data' => ''];
        } catch (\Exception $e) {
            DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

}
