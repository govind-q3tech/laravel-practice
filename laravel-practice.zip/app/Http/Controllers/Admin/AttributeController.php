<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Attribute;
use App\Models\BusinessCategory;
use App\Models\AttributeBusinessCategory;
use Illuminate\Support\Str;
use Mail;
use Gate, DB;


class AttributeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $response = Gate::inspect('check-user', "categories-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $queryObj = Attribute::sortable(['created_at' => 'desc'])->filter($request->query('keyword'));
        if (!empty($request->query('category_id'))) {
            $category_id = $request->query('category_id');
            $queryObj->whereHas('businessCategory', function ($query) use ($category_id) {
                $query->where('category_id', $category_id);
            });
        }

        $attributes = $queryObj->paginate(config('get.ADMIN_PAGE_LIMIT'));
        $categories = BusinessCategory::sortable(['title' => 'desc'])->status()->where(['parent_id' => 0])->pluck('title', 'id')->toArray();
        return view('Admin.attribute.index', compact('attributes', 'categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $response = Gate::inspect('check-user', "categories-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $parentIds = BusinessCategory::select('id', 'title', 'parent_id')->with('children')->status()->where(['parent_id' => 0])->get();
        $categories = $this->makeTree($parentIds);
        return view('Admin.attribute.createOrUpdate', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $response = Gate::inspect('check-user', "categories-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        try {

            $request->validate([
                'name' => 'required|regex:/^[a-zA-Z0-9\s]+$/|min:2|max:100',
                'type' => 'required',
                'label' => 'required',
                'ordering' => 'nullable|numeric|max:100',
            ]);

            $requestData = $request->all();
            $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
            $saveattribute = Attribute::create($requestData);
            if ($saveattribute) {
                if (!empty($request->parent_id)) {
                    $uniValuye = array_unique($request->parent_id);
                    foreach ($uniValuye as $vals) {
                        $saveid = new AttributeBusinessCategory;
                        $saveid->attribute_id = $saveattribute->id;
                        $saveid->category_id = $vals;
                        $saveid->save();
                    }
                }
            }
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.attributes.index')->with('success', 'Attribute has been saved successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $response = Gate::inspect('check-user', "categories-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $attribute = Attribute::find($id);
        return view('Admin.attribute.show', compact('attribute'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $response = Gate::inspect('check-user', "categories-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $parentIds = BusinessCategory::select('id', 'title', 'parent_id')->status()->where(['parent_id' => 0])->get();
        $attribute = Attribute::with('businessCategory')->find($id);
        $selectedCat = [];
        if (!empty($attribute->businessCategory)) {
            foreach ($attribute->businessCategory as $key => $bcat) {
                $selectedCat[] = $bcat->id;
            }
        }
        $categories = $this->makeTree($parentIds, $selectedCat);
        // dd($parentIds);
        return view('Admin.attribute.createOrUpdate', compact('categories', 'attribute'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $response = Gate::inspect('check-user', "categories-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        try {
            $request->validate([
                'name' => 'required|regex:/^[a-zA-Z0-9\s]+$/|min:2|max:100',
                'type' => 'required',
                'label' => 'required',
                'ordering' => 'nullable|numeric|max:100',
            ]);
            $attribute = Attribute::findOrFail($id);
            $requestData = $request->all();

            $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
            $attribute = $attribute->fill($requestData);
            if ($attribute->save()) {
                AttributeBusinessCategory::where('attribute_id', $attribute->id)->delete();
                // $attribute->businessCategory()->delete();
                if (!empty($request->parent_id)) {
                    $uniValuye = array_unique($request->parent_id);
                    foreach ($uniValuye as $cartId) {
                        $saveid = new AttributeBusinessCategory;
                        $saveid->attribute_id = $attribute->id;
                        $saveid->category_id = $cartId;
                        $saveid->save();
                    }
                }
            }
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.attributes.index')->with('success', 'Attributes has been updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $response = Gate::inspect('check-user', "categories-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        DB::beginTransaction();
        try {
            Attribute::findOrFail($id)->delete();
            DB::commit();
            $responce = ['status' => true, 'message' => 'This attribute has been deleted successfully.', 'data' => ['id' => $id]];
        } catch (\Exception $e) {
            DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

    function makeTree($categories, $selected = [])
    {
        $data = [];
        $k = 0;
        /* First Lavel */
        foreach ($categories as $category) {
            $data[$k]['id'] = $category->id;
            $data[$k]['text'] = $category->title;
            $data[$k]['prefix'] = "";
            $data[$k]['position'] = "";
            if (in_array($category->id, $selected)) {
                $data[$k]['selected'] = true;
            }
            $k++;
        }
        return $data;
    }



    // function getCategoryTree($parent_id = 0, $tree_array = array())
    // {
    //     $categories = BusinessCategory::select('id', 'title', 'parent_id')->with('children')->where('parent_id', '=', $parent_id)->orderBy('parent_id')->get();
    //     foreach ($categories as $item) {
    //         $tree_array[] = $item;
    //         $tree_array = $this->getCategoryTree($item->id, $tree_array);
    //     }
    //     return $tree_array;
    // }
}
