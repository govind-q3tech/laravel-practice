<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\OpeningRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
//Models
use App\Models\Opening;

class OpeningsController extends Controller
{
   

    

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $openings = Opening::where('listing_id',$id)->get();
        $openingData = [];
        foreach($openings as $opening){
            $openingData[$opening->day] = $opening;
        }
        
        $days = [1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday'];
        return view('Admin.openings.show', compact('openings', 'id', 'days', 'openingData'));
    }

   

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            $requestData = $request->all();
            $submittedData = [];
            
            foreach(range(0,6) as $data){

                $submittedData['day'] = $requestData['day'][$data];                
                $submittedData['listing_id'] = $requestData['listing_id'][$data];  
                $submittedData['status'] = 1;
                if(isset($requestData['id'][$data])){
                    $submittedData['id'] = $requestData['id'][$data];
                }
                if(!isset($requestData['closed'][$data])){
                    $submittedData['closed'] = 1;
                    $submittedData['start_time'] = $requestData['start_time'][$data];
                    $submittedData['end_time'] = $requestData['end_time'][$data];
                }else{
                    $submittedData['closed'] = 0;
                    $submittedData['start_time'] = '';
                    $submittedData['end_time'] = '';
                } 
                
                if(isset($submittedData['id']) && is_numeric($submittedData['id'])){
                    $opening = Opening::findOrFail($submittedData['id']);
                    $opening->fill($submittedData);
                    $opening->save();
                }else{
                    Opening::create($submittedData);
                }
                
                
            }

           
            
            
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.listings.index')->with('success', 'Openings hour has been saved successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
