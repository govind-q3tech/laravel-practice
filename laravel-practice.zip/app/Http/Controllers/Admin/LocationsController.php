<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\LocationRequest;
use App\Models\Location;
use App\Models\Area;
use App\Models\City;
use App\Models\Advertisement;
use Illuminate\Support\Facades\DB;
use Gate;

class LocationsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $response = Gate::inspect('check-user', "locations-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $locations = Location::sortable(['created_at' => 'desc'])->with('area')->filter($request->query('keyword'))->paginate(config('get.ADMIN_PAGE_LIMIT'));

        return view('Admin.locations.index', compact('locations'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $response = Gate::inspect('check-user', "locations-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }

        $cityAreas = $this->cityArea();
        return view('Admin.locations.createOrUpdate', compact('cityAreas'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(LocationRequest $request)
    {
        $response = Gate::inspect('check-user', "locations-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }

        try {
            $requestData = $request->all();
            $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
            Location::create($requestData);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.locations.index')->with('success', 'Location has been saved successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function show(Location $location)
    {

        $response = Gate::inspect('check-user', "locations-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        return view('Admin.locations.show', compact('location'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $response = Gate::inspect('check-user', "locations-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $location = Location::findOrFail($id);
        $cityAreas = $this->cityArea();
        return view('Admin.locations.createOrUpdate', compact('location', 'cityAreas'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(LocationRequest $request, $id)
    {

        $response = Gate::inspect('check-user', "locations-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        try {
            $location = Location::findOrFail($id);
            $requestData = $request->all();
            $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
            $location->fill($requestData);
            $location->save();
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.locations.index')->with('success', 'Location has been updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Location $location)
    {

        $response = Gate::inspect('check-user', "locations-create");
        if (!$response->allowed()) {
            // return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
            $responce = ['status' => false, 'message' => $response->message()];
        } else {
            DB::beginTransaction();
            try {
                $adsQuery = Advertisement::query();
                if (!empty($city)) {
                    $adsQuery->where('location_id', $location->id);
                }
                $adsCount = $adsQuery->count();
                if ($adsCount) {
                    $responce = ['status' => false, 'message' => "Business category not able to delete due to some associated data."];
                } else {
                    $location->delete();
                    DB::commit();
                    $responce = ['status' => true, 'message' => 'This location has been deleted successfully.', 'data' => $location];
                }
            } catch (\Exception $e) {
                DB::rollBack();
                $responce = ['status' => false, 'message' => $e->getMessage()];
            }
        }
        return $responce;
    }

    function cityArea()
    {
        $cities = City::select(['id', 'title'])->sortable(['title' => 'desc'])->with(['areas'])->where('status', 1)->get();
        $cityAreas = [];
        if (!empty($cities)) {
            foreach ($cities as $city) {
                if (!empty($city->areas)) {
                    foreach ($city->areas as $area) {
                        $cityAreas[$city->title][$area->id] = $area->title;
                    }
                }
            }
        }
        return $cityAreas;
    }
}
