<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\GalleryRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Models\Gallery;
use App\Models\GalleryImage;
use Gate;

class GalleriesController extends Controller
{
    /**
     *  Image upload path.
     *
     * @var string
     */
    protected $image_upload_path;

    /** 
     * Storage Class Object.
     *
     * @var \Illuminate\Support\Facades\Storage
     */
    protected $storage;

    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->image_upload_path = 'gallery' . DIRECTORY_SEPARATOR;
        $this->storage = Storage::disk('public');
    }


    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index(Request $request)
    {
        $response = Gate::inspect('check-user', "galleries-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $allowed_columns = ['id'];
        $sort = in_array($request->get('sort'), $allowed_columns) ? $request->get('sort') : 'created_at';
        $order = $request->get('direction') === 'asc' ? 'asc' : 'desc';
        $galleries = Gallery::filter($request->query('keyword'))->orderBy($sort, $order)->paginate(config('get.ADMIN_PAGE_LIMIT'));
        return view('Admin.galleries.index', compact('galleries'));
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
        $response = Gate::inspect('check-user', "galleries-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $extsting = Gallery::active()->count();
        if($extsting == 5){
             return redirect()->route('admin.galleries.index')->with('error', 'Maximum 5 active banner images uploaded limit.');
        }
        return view('Admin.galleries.createOrUpdate');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(GalleryRequest $request)
    {
        $response = Gate::inspect('check-user', "galleries-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        try {
            $extsting = Gallery::active()->count();
            if($extsting == 5){
                 return redirect()->route('admin.galleries.index')->with('error', 'Maximum 5 active banner images uploaded limit.');
            }
            $requestData = $request->all();
            // dd($requestData);
            $gallery_images = '';
            if (isset($requestData['gallery_image']) || !empty(isset($requestData['gallery_image']))) {
                $gallery_images = $requestData['gallery_image'];
                unset($requestData['gallery_image']);
            }
            if(!empty($gallery_images[0]['title'])){
                $title = $gallery_images[0]['title'];
            }else{
                $image_name = explode('.', $gallery_images[0]['image_name']);
                $title = $image_name[0];
            } 

            $requestData['title'] = $title;
            $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
            $requestData['image_link'] = !empty($gallery_images[0]['image_link'])?$gallery_images[0]['image_link']:'';

            $gallery = Gallery::create($requestData);
            if (!empty($gallery_images)) {
                $galleries = $gallery_images;
                foreach ($galleries as $key => $value) {
                    if (!empty($value['image_name']) || !empty($value['title'])) {
                        $gallery_array = array();
                        $gallery_array['gallery_id'] = $gallery->id;
                        $gallery_array['title'] = $value['title'];
                        $gallery_array['image'] = $value['image_path'];
                        $gallery_array['image_name'] = $value['image_name'];
                        GalleryImage::create($gallery_array);
                    }
                }
            }
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.galleries.index')->with('success', 'Banner has been saved successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function show($id)
    {
        $response = Gate::inspect('check-user', "galleries-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $gallery = Gallery::with('images')->where('id', $id)->first();
        return view('Admin.galleries.show', compact('gallery', 'id'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit(Gallery $gallery)
    {
        $response = Gate::inspect('check-user', "galleries-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        return view('Admin.galleries.createOrUpdate', compact('gallery'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(GalleryRequest $request, $id)
    {
        $response = Gate::inspect('check-user', "galleries-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        try {
            $requestData = $request->all();
            $status = (isset($requestData['status'])) ? 1 : 0;
            $extsting = Gallery::active()->count();
            if($extsting > 5){
                if($status){
                 return redirect()->route('admin.galleries.index')->with('error', 'Maximum 5 active banner images uploaded limit.');
                }
            }
            $path = $this->image_upload_path;
            $gallery = Gallery::findOrFail($id);
            

            if ($request->has('gallery_image')) {
                $delete_previous = GalleryImage::where('gallery_id', $gallery->id)->get();
                foreach ($delete_previous as $key => $del) {
                    GalleryImage::where('id', $del->id)->delete();
                    // if (!empty($del->image_name)) {
                    //     unlink(public_path($path . $del->image_name));
                    // }
                }
                $galleries = $request->get('gallery_image');
                foreach ($galleries as $key => $value) {
                    if (!empty($value['image_name']) || !empty($value['title'])) {
                        $gallery_array = array();
                        $gallery_array['gallery_id'] = $gallery->id;
                        $gallery_array['title'] = $value['title'];
                        $gallery_array['image'] = $value['image_path'];
                        $gallery_array['image_name'] = $value['image_name'];
                        GalleryImage::create($gallery_array);
                    }
                }
            }

            unset($requestData['gallery_image']);
            if(!empty($galleries[0]['title'])){
                $title = $galleries[0]['title'];
            }else{
                $image_name = explode('.', $galleries[0]['image_name']);
                $title = $image_name[0];
            } 
            $requestData['title'] = $title;
            $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
            $requestData['image_link'] = !empty($galleries[0]['image_link'])?$galleries[0]['image_link']:'';

            $gallery->fill($requestData);
            $gallery->save();
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.galleries.index')->with('success', 'Banner has been updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $response = Gate::inspect('check-user', "galleries-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        DB::beginTransaction();
        try {
            $path = $this->image_upload_path;
            $galleryImage = GalleryImage::where('id', $id)->first();
            if (file_exists(public_path($path . $galleryImage->image_name))) {
                unlink(public_path($path . $galleryImage->image_name));
            }
            $galleryImage->delete();
            DB::commit();
            $responce = ['status' => true, 'message' => 'This image has been deleted successfully.', 'data' => ['id' => $id]];
        } catch (\Exception $e) {
            DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteGallery($id)
    {
        $response = Gate::inspect('check-user', "galleries-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        DB::beginTransaction();
        try {
            $path = $this->image_upload_path;
            $delete_previous = GalleryImage::where('gallery_id', $id)->get();
            foreach ($delete_previous as $key => $del) {
                GalleryImage::where('id', $del->id)->delete();
                if (!empty($del->image_name)) {
                    unlink(public_path($path . $del->image_name));
                }
            }
            Gallery::where('id', $id)->delete();
            DB::commit();
            $responce = ['status' => true, 'message' => 'This banner with images has been deleted successfully.', 'data' => ['id' => $id]];
        } catch (\Exception $e) {
            DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

    /**
     * Mangage imagess of lisitng.
     *
     * @param  int  $id of gallery
     * @return \Illuminate\Http\Response
     */
    public function imageUpdate(Request $request, $id)
    {
        try {
            $gallery = Gallery::findOrFail($id);
            $requestData = $request->all();
            $gallery->fill($requestData);
            $gallery->save();
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }

        return back()->with('success', 'Banner has been updated successfully.');
    }

    /*
     * upload images
     */
    public function uploadImage(Request $request)
    {
        $path = $this->image_upload_path;
        if ($request->ajax()) {
            $filedata = $_FILES;
            if (isset($filedata['file']) && strlen($filedata['file']["name"]) > 1) {
                $ext            = pathinfo($filedata['file']["name"], PATHINFO_EXTENSION);
                $allowedExt     = array('gif', 'jpeg', 'png', 'jpg', 'tif', 'bmp', 'ico');
                $image_only     = true;
                $maxsize    = 5242880;
                if (in_array(strtolower($ext), $allowedExt)) {
                    if(($filedata['file']['size'] >= $maxsize) || ($filedata['file']["size"] == 0)) {
                        $data['success']    = false;
                        $data['message'] = 'File too large. File must be less than 5 mb.';
                    }else{
                        $upload_img = $filedata['file']["name"];
                        $ran        = time();
                        $upload_img = $ran . "_" . $filedata['file']["name"];
                        if (strlen($upload_img) > 80) {
                            $upload_img = $ran . "_" . rand() . "." . $ext;
                        }
                        $upload_img = str_replace(' ', '_', $upload_img);
                        $file = $request->file('file');
                        $file->move(public_path($path), $upload_img);

                        if ($image_only)
                            $data['image']   = true;
                        $data['filename']   =  $upload_img;
                        $data['image_path'] = url($path . $upload_img);
                        $data['success']    = true;
                        $data['message']    = "File successfully uploaded!";
                    }
                } else {
                    $data['success'] = false;
                    $data['message'] = "Upload file is type invalid!";
                }
            } else {
                $data['success'] = false;
                $data['message'] = "Please upload valid file!";
            }
        }
        return response()->json($data);
    }

    /*
     * remove image
     */
    public function removeBannerImage($model)
    {
        $path = $this->image_upload_path;
        if ($this->storage->exists($path)) {
            $this->storage->delete($path . $model->images);
            return true;
        }

        throw new \Exception(trans('There is some error in processing this request.'));
    }
}
