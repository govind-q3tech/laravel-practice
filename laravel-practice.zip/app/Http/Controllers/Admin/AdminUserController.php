<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AdminUser;
use App\Models\AdminRole;
use Illuminate\Http\Request;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\AdminUserRequest;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use App\Rules\CheckPhone;
use App\Models\User;
use App\Models\Page;
use App\Models\Location;
use App\Models\BusinessCategory;
use App\Models\Record;
use App\Models\Contact;
use App\Models\Advertisement;
use Gate;

class AdminUserController extends Controller
{

    /**
     * Admin Dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function dashboard()
    {
        $consumers = User::typefilter('customers')->get()->count();
        $advertiserUsers = User::typefilter('advertisers')->get()->count();
        $adminUsers = AdminUser::count();
        $pages = Page::count();
        $locations = Location::count();
        $advertisements = Advertisement::count();
        $contact = Contact::count();
        $businessCategories = BusinessCategory::count();
        $views = Record::where('type', 1)->count();
        $emailclick = Record::where('type', 3)->count();
        $phoneclick = Record::where('type', 2)->count();
        $websiteclick = Record::where('type', 4)->count();
        return view('Admin.adminUsers.dashboard', compact('consumers', 'advertiserUsers', 'adminUsers', 'pages', 'locations', 'businessCategories', 'views', 'emailclick', 'phoneclick', 'websiteclick', 'contact', 'advertisements'));
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $response = Gate::inspect('check-user', "admin_users-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $query = AdminUser::whereNotIn('id', [auth()->guard('admin')->user()->id, 1])->with(['role'])->status(app('request')->query('status'))->filter(app('request')->query('keyword'));
        $adminUsers = $query->sortable(['created_at' => 'DESC'])->paginate(10);
        //dd($adminUsers);
        return view('Admin.adminUsers.index', compact('adminUsers'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $response = Gate::inspect('check-user', "admin_users-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }

        $roles = AdminRole::active()->whereNotIn('id', [1])->pluck('title', 'id');
        return view('Admin.adminUsers.createOrUpdate', compact('roles'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AdminUserRequest $request)
    {

        $response = Gate::inspect('check-user', "admin_users-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        DB::beginTransaction();
        try {
            $requestData = $request->input();
            $requestData['password'] = Hash::make($request->password);
            $requestData['dob'] = date('Y-m-d', strtotime($requestData['dob']));
            $adminUser = AdminUser::create($requestData);
            event(new Registered($adminUser));
            DB::commit();
        } catch (\Illuminate\Database\QueryException $e) {
            DB::rollBack();
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.admin-users.index', app('request')->query())->with('success', 'Admin user has been saved successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\AdminUser  $adminUser
     * @return \Illuminate\Http\Response
     */
    public function show(AdminUser $adminUser)
    {
        $response = Gate::inspect('check-user', "admin_users-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $roles = AdminRole::active()->pluck('title', 'id');
        return view('Admin.adminUsers.show', compact('adminUser', 'roles'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\AdminUser  $adminUser
     * @return \Illuminate\Http\Response
     */
    public function edit(AdminUser $adminUser)
    {
        $response = Gate::inspect('check-user', "admin_users-create");
        if (!$response->allowed() || auth()->guard('admin')->user()->id==$adminUser->id|| $adminUser->id ==1) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        $roles = AdminRole::active()->pluck('title', 'id');
        return view('Admin.adminUsers.createOrUpdate', compact('adminUser', 'roles'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\AdminUser  $adminUser
     * @return \Illuminate\Http\Response
     */
    public function update(AdminUserRequest $request, AdminUser $adminUser)
    {
        // dd($request);
        if(!isset($request->status))
        {
            $request['status'] = 0;
        }else{
            $request['status'] = 1;
        }
        $response = Gate::inspect('check-user', "admin_users-create");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }
        DB::beginTransaction();
        try {
            $adminUser->fill($request->input());
            $adminUser->dob = date('Y-m-d', strtotime($adminUser->dob));
            $adminUser->save();
            DB::commit();
        } catch (\Illuminate\Database\QueryException $e) {
            DB::rollBack();
            return back()->with('error', $e->getMessage())->withInput();
        }
        if (app('request')->query('redirect')) {
            return redirect(app('request')->query('redirect'))->with('success', 'Your profile has been updated successfully');
        }
        return redirect()->route('admin.admin-users.index', app('request')->query())->with('success', 'Admin User has been updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\AdminUser  $adminUser
     * @return \Illuminate\Http\Response
     */
    public function destroy(AdminUser $adminUser)
    {
        $response = Gate::inspect('check-user', "admin_users-index");
        if (!$response->allowed()) {
            return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        }

        DB::beginTransaction();
        try {
            $adminUser->delete();
            DB::commit();
            $responce = ['status' => true, 'message' => 'This admin user has been deleted successfully.', 'data' => $adminUser];
        } catch (\Exception $e) {
            DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }


    public function reports()
    {
        $start_date = '';
        $end_date   = '';
        $records = Record::Select(DB::raw('count(id) as `data` , type'))->with("listing.user");
        $type  = request('type');
        if (request('type')) {
            $today = date("Y-m-d");

            if ((request('type') == 'range')) {
                $start_date  = request('start_date');
                $end_date    = request('end_date');
            } else if (request('type') == 'last week') {
                $start_date  = date('Y-m-d', strtotime($today . ' - 8 days'));
                $end_date    = date('Y-m-d', strtotime($today . ' - 1 days'));
            } else if (request('type') == 'last month') {

                $start_date = Date("Y-F-d", strtotime("first day of previous month"));
                $end_date   = Date("Y-F-d", strtotime("last day of previous month"));
            } else if (request('type') == 'date') {
                $start_date  = request('start_date');
                $end_date    = request('start_date');
            }

            $start_dates = date("Y-m-d", strtotime($start_date)) . ' 00:00:00';
            $end_dates   = date("Y-m-d", strtotime($end_date)) . ' 23:59:59';
            $records     = $records->whereDate('created_at', '>=', $start_dates)->whereDate('created_at', '<=', $end_dates);
        }

        $records    = $records->groupBy("type")->get();
        $recordType = [];
        foreach ($records as $record) {
            $recordType[$record->type] = $record->data;
        }
        return view('Admin.adminUsers.report', compact('recordType', 'start_date', 'end_date', 'type'));
    }

    public function reportDashboard(Request $request)
    {
        // echo "<pre>"; print_r($request->all()); exit;
        $start_date = '';
        $end_date   = '';
        $dateF   = '';
        $consumers = User::typefilter('customers');
        $advertiserFreeUsers = User::typefilter('advertisers');
        $advertisements =  Advertisement::where('title', '!=', '');
        $activeAdvertisements = Advertisement::where('status', 1);
        $draftAdvertisements = Advertisement::where('status', 0);
        $reviewAdvertisements = Advertisement::where('status', 2);
        $declineAdvertisements = Advertisement::where('status', 3);
        $closeAdvertisements = Advertisement::where('status', 4);

        if (request('start_date') && !empty(request('start_date'))) {
            $dateF   = request('start_date');
            $date = explode('-', request('start_date'));
            $today = date("Y-m-d");
            $start_date = $date[0];
            $end_date = $date[1];

            $start_dates = date("Y-m-d", strtotime($start_date)) . ' 00:00:00';
            $end_dates   = date("Y-m-d", strtotime($end_date)) . ' 23:59:59';

            $consumers     = $consumers->whereDate('created_at', '>=', $start_dates)->whereDate('created_at', '<=', $end_dates);
            $advertiserFreeUsers     = $advertiserFreeUsers->whereDate('created_at', '>=', $start_dates)->whereDate('created_at', '<=', $end_dates);
            $advertisements     = $advertisements->whereDate('created_at', '>=', $start_dates)->whereDate('created_at', '<=', $end_dates);
            $activeAdvertisements     = $activeAdvertisements->whereDate('created_at', '>=', $start_dates)->whereDate('created_at', '<=', $end_dates);
            $draftAdvertisements     = $draftAdvertisements->whereDate('created_at', '>=', $start_dates)->whereDate('created_at', '<=', $end_dates);
            $reviewAdvertisements     = $reviewAdvertisements->whereDate('created_at', '>=', $start_dates)->whereDate('created_at', '<=', $end_dates);
            $declineAdvertisements     = $declineAdvertisements->whereDate('created_at', '>=', $start_dates)->whereDate('created_at', '<=', $end_dates);
            $closeAdvertisements     = $closeAdvertisements->whereDate('created_at', '>=', $start_dates)->whereDate('created_at', '<=', $end_dates);
        }

        $consumers = $consumers->get()->count();
        $advertiserFreeUsers = $advertiserFreeUsers->get()->count();
        $advertisements = $advertisements->get()->count();
        $activeAdvertisements = $activeAdvertisements->get()->count();
        $draftAdvertisements = $draftAdvertisements->get()->count();
        $reviewAdvertisements = $reviewAdvertisements->get()->count();
        $closeAdvertisements = $closeAdvertisements->get()->count();
        $declineAdvertisements = $declineAdvertisements->get()->count();
        return view('Admin.adminUsers.report-dashbaord', compact('dateF',  'consumers', 'advertiserFreeUsers', 'advertisements', 'activeAdvertisements', 'draftAdvertisements', 'reviewAdvertisements', 'closeAdvertisements', 'declineAdvertisements'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\AdminUser  $adminUser
     * @return \Illuminate\Http\Response
     */
    public function profile(Request $request)
    {
        $adminUser = AdminUser::status(1)->where('id', \Auth::user()->id)->first();

        return view('Admin.adminUsers.profile', compact('adminUser'));
    }

    /**
     * Handle an incoming registration request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function updateprofile(Request $request)
    {
        $request->validate([
            'first_name' => 'required|regex:/^[\pL\s\-.\']+$/u|min:2|max:100',
            'last_name' => 'nullable|regex:/^[\pL\s\-.\']+$/u|min:2|max:100',
            'mobile' => ['required', 'numeric', 'min:10', new CheckPhone],
        ]);
        $adminUser = AdminUser::status(1)->where('id', \Auth::user()->id)->first();
        //dd($request->all());

        DB::beginTransaction();
        try {
            $adminUser->fill($request->input());
            $adminUser->dob = !empty($request['dob']) ? date('Y-m-d', strtotime($request['dob'])) : null;
            $adminUser->save();
            DB::commit();
        } catch (\Illuminate\Database\QueryException $e) {
            DB::rollBack();
            return back()->with('error', $e->getMessage())->withInput();
        }
        return redirect()->route('admin.dashboard')->with('success', 'Your profile has been updated successfully');
    }
}
