<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MessageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $response = Gate::inspect('check-user', "enquries-index");
        // if (!$response->allowed()) {
        //     return redirect()->route('admin.dashboard', app('request')->query())->with('error', $response->message());
        // }
        return view('Admin.messages.index');
    }
}
