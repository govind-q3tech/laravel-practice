<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Discussion;
use App\Models\DiscussionMessage;
use Auth, Session, Validator;
use Illuminate\Support\Facades\DB;
use App\Models\EventNotification;


class MessageController extends Controller
{
    public function index($id = false)
    {

        $authID = Auth::user()->id;
        $discussionChat = '';
        $discussion = Discussion::with(
            [
                'discussionMsg',
                'advertisement:id,title,slug,user_id',
                'sender:id,first_name,profile_picture',
                'receiver:id,first_name,profile_picture'
            ]
        )
            ->distinct('advertisement_id')
            ->orWhere(['receiver_id' => $authID, 'sender_id' => $authID])
            ->orderBy('created_at', 'DESC')->get();

        if ($id > 0 && \Request::route()->getName() == "frontend.chat") {
            $discussionChat = Discussion::with([
                'discussionMsg', 'advertisement:id,title,slug,user_id', 'sender:id,first_name,profile_picture',
                'receiver:id,first_name,profile_picture'
            ])
                ->distinct('advertisement_id')
                ->orWhere(['receiver_id' => $authID, 'sender_id' => $authID])
                ->orderBy('created_at', 'DESC')->where(['id' => $id])->first();
        }
        return view('message.index', compact('discussion', 'discussionChat'));
    }
    /**
     * Stroe chat in db .
     *
     * @param  Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function send(Request $request)
    {
        try {
            $requestData    = [];
            if (!empty($request->all())) {
                $chat                   = new Discussion;
                $chat->receiver_id      = $request->receiver_id;
                $chat->sender_id        = $request->sender_id;
                $chat->advertisement_id   = $request->advertisement_id;
                $chat->status             = 1;
                if ($chat->save()) {
                    $chatHistory                   = new DiscussionMessage;
                    $chatHistory->receiver_id      = $request->receiver_id;
                    $chatHistory->discussion_id      = $chat->id;
                    $chatHistory->sender_id        = $request->sender_id;
                    $chatHistory->message               = $request->message;
                    $chatHistory->save();

                    $notification_status = config('constants.NOTIFICATION_LIST');
                    $event_notification_user = [
                        'sender_id'     => $request->receiver_id,
                        'sender_type'   => 'U',
                        'receiver_id'   => $request->receiver_id,
                        'receiver_type' => 'U',
                        'advertisement_id' => $request->advertisement_id,
                        'events'        => 'J',
                        'message'       => $notification_status['J']['message'],
                        'is_read'       => 0,
                    ];
                    EventNotification::create($event_notification_user);

                    return response()->json(["status" => true, 'message' => 'Message Sent Successfully.']);
                }
            }
        } catch (\Exception $e) {
            return response()->json(["status" => false]);
        }
    }

    /**
     * Stroe chat in db .
     *
     * @param  Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function sendChat(Request $request)
    {
        // echo "<pre>";
        // print_r($request->all());
        // exit;
        try {
            $requestData    = [];
            $html = '';
            if (!empty($request->all())) {
                $count = ($request->hasFile('attachment')) ? count($request->file('attachment'))  : 0;

                /*For message only*/
                if ($count == 0) {
                    $chatHistory                    = new DiscussionMessage;
                    $chatHistory->receiver_id       = $request->receiver_id;
                    $chatHistory->discussion_id     = $request->discussion_id;
                    $chatHistory->sender_id         = $request->sender_id;
                    $chatHistory->message           = $request->message;
                    $chatHistory->save();
                }
                /*For message with multiple attach only*/
                if ($count > 0) {
                    if ($request->hasFile('attachment')) {
                        $chatHistory                    = new DiscussionMessage;
                        $chatHistory->receiver_id       = $request->receiver_id;
                        $chatHistory->discussion_id     = $request->discussion_id;
                        $chatHistory->sender_id         = $request->sender_id;
                        $chatHistory->message           = $request->message;
                        $attached = [];
                        foreach ($request->file('attachment') as $key => $file) {
                            $filename = random_int(1000, 9999) . time() . '.' . $file->guessExtension();
                            $path = $file->storeAs(
                                'public/discussion',
                                $filename
                            );
                            $attached[] = $filename;
                        }
                        $chatHistory->attachment  = json_encode($attached);
                        $chatHistory->save();
                    }
                }

                if (!empty($request->all())) {
                    $discussionChat = DiscussionMessage::with(
                        [
                            'discussion', 'discussion.advertisement:id,title,slug,user_id',
                            'senderChat:id,first_name,profile_picture',
                            'receiverChat:id,first_name,profile_picture'
                        ]
                    )
                        ->distinct('advertisement_id')
                        ->where(['discussion_id' => $request->discussion_id])
                        ->orderBy('created_at', 'ASC')->get();

                    // echo "<pre>"; print_r($discussionChat->toArray()); exit;
                    if ($discussionChat) {
                        foreach ($discussionChat as $key => $discussionVal) {
                            $sender_id = $discussionVal->sender_id;
                            $imageSenderpath = !empty($discussionVal->senderChat->profile_picture) ? asset('storage/profile_pictures/' . $discussionVal->senderChat->profile_picture) : asset('img/no-image.png');
                            $html .= '<div class="" id="inbox-message-' . ($key + 1) . '">';
                            if (Auth::user()->id == $sender_id) {
                                $html .= '<div class="send-message">';
                                $html .= '<div class="send-area">';
                                $html .= '<div class="send-message-txt">';
                                $html .= '<div class="text-message">';
                                $html .= $discussionVal->message;
                                $html .= '<div class="text-right posted-img">';
                                if (!empty($discussionVal->attachment)) {
                                    $attachmentArray = json_decode($discussionVal->attachment, true);
                                    if (!empty($attachmentArray)) {
                                        foreach ($attachmentArray as $aKey => $aAttachment) {
                                            $ext = pathinfo(asset('storage/discussion/' . $aAttachment), PATHINFO_EXTENSION);
                                            if ($aAttachment != '' && ($ext) && ($ext == "jpg" || $ext == "jpeg" || $ext == "png")) {
                                                $html .= '<a target="_blank" href="' . asset('storage/discussion/' . $aAttachment) . '">';
                                                $html .= '<img src="' . \App\Helpers\Helper::imageUrlTimThumb(asset('storage/discussion/' . $aAttachment), '100', '100', 100) . '" alt="" style="wideth:100px;height:100px" class="">&nbsp;';
                                                $html .= '</a>';
                                            } elseif ($aAttachment != '' && ($ext) && ($ext == "gif")) {
                                                $html .= '<a target="_blank" href="' . asset('storage/discussion/' . $aAttachment) . '">';
                                                $html .= '<img src="' . asset('storage/discussion/' . $aAttachment) . '" alt="" style="wideth:100px;height:100px" class="">&nbsp;';
                                                $html .= '</a>';
                                            } elseif ($aAttachment != '' && ($ext) &&  ($ext == "pdf" || $ext == "doc" || $ext == "docx" || $ext == "txt")) {
                                                $html .= '<a target="_blank" href="' . asset('storage/discussion/' . $aAttachment) . '"><i class="fa fa-file"> </i></a>&nbsp;';
                                            }
                                        }
                                    }
                                }
                                $html .= '</div>';
                                $html .= '</div>';
                                $html .= '<div class="userimage"><img src="' . $imageSenderpath . '" alt="" style="width:44px;height:44px" class=" rounded-circle"></div>';
                                $html .= '</div>';
                                $html .= '<div class="message-time text-right">' . @$discussionVal->created_at->diffForHumans() . '</div>';
                                $html .= '</div>';
                                $html .= '</div>';
                            } else {
                                $html .= '<div class="reply-message">';
                                $html .= '<div class="reply-area">';
                                $html .= '<div class="reply-message-txt">';
                                $html .= '<div class="text-message">';
                                $html .= $discussionVal->message;
                                $html .= '<div class="text-left posted-img">';
                                if (!empty($discussionVal->attachment)) {
                                    $attachmentArray = json_decode($discussionVal->attachment, true);
                                    if (!empty($attachmentArray)) {
                                        foreach ($attachmentArray as $aKey => $aAttachment) {
                                            $ext = pathinfo(asset('storage/discussion/' . $aAttachment), PATHINFO_EXTENSION);
                                            if ($aAttachment != '' && ($ext) && ($ext == "jpg" || $ext == "jpeg" || $ext == "png")) {
                                                $html .= '<a target="_blank" href="' . asset('storage/discussion/' . $aAttachment) . '">';
                                                $html .= '<img src="' . \App\Helpers\Helper::imageUrlTimThumb(asset('storage/discussion/' . $aAttachment), '100', '100', 100) . '" alt="" style="wideth:100px;height:100px" class="">&nbsp;';
                                                $html .= '</a>';
                                            } elseif ($aAttachment != '' && ($ext) && ($ext == "gif")) {
                                                $html .= '<a target="_blank" href="' . asset('storage/discussion/' . $aAttachment) . '">';
                                                $html .= '<img src="' . asset('storage/discussion/' . $aAttachment) . '" alt="" style="wideth:100px;height:100px" class="">&nbsp;';
                                                $html .= '</a>';
                                            } elseif ($aAttachment != '' && ($ext) &&  ($ext == "pdf" || $ext == "doc" || $ext == "docx" || $ext == "txt")) {
                                                $html .= '<a target="_blank" href="' . asset('storage/discussion/' . $aAttachment) . '"><i class="fa fa-file"> </i></a>&nbsp;';
                                            }
                                        }
                                    }
                                }
                                $html .= '</div>';
                                $html .= '</div>';
                                $html .= '<div class="userimage"><img src="' . $imageSenderpath . '" style="width:44px;height:44px" alt="" class=" rounded-circle"></div>';
                                $html .= '</div>';
                                $html .= '<div class="message-time text-left">' . @$discussionVal->created_at->diffForHumans() . '</div>';
                                $html .= '</div>';
                                $html .= '</div>';
                            }

                            $html .= '</div>';
                        }

                        $html .= '</div>';
                    }
                }
            }
            return response()->json(["status" => true, 'message' => 'Message Sent Successfully.', 'html' => $html]);
        } catch (\Exception $e) {
            return response()->json(["status" => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Display news detail view.
     *
     * @param  Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function ajaxload(Request $request, $id)
    {
        $user       = Auth::user();
        $user_id    = $user->id;
        $messages   = [];
        $html = '';
        $discussionChat = DiscussionMessage::with(
            [
                'discussion', 'discussion.advertisement:id,title,slug,user_id',
                'senderChat:id,first_name,profile_picture',
                'receiverChat:id,first_name,profile_picture'
            ]
        )
            ->distinct('advertisement_id')
            ->where(['discussion_id' => $request->discussion_id])
            ->orderBy('created_at', 'ASC')->get();
        if ($discussionChat) {
            foreach ($discussionChat as $key => $discussionVal) {
                $sender_id = $discussionVal->sender_id;
                $imageSenderpath = !empty($discussionVal->senderChat->profile_picture) ? asset('storage/profile_pictures/' . $discussionVal->senderChat->profile_picture) : asset('img/no-image.png');

                $html .= '<div  class="chating-area" id="inbox-message-' . ($key + 1) . '">';
                if (Auth::user()->id == $sender_id) {
                    $html .= '<div class="send-message"><div class="send-area"><div class="send-message-txt">' . $discussionVal->message . '<div class="userimage"><img src="' . $imageSenderpath . '" alt="" style="width:44px;height:44px" class=" rounded-circle"></div></div>';
                    $html .= '<div class="message-time text-right">' . date("H:i A", strtotime(@$discussionVal->created_at)) . '</div>
                        </div>';
                } else {
                    $html .= '<div class="reply-message"><div class="reply-area"><div class="reply-message-txt">' . $discussionVal->message . '<div class="userimage"><img src="' . $imageSenderpath . '" style="width:44px;height:44px" alt="" class=" rounded-circle"></div></div>';
                    $html .= '<div class="message-time text-left">' . date("H:i A", strtotime(@$discussionVal->created_at)) . '</div>
                        </div>';
                }

                $html .= '</div>';
            }
        }
        return response()->json(["status" => true, 'message' => 'Get Chat Successfully.', 'html' => $html]);
    }
}
