<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Claim;

use Response;

class ClaimsController extends Controller
{
        //
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $requestedData = $request->all();
        $user_review = Claim::create($requestedData);
        $data = ['status'=>true, 'data'=>$requestedData];

        return Response::json($data);
    }
}
