<?php

namespace App\Http\Controllers;

use App\Models\Location;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Models\BusinessCategory;
use App\Models\Advertisement;
use App\Models\Page;
use App\Models\Gallery;
use Storage;
use GuzzleHttp\Client;

class HomeController extends Controller
{

  /**
   * Show the home page data.
   *
   */
  public function home()
  {

    
    $homeContent = Page::where("slug", "home")->first();
    $categories = BusinessCategory::where('parent_id', '0')->status()->with('children', function ($q) {
      $q->withCount(['advertisements' => function ($q) {
        $q->status(1);
      }]);
    })->withCount(['main_advertisements' => function ($q) {
      $q->status(1);
    }])->get();
    $banners = Gallery::with('images')->active()->get();
    $featureAds = Advertisement::feature()->where('is_featured', '1')->where('is_publish', '1')->where('admin_approve', '1')->get();
    $tradingAds = Advertisement::feature()->get();
    return view('homepage', compact('homeContent', 'categories', 'banners', 'featureAds', 'tradingAds'));
  }

  /**
   * Show the advertise page data.
   *
   */
  public function advertise(Request $request)
  {

    if (Auth::check()) {
      return redirect(route('user.subscription'));
    }
    $planDuration = ['1' => 'Monthly', '2' => 'Yearly'];
    $planDurationShort = ['1' => 'mo', '2' => 'yr'];
    $planType = ['1' => 'Build Partner', '2' => 'Land Partner'];
    $stripe_publisher_key = config('get.STRIPE_PUBLISHER_KEY');
    $user_data  = auth()->user();

    $all_plans = Plan::where("status", 1)->with('plan_features')->where("status", 1)->orderBy("plan_icon", "desc")->get();
    //   dd($all_plans);

    return view('home.advertise', compact("all_plans"));
  }
  public function couponstatus(Request $request)
  {
    $data['status'] = 0;
    $currentdate = date('Y-m-d');
    $voucherisexist = Voucher::where("vouchercode", $request->codes)->where("from_date", "<=", $currentdate)->where("to_date", ">=", $currentdate)->first();

    if (isset($voucherisexist->id)) {
      $data['status'] = 1;
    }
    return $data;
  }

  public function sitemapxml()
  {
    $myLocationFooter = \App\Helpers\Helper::getLocationFooter();
    $myCategoryFooter = \App\Helpers\Helper::getCategoryFooter();
    $locationdata = Location::status()->where('type', '>', -1)->get();
    $filecontent =  view('sitemap', ['myLocationFooter' => $myLocationFooter, 'myCategoryFooter' => $myCategoryFooter, 'locationdata' => $locationdata,])->render();
    Storage::disk('local')->put('sitemaps.xml', $filecontent);
    $file = storage_path('app/sitemaps.xml');
    $headers = array(
      'Content-Type: text/xml',
    );
    return response()->download($file, 'sitemap.xml', $headers);
  }

  public function checkGuzzle() 
  {
    try {
      // $client = new Client();
      //   // $res = $client->request('GET', 'https://www.google.com/');
      // $client = new \GuzzleHttp\Client([
      //     'base_uri' => 'http://127.0.0.1:8001',
      //     'defaults' => [
      //       'exceptions' => false
      //     ]
      // ]);
      // // $response = $client->request('GET', 'http://127.0.0.1:8001/api/users/register');
      // $response = $client->request('POST', '/api/users/check', [
      //   'headers' => [
      //     'Accept'     => 'application/json',
      //   ],
      //   'name' => 'Govind',
      //   // 'allow_redirects' => false
      // ]);
      $targetUrl = 'http://127.0.0.1:8000/api/users/check/';
      // $targetUrl = 'https://www.google.com/';

      $client = new Client();
      $request = $client->get($targetUrl);
      $response = $request->getBody()->getContents();
      // print_r($response);


      // $ch = curl_init();
      // curl_setopt($ch, CURLOPT_URL,$targetUrl);
      // curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      // // curl_setopt($ch, CURLOPT_POST,1);
      // // curl_setopt($ch,CURLOPT_POSTFIELDS,['name'=>'Govind']);
      // $response = curl_exec ($ch);
      // curl_close ($ch);
      dd($response);die;
    } catch(\Exception $e) {
      dd($e->getMessage());
    }
  }
}
