<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\HashTag;

class UserHashTagController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $hashtags = HashTag::where('user_id',auth()->user()->id)->orderByDesc('id')->paginate(10);
        return view('hashtags.index', compact('hashtags'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate(['title'=> 'required|regex:/^[a-zA-Z]+$/u|min:2|max:100|unique:hash_tags,title'],['title:unique'=>'The HashTag is added']);
        try {
            HashTag::create(['title'=>$request->title,'user_id'=>auth()->user()->id]);
            return redirect()->back()->with('success', 'Hash Tag has been save successfully');
        } catch (\Exception $e) {
            dd($e);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate(['title' => 'required|regex:/^[a-zA-Z]+$/u|min:2|max:100|unique:hash_tags,title,' .$id], ['title:unique' => 'The HashTag is added']);
        try {
            HashTag::find($id)->update(['title'=>$request->title]);
            return redirect()->back()->with('success', 'Hash Tag has been updated successfully');
        } catch (\Exception $e) {
            dd($e);
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
               HashTag::find($id)->delete();
            return redirect()->back()->with('success','HashTag has been deleted successfully');
           } catch (\Exception $e) {
               dd($e);
           }   
    }
}
