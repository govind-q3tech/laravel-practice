<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\GalleryRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
//Models
use App\Models\Gallery;
use App\Models\Advertisement;

class GalleriesController extends Controller
{
             /**
     *  Image upload path.
     *
     * @var string
     */
    protected $image_upload_path;

    /**
     * Storage Class Object.
     *
     * @var \Illuminate\Support\Facades\Storage
     */
    protected $storage;

    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->image_upload_path = 'listing/gallery' . DIRECTORY_SEPARATOR;
        $this->storage = Storage::disk('public');
    }



 

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(GalleryRequest $request)
    {
       
        try {
            $requestData = $request->all();
           

            
            $galleryData = [];
            if ($request->hasFile('images')) {
                
                $files = $request->file('images');
               
                foreach($files as $file){
                    $images_name = $this->uploadImage(null, $file);
                    $data['images'] = $images_name;
                    $data['listing_id'] =  $requestData['listing_id'];
                    $galleryData[] = $data;
                }
            }
            
            if(count( $galleryData)){
                 Gallery::insert($galleryData); 
               
            }
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('galleries.show',[$requestData['listing_id']])->with('success', 'Gallery has been saved successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function show($id)
    {
        $gallery = Gallery::where('listing_id',$id)->get();
        
        return view('galleries.show', compact('gallery', 'id'));
    }

  

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(GalleryRequest $request, $id)
    {
        try {
            $gallery = Gallery::findOrFail($id);
            $requestData = $request->all();
            $requestData['status'] = (isset($requestData['status'])) ? 1 : 0;
            if ($request->hasFile('images')) {
                $images_name = $this->uploadImage($gallery, $request->file('images'));
                $requestData['images'] = $images_name;
            }else{
                $requestData['images'] = $gallery->images;
            }
            $gallery->fill($requestData);
            $gallery->save();
            $gallery->locations()->sync($requestData['locations']);
            $gallery->categories()->sync($requestData['categories']);

        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('listings.index')->with('success', 'Gallery has been updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Gallery $gallery)
    {
        // $response = Gate::inspect('lender-delete', $lender);
        // if (!$response->allowed()) {
        //     return ['status' => false, 'message' =>  $response->message()];
        // }

            
            DB::beginTransaction();
            try {
                $gallery->delete();
                DB::commit();
                $responce = ['status' => true, 'message' => 'This image has been deleted successfully.', 'data' => $gallery];
            } catch (\Exception $e) {
                DB::rollBack();
                $responce = ['status' => false, 'message' => $e->getMessage()];
            }
            return $responce;
    }



    public function uploadData($request, $id = NULL){
        try {
            $requestData = $request->all();
           

            
            $galleryData = [];
            if ($request->hasFile('images')) {
                
                $files = $request->file('images');
               
                foreach($files as $file){
                    $images_name = $this->uploadImage(null, $file);
                    $data['images'] = $images_name;
                    $data['listing_id'] =  $id;
                    $galleryData[] = $data;
                }
            }
            
            if(count( $galleryData)){
                 Gallery::insert($galleryData); 
               
            }
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }

    }



    /**
     * Mangage imagess of lisitng.
     *
     * @param  int  $id of gallery
     * @return \Illuminate\Http\Response
     */
    public function gallery($id)
    {
        
    }

     /*
     * upload images
     */
    public function uploadImage($model = null, $image)
    {
        if($model != null) {
            if ($model->images != null) {
                $this->removeBannerImage($model);
            }
        }

        $path = $this->image_upload_path;

        $image_name = time() . $image->getClientOriginalName();

        // dd($path);

        $this->storage->put($this->image_upload_path . $image_name, file_get_contents($image->getRealPath()));

        return $image_name;
    }

    /*
     * remove image
     */
    public function removeBannerImage($model)
    {
        $path = $this->image_upload_path;
        if ($this->storage->exists($path)) {
            $this->storage->delete($path . $model->images);
            return true;
        }

        throw new \Exception(trans('There is some error in processing this request.'));
    }
}
