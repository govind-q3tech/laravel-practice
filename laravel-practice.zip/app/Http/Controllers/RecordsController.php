<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Record;
use Illuminate\Support\Facades\DB;

class RecordsController extends Controller
{
    //
    public function create($listingId = NULL, $type = NULL){      
        \App\Helpers\Helper::saveRecord($listingId, $type);
   }

   public function index(Request $request){
       
       
       $start_date = '';
       $end_date   = '';
       $records = Record::Select(DB::raw('count(id) as `data` , type'))->with("listing.user")->whereHas("listing.user", function ( $query) {
        $query->where('users.id', auth()->user()->id);
        });
        $type  = request('type');
       if(request('type')) {
            $today = date("Y-m-d");
            
            if((request('type')=='range')){
              $start_date  = request('start_date');
              $end_date    = request('end_date');  
            }else if(request('type')=='last week'){
               $start_date  = date('Y-m-d', strtotime($today . ' - 8 days'));
               $end_date    = date('Y-m-d', strtotime($today . ' - 1 days')); 
              
            }else if(request('type')=='last month'){

               $start_date = Date("Y-F-d", strtotime("first day of previous month")); 
               $end_date   = Date("Y-F-d", strtotime("last day of previous month"));
                   
            }else if(request('type')=='date'){
              $start_date  = request('start_date');
              $end_date    = request('start_date'); 
            }
            
            $start_dates = date("Y-m-d", strtotime($start_date)) . ' 00:00:00';
            $end_dates   = date("Y-m-d", strtotime($end_date)) . ' 23:59:59';
            $records     = $records->whereDate('created_at', '>=', $start_dates)->whereDate('created_at', '<=', $end_dates);
            
       }

        $records    = $records->groupBy("type")->get();
        $recordType = [];
        foreach($records as $record){
            $recordType[$record->type] = $record->data;
        }
         
        return view('records.index',compact('recordType','start_date','end_date','type'));        
   }   
    


}
