<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Rules\MatchOldPassword;
use App\Rules\CheckEmail;
use Illuminate\Contracts\Auth\StatefulGuard;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use App\Models\User;
use App\Models\Advertisement;
use App\Services\ApiService;
use DB, Auth, Validator, Session;

class UsersController extends Controller
{

    /**
     * The guard implementation.
     *
     * @var \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected $guard;

    /**
     * Create a new controller instance.
     *
     * @param  \Illuminate\Contracts\Auth\StatefulGuard  $guard
     * @return void
     */
    public function __construct(StatefulGuard $guard)
    {
        $this->guard = $guard;
    }

    /*
    *
    1 => Active
    2 => Reviewing
    3 => Declined
    0 => Draft
    4 => Closed
    */

    public function dashbaord(Request $request, $type = 'ad-active')
    {
        $user = Auth::user();
        $planFeatures = \App\Helpers\Helper::getPlanData();
        // dd($planFeatures);
        $advertisements = $this->getAds($type);
        // dd($advertisements);
        if ($request->ajax()) {
            $html = '';
            $html .= view('advertisements.user-list', compact('advertisements'))->render();
            return $html;
        }
        /*Advertisement Counts*/
        $countData = [];
        $countData['all'] = Advertisement::isuser()->count();
        $countData['active'] = Advertisement::isuser()->status(1)->count();
        $countData['reviewing'] = Advertisement::isuser()->status(2)->count();
        $countData['declined'] = Advertisement::isuser()->status(3)->count();
        $countData['draft'] = Advertisement::isuser()->status(0)->count();
        $countData['closed'] = Advertisement::isuser()->status(4)->count();

        if ($user->email_verified_at == null) {
            return redirect()->route('verification.notice');
        } else {
            return view('users.dashboard', compact('advertisements', 'countData', 'type'));
        }
    }

    private function getAds($type)
    {
        $user = Auth::user();

        $adsQuery = Advertisement::with([
            'advertisement_images',
            'location.area' => function ($q) {
                $q->select('id', 'title', 'city_id');
            },
            'location.area.city' => function ($q) {
                $q->select('id', 'title');
            },
            'location.area.city' => function ($q) {
                $q->select('id', 'title');
            },
            'sub_business_category' => function ($q) {
                $q->select('id', 'title', 'parent_id');
            },
            'sub_business_category.parent' => function ($q) {
                $q->select('id', 'title');
            }
        ]);
        if ($type == 'ad-active') {
            $adsQuery->status(1);
        } elseif ($type == 'ad-reviewing') {
            $adsQuery->status(2);
        } elseif ($type == 'ad-declined') {
            $adsQuery->status(3);
        } elseif ($type == 'ad-closed') {
            $adsQuery->status(4);
        } elseif ($type == 'ad-draft') {
            $adsQuery->status(0);
        }
        $adsQuery->where("user_id", $user->id);

        $advertisements = $adsQuery->orderBy('id', 'DESC')->paginate(config('get.FRONT_PAGE_LIMIT'));

        // $advertisements = $adsQuery->skip($start)->take(config('get.FRONT_PAGE_LIMIT'))->get();
        return $advertisements;
    }

    public function sendOtp(Request $request)
    {
        $messageStatus = \App\Helpers\Helper::sendOtp(7894561230, 123456);
        dd($messageStatus);
    }

    public function sendOtpVerify(Request $request)
    {
        try {
            $user = Auth::user();
            $data = [];
            switch ($request->action) {
                case "send_otp":
                    if (!empty($user)) {
                        $validator = Validator::make($request->all(), [
                            'mobile_number' =>  'required|numeric|unique:users,phone,' . $user->id,
                        ]);
                    } else {
                        $validator = Validator::make($request->all(), [
                            'mobile_number' =>  'required|numeric|unique:users,phone',
                        ]);
                    }
                    if ($validator->fails()) {
                        $errors = $validator->messages();
                        $data['status'] = 0;
                        $data['message'] = $errors->first('mobile_number');
                        echo json_encode($data);
                        exit;
                    }
                    $mobile_number = $request->mobile_number;
                    // $apiKey = urlencode('YOUR_API_KEY');
                    // $Textlocal = new Textlocal(false, false, $apiKey);
                    $numbers = array(
                        $mobile_number
                    );
                    $sender = 'PHPPOT';
                    //$otp = rand(100000, 999999);
                    $otp = 123456;
                    Session::put('mobile_number', $mobile_number);
                    Session::put('session_otp', $otp);
                    $message = "Your One Time Password is " . $otp;
                    try {
                        //$response = $Textlocal->sendSms($numbers, $message, $sender);
                        //require_once ("verification-form.php");
                        $data['status'] = 1;
                        $data['message'] = "OTP send Successfully";
                        echo json_encode($data);
                    } catch (Exception $e) {
                        $data['status'] = 0;
                        $data['message'] = 'Error: ' . $e->getMessage();
                        echo json_encode($data);
                    }
                    break;
                case "resend_otp":
                    $validator = Validator::make($request->all(), [
                        'mobile_number' =>  'required|numeric|unique:users,phone',
                    ]);
                    if ($validator->fails()) {
                        $errors = $validator->messages();
                        $data['status'] = 0;
                        $data['message'] = $errors->first('mobile_number');
                        echo json_encode($data);
                    }
                    $mobile_number = $request->mobile_number;
                    // $apiKey = urlencode('YOUR_API_KEY');
                    // $Textlocal = new Textlocal(false, false, $apiKey);
                    $numbers = array(
                        $mobile_number
                    );
                    $sender = 'PHPPOT';
                    //$otp = rand(100000, 999999);
                    $otp = 123456;
                    Session::put('mobile_number', $mobile_number);
                    Session::put('session_otp', $otp);
                    $message = "Your One Time Password is " . $otp;
                    try {
                        //$response = $Textlocal->sendSms($numbers, $message, $sender);
                        //require_once ("verification-form.php");
                        $data['status'] = 1;
                        $data['message'] = "OTP send Successfully";
                        echo json_encode($data);
                    } catch (Exception $e) {
                        $data['status'] = 0;
                        $data['message'] = 'Error: ' . $e->getMessage();
                        echo json_encode($data);
                    }
                    break;
                case "verify_otp":
                    $otp = $request->otp;
                    //$request()->session()->get('session_otp')
                    $value = Session::get('session_otp');
                    // $value = 123456;
                    if ($otp == $value) {
                        Session::put('OTPVerified', true);
                        // dd(Session::all());
                        //$request()->session()->forget('session_otp');
                        $data['status'] = 1;
                        $data['message'] = "Your mobile number is verified!";
                        echo json_encode($data);
                    } else {
                        $data['status'] = 0;
                        $data['message'] = "Mobile number verification failed";
                        echo json_encode($data);
                    }
                    break;
            }
        } catch (\Exception $e) {
            return back()->withError($e->getMessage())->withInput();
        }
    }


    public function forgotPassword(Request $request)
    {
        try {
            $request->validate([
                'email' =>  ['required', 'email', new CheckEmail],
            ]);
            $user = User::whereEmail($request->email)->first();
            $user->sendRegEmail($user);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->with('error', $e->getMessage())->withInput();
        }
        return redirect()->route('frontend.login')->with('success', 'Reset Password link has been sent on email.');
    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function changePassword()
    {
        return view('profile.change-password');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function updatePassword(Request $request)
    {
        try {
            $request->validate([
                'current_password' => ['required', new MatchOldPassword],
                'new_password' => ['required', 'different:current_password'],
                'new_confirm_password' => ['same:new_password'],
            ]);
            User::find(Auth::user()->id)->update(['password' => Hash::make($request->new_password)]);
            Auth::guard('web')->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            // dd(Auth::user()->id);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('frontend.login')->with('success', 'Password change successfully.');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @param  string  $hash
     * @return \Illuminate\Http\Response
     */
    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function verifyAccount(Request $request, $id, $hash)
    {
        $data = [];
        $requestData = [];
        try {
            $user = User::findOrFail($id);
            if (!empty($user->email_verified_at)) {
                $data['status'] = false;
                $data['message'] = 'User Already Verified';
                return redirect()->route('frontend.login')->with('success', 'User Already Verified.');
            } else {
                $usersVer = DB::table('user_verifications')->where(['user_id' => $id, 'verification_code' => $hash])->first();
                if (!empty($usersVer)) {
                    if (empty($user->email_verified_at)) {
                        $requestData['email_verified_at'] = time();
                    }
                    $user->fill($requestData);
                    $user->save();
                    DB::table('user_verifications')->where(['user_id' => $id, 'verification_code' => $hash])->delete();
                    $data['status'] = true;
                    $data['message'] = 'User Verified Successfully';
                    return redirect()->route('frontend.login')->with('success', 'User Verified Successfully!');
                } else {
                    $data['status'] = false;
                    $data['message'] = 'Invalid Verification link';
                    return redirect()->route('frontend.login')->with('success', 'Invalid Verification link!');
                }
            }
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        // return view('users.verify', compact('data'));
    }

    public function checkemail(Request $request)
    {
        $success = true;
        $email = User::where('email', $request->input('email'));
        if ($request->has('id'))
            $email = $email->where('id', '!=', $request->input('id'));
        $email = $email->first();
        if ($email && isset($email->id))
            $success = false;
        return response()->json($success);
    }
}
