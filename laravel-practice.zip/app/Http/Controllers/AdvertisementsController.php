<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\ListingRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\App;
use App\Helpers\Helper;
use Illuminate\Support\Str;
use Mail;
//Models
use App\Models\Advertisement;
use App\Models\Location;
use App\Models\User;
use App\Models\BusinessCategory;
use App\Models\Attribute;
use App\Models\AttributeOption;
use App\Models\AdvertisementAttribute;
use App\Models\AdvertisementImage;
use App\Models\UserReview;
use App\Models\UserWishlist;
use Auth, Session, Validator;
use App\Models\Discussion;
use App\Models\City;
use App\Models\Area;
use App\Models\HashTag;
use App\Models\AdvertisementHashtag;
use App\Models\EventNotification;
use App\Models\Membership\Subscription;
use Illuminate\Support\Facades\Route;
use App\Models\Setting;

class AdvertisementsController extends Controller
{

    /**
     *  Image upload path.
     *
     * @var string
     */
    protected $image_upload_path;

    /**
     * Storage Class Object.
     *
     * @var \Illuminate\Support\Facades\Storage
     */
    protected $storage;

    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->storage = Storage::disk('public');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function createStepOne(Request $request)
    {
        if (Route::currentRouteName() == 'frontend.advertisements.create-step-one') {
            // dd('test');
            Session::forget('first_step');
        }
        $user = auth()->user();
        // $planFeatures = \App\Helpers\Helper::getPlanData();
        // $countDataActive = Advertisement::isuser()->status(1)->count();die;
        // if($countDataActive == $planFeatures['number_ads']){
        // }
        // dd(session('first_step'));
        $locationData = $this->getLocations();
        //Check Active Plan
        $active_plan_categories =  Subscription::where(['user_id' => Auth::user()->id, 'status' => 1])
            ->whereDate('start_date', '<=', date("Y-m-d"))
            ->whereDate('end_date', '>=', date("Y-m-d"))
            // ->with('plans.plan_features')
            ->pluck('category_id')->toArray();
        // dd($active_plan_categories);
        // $cities = City::whereHas('areas.location')->where('country_id', 110)
        // ->where('status', 1)
        // ->pluck('title', 'id');
        $cities = City::whereHas('areas')->where('country_id', 110)
            ->where('status', 1)
            ->pluck('title', 'id');
        if (session('first_step') && session('first_step')['city_id']) {
            // $areas = Area::whereHas('location')->where('status', 1)->where('city_id', session('first_step')['city_id'])
            //     ->pluck('title', 'id');
            $areas = Area::where('status', 1)->where('city_id', session('first_step')['city_id'])
                ->pluck('title', 'id');
        } else {
            $areas = [];
        }

        if (session('first_step') && session('first_step')['area_id']) {
            $locations = Location::where('status', 1)->where('area_id', session('first_step')['area_id'])
                ->pluck('title', 'id');
        } else {
            $locations = [];
        }

        $categories = BusinessCategory::whereIn('id', $active_plan_categories)->where('parent_id', '0')->whereHas('children')
            ->status(1)
            ->pluck('title', 'id');            
        if (session('first_step') && session('first_step')['business_category_id']) {
            $sub_categories = BusinessCategory::where('parent_id', session('first_step')['business_category_id'])->status(1)
                ->pluck('title', 'id');
        } else {
            $sub_categories = [];
        }

        if (session('first_step') && session('first_step')['uploadedImages']) {
            // dd(session('first_step')['uploadedImages']);
            $auctionImages = [];
            if (session('first_step')['uploadedImages'] > 0) {
                foreach (session('first_step')['uploadedImages'] as $keyImage => $advertisement_image) {
                    $auctionImages[$keyImage]['Url'] = asset('storage/advertisements/' . $advertisement_image);
                    $auctionImages[$keyImage]['Name'] = $advertisement_image;
                }
            }
            // dd($auctionImages);

        } else {
            $auctionImages = [];
        }

        return view('advertisements.createStepOne', compact('locationData', 'categories', 'sub_categories', 'cities', 'areas', 'auctionImages', 'locations'));
    }

    public function getAreas(Request $request)
    {
        // $areas = Area::where('status',1)->get();
        // $data = Area::whereHas('location')->where("city_id", $request->city_id)->status(1)
        //     ->pluck('title', 'id');
        $data = Area::where("city_id", $request->city_id)->status(1)
            ->pluck('title', 'id');
        return response()
            ->json($data);
    }
    public function getHashtags(Request $request)
    {
        $data = [];
        if ($request->has('q')) {
            $search = $request->q;
            $data = HashTag::select("id", "title")->where('title', 'LIKE', "%$search%")->get();
        }
        return response()
            ->json($data);
    }

    public function getLocationsAjax(Request $request)
    {
        $data = Location::where("area_id", $request->area_id)->status(1)
            ->pluck('title', 'id');
        return response()
            ->json($data);
    }

    private function getLocations()
    {
        $locations = Location::with('area', 'area.city')->status(1)->get();
        $locationData = [];
        if (!empty($locations)) {
            foreach ($locations as $location) {
                $title = '';
                $title .= $location->title;
                if (!empty($location->area)) {
                    $title .= ' - ' . $location->area->title;
                    if (!empty($location->area->city)) {
                        $title .= ' - ' . $location->area->city->title;
                    }
                }
                $locationData[$location->id] = $title;
            }
        }
        return $locationData;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function storeStepOne(Request $request)
    {
        try {
            $requestData = $request->all();
            $storeData = [];
            if (!empty($request->uploaded_images)) {
                $storeData['uploadedImages'] = $this->uploadImage($request->uploaded_images);
            }
            $storeData['business_category_id'] = !empty($requestData['business_category_id']) ? $requestData['business_category_id'] : '';
            $storeData['sub_business_category_id'] = !empty($requestData['sub_business_category_id']) ? $requestData['sub_business_category_id'] : '';
            $storeData['location_id'] = !empty($requestData['location_id']) ? $requestData['location_id'] : '';
            $storeData['city_id'] = !empty($requestData['city_id']) ? $requestData['city_id'] : '';
            $storeData['area_id'] = !empty($requestData['area_id']) ? $requestData['area_id'] : '';
            Session::put('first_step', $storeData);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())
                ->withInput();
        }
        return redirect()
            ->route('frontend.advertisements.create-step-two');
        // ->with('success', 'Please complete the second step for complete advertisement');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function createStepTwo(Request $request)
    {
        $user = auth()->user();
        $business_category_id = '';
        $sub_business_category_id = '';
        if ($request->session()
            ->has('first_step')
        ) {
            $first_step = Session::get('first_step');
            $business_category_id = $first_step['business_category_id'];
            $sub_business_category_id = $first_step['sub_business_category_id'];
        } else {
            return redirect()->route('frontend.advertisements.create-step-one');
        }

        $selectedMainCategory = BusinessCategory::where('id', $business_category_id)->status(1)
            ->first();
        $selectedCategory = BusinessCategory::with('parent')->where('id', $sub_business_category_id)->status(1)
        ->first();
        $attributes = $this->getAttributes($business_category_id);
        // dd($attributes);
        return view('advertisements.createStepTwo', compact('selectedCategory', 'attributes', 'selectedMainCategory'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function storeStepTwo(Request $request)
    {
        // dd($request->all());
        $rules = [];
        $business_category_id = '';
        $sub_business_category_id = '';
        if ($request->session()
            ->has('first_step')
        ) {
            $first_step = Session::get('first_step');
            $business_category_id = $first_step['business_category_id'];
            $sub_business_category_id = $first_step['sub_business_category_id'];
        } else {
            return redirect()->route('frontend.advertisements.create-step-one')->with('error', 'Please submit required fields');;
        }
        $checkPostCount = \App\Helpers\Helper::checkPlanFeaturesStatus(auth()->user()->id, $first_step['business_category_id'], 1);
        // dd($checkPostCount->value);
        if (Advertisement::where('user_id', auth()->user()->id)->where('business_category_id', $first_step['business_category_id'])->count() == $checkPostCount->value) {
            return redirect()->route('frontend.dashboard')->with('error', 'You already reach the ads posting limit, please check the selected plan features');;
        }
        // dd(Advertisement::where('user_id', auth()->user()->id)->where('business_category_id', $first_step['business_category_id'])->count(), $checkPostCount->value);
        // else{
        //     dd('false');
        // }
        $attributes = $this->getAttributes($business_category_id);
        $rules['title'] = 'required|regex:/^[\pL\s\-]+$/u';
        $rules['description'] = 'required';
        $rules['hashtags'] = 'required';
        $rules['matches.*'] = 'required';
        if ($attributes->count() > 0) {
            foreach ($attributes as $attribute) {
                if ($attribute->requried) {
                    $rules['attribute_' . $attribute->id] = 'required';
                }
            }
        }

        try {
            $validator = Validator::make($request->all(), $rules);
            $requestData = $request->all();
            $attributeDatas = [];
            $adsData = [];
            foreach ($requestData as $reqKey => $reqData) {
                if (strpos($reqKey, 'attribute_') !== false) {
                    $attr_id = explode("_", $reqKey);
                    $attributeDatas[$attr_id[1]] = $reqData;
                } else {
                    $adsData[$reqKey] = $reqData;
                }
            }
            // dd($attributeDatas);
            $storeData['user_id'] = auth()->user()->id;
            $storeData['business_category_id'] = !empty($first_step['business_category_id']) ? $first_step['business_category_id'] : '';;
            $storeData['sub_business_category_id'] = !empty($first_step['sub_business_category_id']) ? $first_step['sub_business_category_id'] : '';
            if (!empty($first_step['location_id'])) {
                $location_id = $first_step['location_id'];
                $location = Location::with([
                    'area' => function ($q) {
                        $q->select('id', 'city_id');
                    }
                ])
                    ->where('id', $location_id)->first();
                if ($location->area) {
                    $area_id = $location
                        ->area->id;
                    $city_id = $location
                        ->area->city_id;
                } else {
                    $area_id = '';
                    $city_id = '';
                }
            } else {
                $location_id = '';
                $area_id = '';
                $city_id = '';
            }

            // dd($first_step);
            $storeData['location_id'] = $first_step['location_id'];
            $storeData['area_id'] = $first_step['area_id'];
            $storeData['city_id'] = $first_step['city_id'];
            $storeData['title'] = $adsData['title'];
            $storeData['description'] = $adsData['description'];
            $storeData['price_type'] = $adsData['radio_payment'];
            // $storeData['hashtag'] = $adsData['hashtag'];
            if ($adsData['radio_payment'] == 1) {
                $priceRange = explode(";", $adsData['rangePrimary']);
                $minPrice = $priceRange[0];
                $maxPrice = $priceRange[1];
                $storeData['min_price'] = $minPrice;
                $storeData['max_price'] = $maxPrice;
                $storeData['fixed_price'] = $maxPrice;
            } else {
                $storeData['fixed_price'] = $adsData['fixed_price'];
            }

            // dd($uploaded_images);
            $advertisement = Advertisement::create($storeData);
            $notification_status = config('constants.NOTIFICATION_LIST');

            //event notification and email
            if ($advertisement) {
                $event_notification_admin = [
                    'sender_id'     => auth()->user()->id,
                    'sender_type'   => 'U',
                    'receiver_id'   => 1,
                    'receiver_type' => 'A',
                    'advertisement_id' => $advertisement->id,
                    'events'        => 'A',
                    'message'       => $notification_status['F']['message'],
                    'is_read'       => 0,
                ];
                $event_notification_user = [
                    'sender_id'     => 1,
                    'sender_type'   => 'A',
                    'receiver_id'   => auth()->user()->id,
                    'receiver_type' => 'U',
                    'advertisement_id' => $advertisement->id,
                    'events'        => 'B',
                    'message'       => $notification_status['E']['message'],
                    'is_read'       => 0,
                ];
                EventNotification::create($event_notification_admin);
                EventNotification::create($event_notification_user);
            }
            if (!empty($first_step['uploadedImages'])) {
                $uploaded_images = $first_step['uploadedImages'];
                $uploadedImagesObj = [];
                foreach ($uploaded_images as $imageKey => $imageValue) {
                    $adImage = [];
                    $adImage['image_name'] = (string)$imageValue;
                    $adImage['main'] = $imageKey == 0 ? 1 : 0;
                    $uploadedImagesObj[] = new AdvertisementImage($adImage);
                }
                if (!empty($uploadedImagesObj)) {
                    $advertisement->advertisement_images()
                        ->saveMany($uploadedImagesObj);
                }
            }
            if ($request->hashtags) {
                $hashtagsObj = [];
                foreach ($request->hashtags as $value) {
                    $hashtagsObj[] = new AdvertisementHashtag(['hashtag_id' => $value]);
                }
                if (!empty($hashtagsObj)) {
                    $advertisement->advertisement_hashtags()
                        ->saveMany($hashtagsObj);
                }
            }
            if (!empty($attributeDatas)) {
                $adsAttrObj = [];
                foreach ($attributeDatas as $attrKey => $attrValue) {
                    $adattr = [];
                    $adattr['attribute_id'] = $attrKey;
                    $adattr['value'] = $attrValue;
                    $adsAttrObj[] = new AdvertisementAttribute($adattr);
                }
                if (!empty($adsAttrObj)) {
                    $advertisement->advertisement_attributes()
                        ->saveMany($adsAttrObj);
                }
            }
            $advertisementData = Advertisement::findOrFail($advertisement->id);
            Session::forget('first_step');
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())
                ->withInput();
        }
        if ($request->save_draft_btn) {
            return redirect()
                ->route('frontend.dashboard', ['type' => 'ad-draft'])
                ->with('success', 'Advertisement has been saved successfully');
        } else {
            return redirect()
                ->route('frontend.advertisements.detail', [$advertisementData
                    ->slug])
                ->with('success', 'Advertisement has been saved successfully');
        }
    }

    private function getAttributes($business_category_id)
    {
        $attributes = Attribute::withCount([
            'attribute_options' => function ($query) {
                $query->where('parent_id', 0);
            }
        ])
            ->sortable(['ordering' => 'ASC'])
            ->with(['attribute_options' => function ($q) {
                $q->where('status', 1);
            }])->whereHas('businessCategory', function ($query) use ($business_category_id) {
                $query->where('category_id', $business_category_id);
            })->where('status', 1)->get();
        return $attributes;
    }

    public function getChildAttribute(Request $request)
    {
        if ($request->ajax()) {
            $attribute_id = $request->attribute_id;
            if ($request->action == "update_attribute") {
                $business_category_id = $request->business_category_id;
            } else {
                $first_step = Session::get('first_step');
                $business_category_id = $first_step['business_category_id'];
            }
            $attributeOptions = AttributeOption::with('attribute')->where('parent_id', $attribute_id)->sortable(['ordering' => 'ASC'])->whereHas('businessCategory', function ($query) use ($business_category_id) {
                $query->where('category_id', $business_category_id);
            })->status(1)
                ->get();
            $attributeOptionsRecored = [];
            if ($attributeOptions->count()) {
                $attributeOptionsRecored['children'] = $attributeOptions[0]
                    ->attribute->slug;
                $attributeOptionsRecored['data']['0'] = 'Select ' . $attributeOptions[0]
                    ->attribute->name;
                foreach ($attributeOptions as $attributeOption) {
                    $attributeOptionsRecored['data'][$attributeOption
                        ->id] = $attributeOption->name;
                }
            }
            return response($attributeOptionsRecored, 200);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($slug)
    {
        // dd($slug);
        $user = Auth::user();
        $adsQuery = Advertisement::query();
        $adsQuery->with([
            'user', 'advertisement_images', 'advertisement_attributes', 'advertisement_attributes.attribute', 'location', 'location.area' => function ($q) {
                $q->select('id', 'title', 'city_id');
            }, 'location.area.city' => function ($q) {
                $q->select('id', 'title');
            }, 'location.area.city' => function ($q) {
                $q->select('id', 'title');
            }, 'sub_business_category' => function ($q) {
                $q->select('id', 'title', 'parent_id', 'slug', 'color');
            }, 'sub_business_category.parent' => function ($q) {
                $q->select('id', 'title', 'color');
            }, 'user_reviews' => function ($q) {
                $q->select('id', 'advertisement_id', 'user_id', 'review', 'rating', 'created_at')
                    ->active();
            }, 'user_reviews.user' => function ($q) {
                $q->select('id', 'first_name', 'last_name', 'profile_picture');
            }
        ])
            ->slug($slug);
        if (!Auth::user()) {
            $adsQuery->status(1);
        }

        $advertisementData = $adsQuery->first();

        $actionSocialLinks = \App\Helpers\Helper::checkPlanFeaturesStatus($advertisementData->user_id, $advertisementData->business_category_id, 8);

        $actionSocialPromotion = \App\Helpers\Helper::checkPlanFeaturesStatus($advertisementData->user_id, $advertisementData->business_category_id, 7);

        if ($advertisementData) {
            if (!Auth::user()) {
                if ($advertisementData->status != 1) {
                    return redirect()
                        ->route('frontend.home')
                        ->with('error', 'you are not authorized to access it.');
                }
            } else {
                if (Auth::user()->id != $advertisementData->user_id) {
                    if ($advertisementData->status != 1) {
                        return redirect()
                            ->route('frontend.dashboard')
                            ->with('error', 'you are not authorized to access it.');
                    }
                }
            }
            $isPostReview = 0;
            if (Auth::user()) {
                $isPostReview = UserReview::where(['advertisement_id' => $advertisementData->id, 'user_id' => $user
                    ->id])
                    ->count();
            }
            $iswishlist = 0;
            if (Auth::user()) {
                $iswishlist = UserWishlist::where(['advertisement_id' => $advertisementData->id, 'user_id' => $user
                    ->id])
                    ->count();
            }
            $similarAdverts = Advertisement::with([
                'user', 'advertisement_images', 'location.area' => function ($q) {
                    $q->select('id', 'title', 'city_id');
                }, 'location.area.city' => function ($q) {
                    $q->select('id', 'title');
                }, 'location.area.city' => function ($q) {
                    $q->select('id', 'title');
                }, 'sub_business_category' => function ($q) {
                    $q->select('id', 'title', 'parent_id', 'color');
                }, 'sub_business_category.parent' => function ($q) {
                    $q->select('id', 'title', 'icon', 'color');
                }
            ])
                ->where('business_category_id', $advertisementData->business_category_id)
                ->where('id', '!=', $advertisementData->id)
                ->status(1)
                ->take(10)
                ->get();
            $getDiscussUser = '';
            if (Auth::user()) {
                $getDiscussUser = Discussion::where('sender_id', Auth::user()->id)
                    ->where('advertisement_id', $advertisementData->id)
                    ->count();
            }
        } else {
            return redirect()
                ->route('frontend.home',)
                ->with('error', 'Advertisement not found');
        }

        return view('advertisements.show', compact('advertisementData', 'similarAdverts', 'isPostReview', 'iswishlist', 'getDiscussUser', 'actionSocialLinks', 'actionSocialPromotion'));
    }

    /**
     * post Review of ads the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function postReview(Request $request)
    {
        $user = Auth::user();
        try {
            if ($request->ajax()) {
                $validator = Validator::make($request->all(), ['rating' => 'required', 'review' => 'required|max:1000|string',]);
                if ($validator->fails()) {
                    $errors = $validator->messages();
                    $responce = ['status' => 'danger', 'message' => $errors->first()];
                } else {
                    $advertisement = Advertisement::findOrFail($request->advertisement_id);
                    $user_reviews = new UserReview();
                    $responce = [];
                    $user_reviews->user_id = $user->id;
                    $user_reviews->review = $request->review;
                    $user_reviews->rating = $request->rating;
                    if ($advertisement->user_reviews()
                        ->save($user_reviews)
                    ) {

                        $notification_status = config('constants.NOTIFICATION_LIST');
                        // Event notification starts
                        $event_notification_user = [
                            'sender_id'     => 1,
                            'sender_type'   => 'A',
                            'receiver_id'   => $advertisement->user_id,
                            'receiver_type' => 'U',
                            'advertisement_id' => $advertisement->id,
                            'events'        => 'I',
                            'message'       => $notification_status['I']['message'],
                            'is_read'       => 0,
                        ];

                        EventNotification::create($event_notification_user);
                        // Event notification ends


                        //For sending invoice mail to user//
                        $hook = "post_review";
                        $replacement['USER_NAME']   = $advertisement->user->first_name;
                        $replacement['AD_TITLE']    = $advertisement->title;
                        $replacement['REVIEW']      = $request->review;
                        $replacement['RATING']      = $request->rating;

                        $data = ['template' => $hook, 'hooksVars' => $replacement];
                        Mail::to($advertisement->user->email)->send(new \App\Mail\ManuMailer($data));
                        // For sending invoce mail to user//


                        $responce = ['status' => 'success', 'message' => 'Advertisement review has been update successfully.'];
                    } else {
                        $responce = ['status' => 'danger', 'message' => 'Advertisement review has not update due to technical issue.'];
                    }
                }
            }
        } catch (\Illuminate\Database\QueryException $e) {
            $responce = ['status' => 'danger', 'message' => $e->getMessage()];
        }
        return $responce;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function addRemoveWish(Request $request)
    {
        $user = Auth::user();
        try {
            if ($request->ajax()) {
                $request->validate(['aid' => 'required',]);
                $advertisement = Advertisement::where(['id' => $request->aid, 'user_id' => $user
                    ->id])
                    ->count();
                if ($advertisement > 0) {
                    $responce = ['status' => 'danger', 'message' => 'Advertisement owner can\'t  add wishlist.'];
                } else {
                    $user_wishlist = UserWishlist::where(['advertisement_id' => $request->aid, 'user_id' => $user
                        ->id])
                        ->count();
                    if ($user_wishlist > 0) {
                        UserWishlist::where(['advertisement_id' => $request->aid, 'user_id' => $user
                            ->id])
                            ->delete();
                        $responce = ['status' => 'success', 'message' => 'Advertisement has been removed from wishlist.', 'action' => 'removed'];
                    } else {
                        $storeData = [];
                        $storeData['user_id'] = $user->id;
                        $storeData['advertisement_id'] = $request->aid;
                        UserWishlist::create($storeData);
                        $responce = ['status' => 'success', 'message' => 'Advertisement has been added wishlist successfully.', 'action' => 'added'];
                    }
                }
            }
        } catch (\Illuminate\Database\QueryException $e) {
            $responce = ['status' => 'danger', 'message' => $e->getMessage()];
        }
        return $responce;
    }

    /**
     * Show the form for add review for admin the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function adsReview(Request $request, $id)
    {
        try {
            $user = Auth::user();
            if ($id) {
                $advertisement = Advertisement::where(['id' => $id, 'user_id' => $user
                    ->id])
                    ->status(0)
                    ->first();
                if ($advertisement) {
                    $advertisement->status = 2;
                    $advertisement->save();

                    $notification_status = config('constants.NOTIFICATION_LIST');
                    $adminMail  = Setting::where('slug', 'ADMIN_EMAIL')->first();

                    // Event notification starts
                    $event_notification_admin = [
                        'sender_id'     => $user->id,
                        'sender_type'   => 'U',
                        'receiver_id'   => 1,
                        'receiver_type' => 'A',
                        'advertisement_id' => $advertisement->id,
                        'events'        => 'F',
                        'message'       => $notification_status['F']['message'],
                        'is_read'       => 0,
                    ];
                    $event_notification_user = [
                        'sender_id'     => 1,
                        'sender_type'   => 'A',
                        'receiver_id'   => $user->id,
                        'receiver_type' => 'U',
                        'advertisement_id' => $advertisement->id,
                        'events'        => 'E',
                        'message'       => $notification_status['E']['message'],
                        'is_read'       => 0,
                    ];

                    EventNotification::create($event_notification_admin);
                    EventNotification::create($event_notification_user);
                    // Event notification ends

                    //For sending invoice mail to user//
                    $hook = "advertisement_in_review";
                    $replacement['USER_NAME'] = $user->first_name;
                    $replacement['USER_EMAIL'] = $user->email;
                    $data = ['template' => $hook, 'hooksVars' => $replacement];
                    Mail::to($user->email)->send(new \App\Mail\ManuMailer($data));
                    // For sending invoce mail to user//

                    //For sending invoice mail to admin//
                    $hook = "new_advertisement";
                    $replacement['USER_NAME'] = $user->first_name;
                    $replacement['USER_EMAIL'] = $user->email;
                    $data = ['template' => $hook, 'hooksVars' => $replacement];
                    Mail::to($adminMail->config_value)->send(new \App\Mail\ManuMailer($data));
                    // For sending invoce mail to admin//

                    return redirect()
                        ->route('frontend.dashboard', 'ad-reviewing')
                        ->with('success', 'Advertisement has been send to review successfully.');
                } else {
                    return redirect()
                        ->route('frontend.dashboard', 'ad-reviewing')
                        ->withError('Advertisement not found for send to review.');
                }
            }
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())
                ->withInput();
        }
    }

    /**
     * Show the form for apply Featured for admin the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function applyFeatured(Request $request)
    {
        try {
            $user = Auth::user();
            if ($request->id) {
                $advertisement = Advertisement::where(['id' => $request->id, 'user_id' => $user
                    ->id])
                    ->status(1)
                    ->first();
                if ($advertisement) {
                    $advertisement->is_featured = 2;
                    $advertisement->save();
                    $responce = ['status' => true, 'message' => 'This advertisement has been apply for featured.', 'data' => []];
                } else {
                    $responce = ['status' => false, 'message' => 'This advertisement not found for send to featured.', 'data' => []];
                }
            }
        } catch (\Illuminate\Database\QueryException $e) {
            $responce = ['status' => false, 'message' => $e->getMessage(), 'data' => []];
        }
        return $responce;
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editStepOne($id)
    {
        $advertisement = Advertisement::with(['location', 'business_category', 'advertisement_images', 'sub_business_category',])->findOrFail($id);

        if (
            $advertisement->user_id != auth()
            ->user()
            ->id
        ) {
            return redirect()
                ->route('frontend.dashboard')
                ->with('error', 'you are not authorized to access it.');
        }
        $auctionImages = [];
        if (
            $advertisement
            ->advertisement_images
            ->count() > 0
        ) {
            foreach ($advertisement->advertisement_images as $keyImage => $advertisement_image) {
                $auctionImages[$keyImage]['Url'] = asset('storage/advertisements/' . $advertisement_image->image_name);
                $auctionImages[$keyImage]['Name'] = "Images " . $keyImage;
            }
        }
        // dd($auctionImages);
        $locationData = $this->getLocations();

        $cities = City::whereHas('areas')->where('country_id', 110)
            ->where('status', 1)
            ->pluck('title', 'id');
        $areas = Area::where('status', 1)->where('city_id', $advertisement->city_id)
            ->pluck('title', 'id');

        $locations = Location::where('status', 1)->where('area_id', $advertisement->area_id)
            ->pluck('title', 'id');
        //Check Active Plan
        $active_plan_categories =  Subscription::where(['user_id' => Auth::user()->id, 'status' => 1])
            ->whereDate('start_date', '<=', date("Y-m-d"))
            ->whereDate('end_date', '>=', date("Y-m-d"))
            // ->with('plans.plan_features')
            ->pluck('category_id')->toArray();
        // dd($active_plan_categories);
        // $categories = BusinessCategory::where('parent_id','0')->status(1)->pluck('title', 'id');
        // $categories = BusinessCategory::where('parent_id', '0')->whereHas('children')
        //     ->status(1)
        //     ->pluck('title', 'id');
        $categories = BusinessCategory::whereIn('id', $active_plan_categories)->where('parent_id', '0')->whereHas('children')
            ->status(1)
            ->pluck('title', 'id');
        $sub_categories = BusinessCategory::where('parent_id', $advertisement->business_category_id)
            ->status(1)
            ->pluck('title', 'id');

        return view('advertisements.editStepOne', compact('advertisement', 'locationData', 'categories', 'sub_categories', 'auctionImages', 'cities', 'areas', 'locations'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateStepOne(Request $request)
    {
        $user = auth()->user();
        try {
            $rules['business_category_id'] = 'required';
            $rules['sub_business_category_id'] = 'sub_business_category_id';
            $validator = Validator::make($request->all(), $rules);
            $advertisement = Advertisement::findOrFail($request->advertisement_id);
            if ($advertisement->user_id != $user->id) {
                return redirect()
                    ->route('frontend.dashboard')
                    ->with('error', 'You are not authorized to access it.');
            }
            // dd($request->all());
            $requestData = $request->all();
            if (!empty($request->uploaded_images)) {
                $uploadedImages = $this->uploadImage($request->uploaded_images);
                if (!empty($uploadedImages)) {
                    if (
                        $advertisement
                        ->advertisement_images
                        ->count() > 0
                    ) {
                        $advertisement->advertisement_images()
                            ->delete();
                    }
                    $uploadedImagesObj = [];
                    foreach ($uploadedImages as $imageKey => $imageValue) {
                        $adImage = [];
                        $adImage['image_name'] = (string)$imageValue;
                        $adImage['main'] = $imageKey == 0 ? 1 : 0;
                        $uploadedImagesObj[] = new AdvertisementImage($adImage);
                    }
                    if (!empty($uploadedImagesObj)) {
                        $advertisement->advertisement_images()
                            ->saveMany($uploadedImagesObj);
                    }
                }
            }
            $storeData = [];
            $storeData['business_category_id'] = !empty($requestData['business_category_id']) ? $requestData['business_category_id'] : '';;
            $storeData['sub_business_category_id'] = !empty($requestData['sub_business_category_id']) ? $requestData['sub_business_category_id'] : '';
            if (!empty($requestData['location_id'])) {
                $location_id = $requestData['location_id'];
                $location = Location::with([
                    'area' => function ($q) {
                        $q->select('id', 'city_id');
                    }
                ])
                    ->where('id', $location_id)->first();
                if ($location->area) {
                    $area_id = $location
                        ->area->id;
                    $city_id = $location
                        ->area->city_id;
                } else {
                    $area_id = '';
                    $city_id = '';
                }
            } else {
                $location_id = '';
                $area_id = '';
                $city_id = '';
            }
            $storeData['city_id'] = $requestData['city_id'];
            $storeData['area_id'] = $requestData['area_id'];
            $storeData['location_id'] = $requestData['location_id'];
            $storeData['status'] = 0;
            $storeData['admin_approve'] = 0;
            $storeData['is_publish'] = 0;
            $advertisement->fill($storeData);
            $advertisement->save();
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())
                ->withInput();
        }
        return redirect()
            ->route('frontend.advertisements.edit-step-two', $advertisement->id)
            ->with('success', 'Advertisement has been updated successfully.');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editStepTwoHashtags(Request $request, $id)
    {
        $advertisement = Advertisement::find($id);
        $outerArr = [];
        $innerArr = [];
        foreach ($advertisement->advertisement_hashtags as $key => $row) {
            $innerArr['id'] = $row->getHashtags->id;
            $innerArr['title'] = $row->getHashtags->title;
            $outerArr[] = $innerArr;
        }
        return response()->json($outerArr);
    }
    public function editStepTwo(Request $request, $id)
    {

        $user = auth()->user();
        try {
            $advertisement = Advertisement::with([
                'business_category', 'sub_business_category', 'advertisement_attributes', 'advertisement_attributes.attribute' => function ($q) {
                    $q->orderBy('ordering', 'ASC');
                },
            ])
                ->findOrFail($id);

            if (
                $advertisement->user_id != auth()
                ->user()
                ->id
            ) {
                return redirect()
                    ->route('frontend.dashboard')
                    ->with('error', 'you are not authorized to access it.');
            }
            $attributes = $this->getAttributes($advertisement->business_category_id);
            $selectedAttribute = [];
            // dd($advertisement->advertisement_hashtags);
            if (
                $advertisement
                ->advertisement_attributes
                ->count() > 0
            ) {
                foreach ($advertisement->advertisement_attributes as $key => $advertisement_attribute) {
                    $selectedAttribute[$advertisement_attribute
                        ->attribute
                        ->id] = $advertisement_attribute->value;
                }
            }
            // dump($selectedAttribute);
            // dd($advertisement);

        } catch (\Exception $e) {
            return redirect()->route('frontend.dashboard')
                ->withError($e->getMessage())
                ->withInput();
        }
        return view('advertisements.editStepTwo', compact('advertisement', 'attributes', 'selectedAttribute'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateStepTwo(Request $request)
    {
        // dd($request->all());
        $user = auth()->user();
        $rules = [];
        $advertisement = Advertisement::findOrFail($request->advertisement_id);
        if ($advertisement->user_id != $user->id) {
            return redirect()
                ->route('frontend.dashboard')
                ->with('error', 'You are not authorized to access it.');
        }
        $attributes = $this->getAttributes($advertisement->business_category_id);
        $rules['title'] = 'required|regex:/^[\pL\s\-]+$/u';
        $rules['description'] = 'required';
        // $rules['hashtag'] = 'required';
        $rules['matches.*'] = 'required';
        if ($attributes->count() > 0) {
            foreach ($attributes as $attribute) {
                if ($attribute->requried) {
                    $rules['attribute_' . $attribute->id] = 'required';
                }
            }
        }

        try {
            $validator = Validator::make($request->all(), $rules);
            $requestData = $request->all();
            $attributeDatas = [];
            $adsData = [];
            foreach ($requestData as $reqKey => $reqData) {
                if (strpos($reqKey, 'attribute_') !== false) {
                    $attr_id = explode("_", $reqKey);
                    $attributeDatas[$attr_id[1]] = $reqData;
                } else {
                    $adsData[$reqKey] = $reqData;
                }
            }
            $storeData['title'] = $adsData['title'];
            $storeData['description'] = $adsData['description'];
            $storeData['price_type'] = $adsData['radio_payment'];
            // $storeData['hashtag'] = $adsData['hashtag'];
            if ($adsData['radio_payment'] == 1) {
                $priceRange = explode(";", $adsData['rangePrimary']);
                $minPrice = $priceRange[0];
                $maxPrice = $priceRange[1];
                $storeData['min_price'] = $minPrice;
                $storeData['max_price'] = $maxPrice;
                $storeData['fixed_price'] = $maxPrice;
            } else {
                $storeData['fixed_price'] = $adsData['fixed_price'];
            }
            $storeData['status'] = 0;
            $storeData['admin_approve'] = 0;
            $storeData['is_publish'] = 0;

            $advertisement->fill($storeData);
            $advertisement->save();

            if ($request->hashtags) {
                $advertisement->advertisement_hashtags()->delete();
                $hashtagsObj = [];
                foreach ($request->hashtags as $value) {
                    $hashtagsObj[] = new AdvertisementHashtag(['hashtag_id' => $value]);
                }
                if (!empty($hashtagsObj)) {
                    $advertisement->advertisement_hashtags()
                        ->saveMany($hashtagsObj);
                }
            }

            if (!empty($attributeDatas)) {
                if (
                    $advertisement
                    ->advertisement_attributes
                    ->count() > 0
                ) {
                    $advertisement->advertisement_attributes()
                        ->delete();
                }
                $adsAttrObj = [];
                foreach ($attributeDatas as $attrKey => $attrValue) {
                    $adattr = [];
                    $adattr['attribute_id'] = $attrKey;
                    $adattr['value'] = $attrValue;
                    $adsAttrObj[] = new AdvertisementAttribute($adattr);
                }
                if (!empty($adsAttrObj)) {
                    $advertisement->advertisement_attributes()
                        ->saveMany($adsAttrObj);
                }
            }

            $notification_status = config('constants.NOTIFICATION_LIST');
            $adminMail  = Setting::where('slug', 'ADMIN_EMAIL')->first();

            // Event notification starts
            $event_notification_admin = [
                'sender_id'     => $user->id,
                'sender_type'   => 'U',
                'receiver_id'   => 1,
                'receiver_type' => 'A',
                'advertisement_id' => $advertisement->id,
                'events'        => 'H',
                'message'       => $notification_status['H']['message'],
                'is_read'       => 0,
            ];
            $event_notification_user = [
                'sender_id'     => $user->id,
                'sender_type'   => 'U',
                'receiver_id'   => $user->id,
                'receiver_type' => 'U',
                'advertisement_id' => $advertisement->id,
                'events'        => 'G',
                'message'       => $notification_status['G']['message'],
                'is_read'       => 0,
            ];

            EventNotification::create($event_notification_admin);
            EventNotification::create($event_notification_user);
            // Event notification ends

            //For sending invoice mail to user//
            $hook = "edit_advertisement";
            $replacement['USER_NAME'] = $user->first_name;
            $replacement['USER_EMAIL'] = $user->email;
            $replacement['AD_TITLE'] = $advertisement->title;
            $replacement['MATCH']     = '.';

            $data = ['template' => $hook, 'hooksVars' => $replacement];
            Mail::to($user->email)->send(new \App\Mail\ManuMailer($data));
            // For sending invoce mail to user//

            //For sending invoice mail to admin//
            $hook = "edit_advertisement";
            $replacement['USER_NAME'] = 'Admin';
            $replacement['USER_EMAIL'] = $adminMail->config_value;
            $replacement['AD_TITLE'] = $advertisement->title;
            $replacement['MATCH']     = ' by ' . $user->first_name . ' ' . '( ' . $user->email . ' )';

            $data = ['template' => $hook, 'hooksVars' => $replacement];
            Mail::to($adminMail->config_value)->send(new \App\Mail\ManuMailer($data));
            // For sending invoce mail to admin//

        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())
                ->withInput();
        }
        $advertisementData = Advertisement::findOrFail($advertisement->id);
        if ($advertisementData->status == 0) {
            return redirect()
                ->route('frontend.advertisements.detail', [$advertisementData
                    ->slug])
                ->with('success', 'Advertisement has been updated successfully');
        }

        return redirect()
            ->route('frontend.dashboard')
            ->with('success', 'Advertisement has been updated successfully');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $user = Auth::user();
        DB::beginTransaction();
        try {
            $advertisement = Advertisement::where(['id' => $request->id, 'user_id' => $user
                ->id])
                ->first();
            if ($advertisement) {
                $advertisement->advertisement_images()
                    ->delete();
                $advertisement->advertisement_attributes()
                    ->delete();
                $advertisement->user_reviews()
                    ->delete();
                $advertisement->delete();
                DB::commit();
                $responce = ['status' => true, 'message' => 'This advertisement has been deleted successfully.', 'data' => []];
            } else {
                $responce = ['status' => true, 'message' => 'Advertisement record not found.', 'data' => []];
            }
        } catch (\Exception $e) {
            DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

    /*
     * upload image
    */
    public function uploadImage($iData = [])
    {
        $imageNames = [];
        foreach ($iData as $imageData) {
            // dd($imageData);
            $image = $imageData; // your base64 encoded
            $image = str_replace('data:image/png;base64,', '', $image);
            $image = str_replace(' ', '+', $image);
            $imageName = Str::random(20) . '.' . 'png';
            \File::put(storage_path('app/public') . '/advertisements/' . $imageName, base64_decode($image));
            $imageNames[] = $imageName;
        }

        return $imageNames;
    }

    public function publishUnpublish(Request $request, $id)
    {
        try {
            $advertisementData = Advertisement::findOrFail($id);
            if ($request->type == 'publish') {
                $message = 'published';
                $advertisementData->status = 1;
                $advertisementData->is_publish = 1;
            } else {
                $message = 'unpublished';
                $advertisementData->status = 0;
                $advertisementData->is_publish = 0;
            }
            $advertisementData->save();
            $responce = ['status' => true, 'message' => 'This advertisement has been ' . $message . ' successfully.', 'data' => []];
        } catch (\Exception $e) {
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

    public function location(Request $req, $location = null, $char = 'a')
    {

        $searchcategory = '';
        if (!empty($req->query('category'))) {
            $searchcategory = $req->query('category');
        }

        $locationData = Location::where('slug', $location)->orwhere('postcode', $location)->status()
            ->with('parent')
            ->first();

        if (empty($locationData)) {
            $category = $location;
            $categoryData = Category::where('slug', $category)->status()
                ->first();
            if (empty($categoryData)) {
                abort(404);
            }
            $searchLocaiton = '';
            $parentId = 0;
            $locationdata = Location::status();
            $char = 'a';

            if (!empty($req->query('s'))) {
                $char = $req->query('s');
            }

            if (!empty($char)) {
                $locationdata = $locationdata->where("title", "like", $char . "%");
            }
            $locationValue = $locationdata->where('parent_id', '>', 0)
                ->with('parent')
                ->get();

            return view('listings.category', compact('locationValue', 'category', 'searchLocaiton', 'categoryData'));
        }
        $categoryData = Category::status()->orderBy('title', 'asc');
        if ($searchcategory != '') {
            $categoryData = $categoryData->where("title", "like", "%$searchcategory%");
        }
        $categoryData = $categoryData->get();
        return view('listings.location', compact('categoryData', 'location', 'searchcategory', 'locationData'));
    }

    public function allLocationold(Request $req)
    {
        $searchLocaiton = '';
        $parentId = 0;
        if (!empty($req->query('locations'))) {
            $searchLocaiton = $req->query('locations');
            $locationData = Location::where('slug', $searchLocaiton)->first();
            $parentId = $locationData->parent_id;
            if ($locationData->parent_id == 0) {
                $parentId = $locationData->id;
            }
        }

        if ($parentId != 0) {
            $locationdata = Location::status()->where('id', $parentId)->orWhere('parent_id', $parentId)->get();
        } else {
            $locationdata = Location::status()->get();
        }

        $locationValue = [];
        foreach ($locationdata as $location) {
            if ($location->parent_id == -1) {
                continue;
            }

            $parent = $location->parent_id != 0 ? $location->parent_id : $location->id;

            $locationValue[$parent][$location->id]['title'] = $location->title;
            $locationValue[$parent][$location->id]['slug'] = $location->slug;
            $locationValue[$parent][$location->id]['parent_id'] = $location->parent_id;
        }

        // for postcode Searching
        $postcodes = Location::status()->groupBy('postcode')
            ->orderBy("postcode", "ASC")
            ->pluck("postcode", "postcode");

        return view('listings.all_location', compact('locationValue', 'postcodes'));
    }

    public function allLocation(Request $req)
    {

        $searchLocaiton = '';
        $parentId = 0;
        if (!empty($req->query('locations'))) {
            $searchLocaiton = $req->query('locations');
        }

        $counties = Location::status()->where('type', 2);
        if ($searchLocaiton != '') {
            $counties = $counties->where("title", "like", "%$searchLocaiton%");
        }
        $counties = $counties->orderBy("title", "ASC")
            ->pluck("title", "slug");
        $cities = Location::status()->where('type', 3);
        if ($searchLocaiton != '') {
            $cities = $cities->where("title", "like", "%$searchLocaiton%");
        }
        $cities = $cities->orderBy("title", "ASC")
            ->pluck("title", "slug");

        // for postcode Searching
        $postcodes = Location::status();
        if ($searchLocaiton != '') {
            $postcodes = $postcodes->where("postcode", "like", "%$searchLocaiton%");
        }
        $postcodes = $postcodes->groupBy('postcode')
            ->orderBy("postcode", "ASC")
            ->pluck("postcode", "postcode");

        return view('listings.all_location', compact('counties', 'postcodes', 'cities', 'searchLocaiton'));
    }

    public function allTown(Request $req, $char = 'a')
    {

        $searchLocaiton = '';
        if (!empty($req->query('locations'))) {
            $searchLocaiton = $req->query('locations');
        }

        $towns = Location::status()->where('type', 4);
        if ($searchLocaiton != '') {
            $towns = $towns->where("title", "like", "%$searchLocaiton%");
        } else {
            $towns = $towns->where("title", "like", $char . "%");
        }

        $towns = $towns->with('parent')
            ->orderBy("title", "ASC")
            ->get();

        return view('listings.all_towns', compact('char', 'towns', 'searchLocaiton'));
    }

    public function category(Request $req, $category = null, $char = 'a')
    {

        $categoryData = Category::where('slug', $category)->status()
            ->first();
        if (empty($categoryData)) {
            abort(404);
        }
        $searchLocaiton = '';
        $parentId = 0;
        $locationdata = Location::status();
        if (!empty($req->query('locations'))) {
            $searchLocaiton = $req->query('locations');
            $locationdata = $locationdata->where("title", "like", "%" . $searchLocaiton . "%");
        }

        if (!empty($char)) {
            $locationdata = $locationdata->where("title", "like", $char . "%");
        }
        $locationValue = $locationdata->where('parent_id', '>', 0)
            ->with('parent')
            ->get();

        return view('listings.category', compact('locationValue', 'category', 'searchLocaiton', 'categoryData'));
    }

    public function search($location = null, $category = null)
    {

        /*
        $listings = Advertisement::with('user.sponsor','locations', 'categories')->whereHas('locations',function ($query)  use($location){
        $query->where('slug', $location);
        })->whereHas('categories',function ($query)  use($category){
        $query->where('slug', $category);
        })->status()->paginate(config('get.FRONT_PAGE_LIMIT'));
        $categoryData = Category::where('slug', $category)->status()->first();
        $locationData = Location::where('slug', $location)->status()->first();
        
        $connected_cat = Category::status()->whereIn('id', explode(',', $categoryData->connected_cat))->pluck('title', 'slug')->toArray();
        $metaTags = Metatag::filter(['location_id'=>$locationData->id,'category_id' => $categoryData->id])->first();
        
        */

        $locationData = Location::where('slug', $location)->status()
            ->first();

        if (empty($locationData)) {
            abort(404);
        }
        $locationCount = Location::where('title', $locationData->title)
            ->count();

        if ($locationCount > 1) {
            $locationData = Location::where('slug', $location)->parent()
                ->first();

            $locationString = $locationData->title . " " . (isset($locationData
                ->parent
                ->title) ? $locationData
                ->parent->title : '');
        } else {
            $locationString = $locationData->title;
        }

        $searchData = $this->getListingData($location, $category);
        extract($searchData);
        // dd($metaTags);
        $metaTitle = '';
        $metaDescription = '';
        if ($categoryData->meta_title != '') {
            $metaTitle = str_replace("XXX", $locationString, $categoryData->meta_title);
        }

        if ($categoryData->meta_description != '') {
            $metaDescription = str_replace("XXX", $locationString, $categoryData->meta_description);
        }
        return view('listings.listing', compact('listings', 'metaTags', 'connected_cat', 'location', 'categoryData', 'locationData', 'category', "metaDescription", "metaTitle", "locationString"));
    }

    public function map_view($location = null, $category = null)
    {
        $searchData = $this->getListingData($location, $category);
        extract($searchData);
        $mapArr = [];
        foreach ($listings as $listing) {
            $map = [];
            $map[0] = $listing->title;
            $map[1] = $listing->location;
            $map[2] = route("listings.detail", array(
                $listing->slug
            ));
            $map[3] = $listing->lat;
            $map[4] = $listing->lng;
            $mapArr[] = $map;
        }
        return view('listings.map_view', compact('listings', 'metaTags', 'connected_cat', 'location', 'categoryData', 'locationData', 'category', 'mapArr'));
    }

    private function getListingData($location = null, $category = null)
    {

        $locationArr = Location::where('slug', $location)->first();
        $categoryArr = Category::where('slug', $category)->status()
            ->first();
        if (empty($locationArr)) {
            // check postcode;
            $locations = Location::where('postcode', $location)->pluck("id")
                ->toArray();
        } elseif ($locationArr->parent_id == 0) {
            // in case if location is County get all towns
            $locations = Location::where('parent_id', $locationArr->id)
                ->pluck("id")
                ->toArray();
            //   $locations[$locationArr->id] = $locationArr->slug;

        } else {
            // in case of town
            $locations = [$locationArr->id];
            ///    $locationsid = [$locationArr->id];

        }

        if (empty($locations)) {
            abort(404);
        }

        if (empty($categoryArr)) {
            abort(404);
        }

        /*$return['listings'] = Advertisement::with('locations', 'categories','services')->whereHas('locations',function ($query)  use($locations){
            
            $query->whereIn('slug', $locations);
        })->whereHas('categories',function ($query)  use($category){
            $query->where('slug', $category);
        })->status()->orderBy('title','asc')->paginate(config('get.FRONT_PAGE_LIMIT'));*/

        /* $return['listings'] = [];*/
        $return['categoryData'] = $categoryArr;
        $return['locationData'] = $locationArr;

        $return['connected_cat'] = Category::status()->whereIn('id', explode(',', $return['categoryData']->connected_cat))
            ->pluck('title', 'slug')
            ->toArray();
        $return['metaTags'] = [];
        if (isset($return['locationData']->id)) $return['metaTags'] = Metatag::filter(['location_id' => $return['locationData']->id, 'category_id' => $return['categoryData']
            ->id])
            ->first();

        $listing_location = DB::table('listing_location')->whereIn('location_id', $locations)->pluck('listing_id')
            ->toArray();

        $listing_category = DB::table('category_listing')->where('category_id', $categoryArr->id)
            ->pluck('listing_id')
            ->toArray();

        $result = array_intersect($listing_location, $listing_category);

        $return['listings'] = Advertisement::with('user.sponsor', 'avgRating')->whereIn('id', $result)->orderBy('sort_order', 'desc')
            ->paginate(config('get.FRONT_PAGE_LIMIT'));

        return $return;
    }
    /**
     * Display the specified resource.
     *
     * @param  string  $slug
     * @return \Illuminate\Http\Response
     */
    public function detail($slug = null)
    {
        // dd('ok');
        $listing = Advertisement::with('user.sponsor', 'locations', 'categories', 'galleries', 'approveReview', 'avgRating', 'openings')->status()
            ->slug($slug)->first();

        if (empty($listing)) {
            abort(404);
            /*return redirect()->route('home')->with('error', 'you are not authorized to access it.');*/
        }

        \App\Helpers\Helper::saveRecord($listing->id, 1);
        return view('listings.show', compact('listing'));
    }

    /**
     * Display the specified resource.
     *
     * @param  Request  $req
     * @return \Illuminate\Http\Response
     */

    public function autosuggestion(Request $req)
    {

        $requestData = $req->all();
        $listings = Listing::where('title', 'like', '%' . $requestData['search'] . '%')->status()
            ->get();
        $listing = [];
        foreach ($listings as $listingData) {
            $data['value'] = $listingData['slug'];
            $data['label'] = $listingData['title'];
            $listing[] = $data;
        }
        echo json_encode($listing);
    }

    public function sellermail(Request $request)
    {
        dd('ok');

        $info = array(
            'name' => "Alex"
        );
        Mail::send('mail', $info, function ($message) {
            $message->to('ravijhalani4@gmail.com', 'w3schools')
                ->subject('HTML test eMail from W3schools.');
            $message->from('karlosray@gmail.com', 'Alex');
        });

        return redirect()
            ->back()
            ->with('success', 'Mail Send Successfully..');
    }
}
