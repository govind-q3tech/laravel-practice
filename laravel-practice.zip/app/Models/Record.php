<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Record extends Model
{
    use HasFactory;

    protected $fillable = ["type", "ipaddress", "listing_id",  "status"];

    public function listing()
    {
        return $this->belongsTo(\App\Models\Listing::class, 'listing_id');
    }

}
