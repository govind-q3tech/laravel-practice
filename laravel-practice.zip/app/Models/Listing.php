<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Kyslik\ColumnSortable\Sortable;

class Listing extends Model
{
    use HasFactory;
    use Sortable;
    use Sluggable;

    protected $fillable = ["title", "user_id", "slug", "description", "short_description", "location", "lat", "lng", "category_id", "sub_category_id", "website", "tagline", "facebook", "twitter", "instagram", "status", "admin_approve", "show_at_home","sponsored",'sort_order'];

    /**
     * The sortable used for column sort.
     *
     * @var array
     */
    public $sortable = ["title", "user_id", "slug", "description", "admin_approve",'created_at', 'updated_at']; 


    /*joing come here */


    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }

    public function locations()
    {
        return $this->belongsTo(\App\Models\Location::class);
    }

    public function business_categories()
    {
        return $this->belongsTo(\App\Models\BusinessCategory::class);
    }

    public function advertisement_images()
    {
        return $this->hasMany(\App\Models\AdvertisementImage::class, 'advertisement_id');
    }

    public function userreview()
    {
        return $this->hasMany(\App\Models\UserReview::class, 'listing_id');
    }

    public function approveReview()
    {
        return $this->userreview()->where('admin_approve','1');
    }



     /**
     * Get the only lender detail from existing crm.
     * Nee to delete after remove from all places and use xero_contact instead of this method
     */
    public function data_listing()
    {
        return $this->morphOne(\App\Models\DataSync::class, 'datasyncable')->where('table_type', 3);
    }

    public function avgRating()
    {
        return $this->approveReview()
        ->selectRaw('avg(rating) as aggregate, listing_id')
        ->groupBy('listing_id');
    }

    public function getAvgRatingAttribute()
    {
        if ( ! array_key_exists('avgRating', $this->relations)) {
        $this->load('avgRating');
        }

        $relation = $this->getRelation('avgRating')->first();

        return ($relation) ? $relation->aggregate : null;
    }

    

    /* end of joining */




    /* SLUG Works come here */
    public function sluggable()
    {
        return [
            'slug' => [
                'source' => 'custom_slug',
                'unique' => true,
                'separator' => '-',
                'onUpdate' => true,
            ]
        ];
    }

    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function getCustomSlugAttribute()
    {
        if (empty($this->slug)) {
            return strtoupper(trim($this->title));
        } else {
            return strtoupper(trim($this->slug));
        }
    }

    /* End of slug */

    /**
     * The scope filter used for filter the result on the basis of search keyword.
     *
     * @return query object
     */
    public function scopeFilter($query, $keyword)
    {
        if (!empty($keyword)) {
            $query->where(function ($query) use ($keyword) {
                if($keyword == 1)
                $query->where('status',  '1');

                if($keyword == 2)
                $query->where('admin_approve',  '1');

                if($keyword == 3)
                $query->whereIn('admin_approve',  ['2','0']);
                // $query->where('status',  '1');

                if($keyword == 4)
                $query->where('status',  '0');



            });
        }
        return $query;
    }


    /**
     * The slug filter used for filter the result on the basis of slug.
     *
     * @return query object
     */
    public function scopeSlug($query, $slug)
    {
        if (!empty($slug)) {
            $query->where(function ($query) use ($slug) {
                $query->where('slug',  $slug );
            });
        }
        return $query;
    }

    public function scopeStatus($query)
    {
        
            $query->where(function ($query) {
                $query->where('status',1);
                $query->where('admin_approve',1);
            });
        
        return $query;
    }

    public function scopeHome($query)
    {
        
            $query->where(function ($query) {
                $query->where('show_at_home',1);
            });
        
        return $query;
    }
}