<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class UserWishlist extends Model
{
    use HasFactory, Sortable;

    protected $fillable = ['advertisement_id','user_id', 'admin_approve'];

    public function advertisement()
    {
        return $this->belongsTo(\App\Models\Advertisement::class, 'advertisement_id');
    }    

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }    
}