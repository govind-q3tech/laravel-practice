<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;


class Attribute extends Model
{
    use HasFactory, Sortable, Sluggable;

    protected $fillable = ["name", "slug", "type", "label", "placeholder", "ordering", "requried", "status"];

     /*
     * sortable used for column sort.
     *
     * @var array
     */
    public $sortable = ["name",  "type", 'status', 'ordering', 'created_at'];
   /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'name',
                'unique' => true,
                'separator' => '-',
                'onUpdate' => true,
            ]
        ];
    }


    public function businessCategory()
    {
        return $this->belongsToMany(\App\Models\BusinessCategory::class,'attribute_business_category','attribute_id','category_id');
    }

    public function attribute_options()
    {
        return $this->hasMany(\App\Models\AttributeOption::class, 'attr_id', 'id');
    }

    public function scopeFilter($query, $keyword)
    {
        if (!empty($keyword)) {
            $query->where(function ($query) use ($keyword) {
                $query->where('name', 'LIKE', '%' . $keyword . '%');
            });
        }
        return $query;
    }


    public function scopeStatus($query, $status = 1)
    {
        if (!empty($status)) {
            $query->where(function ($query) use ($status) {
                $query->where('status', $status);
            });
        }
        return $query;
    }
}
