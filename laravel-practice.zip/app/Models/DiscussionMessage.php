<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DiscussionMessage extends Model
{
    use HasFactory;
    protected $table = 'discussion_message';
     /**
     * The sortable used for column sort.
     *
     * @var array
     */
    public $sortable = ["sender_id", "receiver_id", "discussion_id", "status", 'created_at', 'updated_at','message','attachment']; 

     /**
     * Get the product associated with the attribute.
     */
    public function discussion() {
        return $this->belongsTo('App\Models\Discussion', 'discussion_id');
    }
    
    /**
     * The Advertisement Attribute that belong to the Attribute.
     */
    public function senderChat()
    {
        return $this->hasOne(\App\Models\User::class, 'id','sender_id');
    }
    /**
     * The Advertisement Attribute that belong to the Attribute.
     */
    public function receiverChat()
    {
        return $this->hasOne(\App\Models\User::class, 'id','receiver_id');
    }

}
