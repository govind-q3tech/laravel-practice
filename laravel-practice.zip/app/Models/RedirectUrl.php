<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RedirectUrl extends Model
{
    protected $fillable = ['old_url','new_url'];

    /**
     * Scope a query to only include active users.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeStatus($query, $status = null)
    {
        if($status === '0' || $status == 1){
            $query->where('status', $status);
        }
        return $query;
    }
    /**
     * Scope a query to only include filtered users.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeFilter($query, $keyword)
    {
        if(!empty($keyword)){
            $query->where(function($query) use ($keyword){
                $query->where('old_url', 'LIKE', '%'.$keyword.'%');
                $query->orWhere('new_url', 'LIKE', '%'.$keyword.'%');
            });
        }
        return $query;
    }
}
