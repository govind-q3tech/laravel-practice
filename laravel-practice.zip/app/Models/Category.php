<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class Category extends Model
{
    use HasFactory, Sortable;
    // set table name for model
    protected $table = 'business_categories';

    protected $fillable = ["title", "slug", "description", "status", "meta_title", "meta_keyword", "meta_description", "connected_cat", "icon", "priority"];

    protected $appends = array('icon_image');

    public function lisitngs()
    {
        return $this->belongsToMany(\App\Models\Listing::class);
    }

    public function getIconImageAttribute()
    {
        
        return !empty($this->icon) ? asset('category_icons/' . $this->icon) : "";
    }


    public function scopeFilter($query, $keyword)
    {
        if (!empty($keyword)) {
            $query->where(function ($query) use ($keyword) {
                $query->where('title', 'LIKE', '%' . $keyword . '%');
            });
        }
        return $query;
    }


    public function scopeStatus($query, $status = 1)
    {
        if (!empty($status)) {
            $query->where(function ($query) use ($status) {
                $query->where('status', $status);
            });
        }
        return $query;
    }


    /**
     * Get the only lender detail from existing crm.
     * Nee to delete after remove from all places and use xero_contact instead of this method
     */
    public function data_category()
    {
        return $this->morphOne(\App\Models\DataSync::class, 'datasyncable')->where('table_type', 2);
    }
}
