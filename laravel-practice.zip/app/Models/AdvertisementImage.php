<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\ServiceManager\Entities\Service;

class AdvertisementImage extends Model
{

    protected $fillable = ["advertisement_id", "image_name", "main"];
    protected $appends = array('ad_image');

    /**
     * The gallery that belong to the houses.
     */
    public function advertisement()
    {
        return $this->belongsTo(App\Models\Advertisement::class);
    }

    public function getAdImageAttribute()
    {
        
        return !empty($this->image_name) ? asset('storage/advertisements/' . $this->image_name) : "";
    }

   
}
