<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class AttributeOption extends Model
{
    use HasFactory, Sortable;

    protected $fillable = ["attr_id", "parent_id", "category_id", "name", "slug", "status"];

   
   protected $appends = ['label', 'value'];

    

    public function getLabelAttribute()
    {

        return !empty($this->name) ? $this->name : "";
    }


     public function getValueAttribute()
    {

        return !empty($this->id) ? $this->id : "";
    }



    public function parent()
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function businessCategory()
    {
        return $this->belongsTo(\App\Models\BusinessCategory::class, 'category_id', 'id');
    }

    public function attribute()
    {
        return $this->belongsTo(\App\Models\Attribute::class, 'attr_id', 'id');
    }

    /**
     * Scope a query to only include filtered users.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeFilter($query, $keyword)
    {
        if (!empty($keyword)) {
            $query->where(function ($query) use ($keyword) {
                $query->where('name', 'LIKE', '%' . $keyword . '%');
            });
        }
        return $query;
    }

    /**
     * Scope a query to only include active users.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeStatus($query, $status = null)
    {
        if ($status === '0' || $status == 1) {
            $query->where('status', $status);
        }
        return $query;
    }
}
