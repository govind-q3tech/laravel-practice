<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Kyslik\ColumnSortable\Sortable;

class Discussion extends Model
{
    use HasFactory;
    protected $table = 'discussion';
    /**
     * The sortable used for column sort.
     *
     * @var array
     */
    public $sortable = ["sender_id", "receiver_id", "advertisement_id", "status", 'created_at', 'updated_at']; 

     /**
     * Get the product associated with the attribute.
     */
    public function discussionMsg() {
        return $this->hasMany('App\Models\DiscussionMessage', 'discussion_id');
    }

    /**
     * The Advertisement Attribute that belong to the Attribute.
     */
    public function advertisement()
    {
        return $this->hasOne(\App\Models\Advertisement::class, 'id','advertisement_id');
    }
    /**
     * The Advertisement Attribute that belong to the Attribute.
     */
    public function sender()
    {
        return $this->hasOne(\App\Models\User::class, 'id','sender_id');
    }
    /**
     * The Advertisement Attribute that belong to the Attribute.
     */
    public function receiver()
    {
        return $this->hasOne(\App\Models\User::class, 'id','receiver_id');
    }
}
