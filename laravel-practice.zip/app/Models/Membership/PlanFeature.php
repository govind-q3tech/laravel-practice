<?php

namespace App\Models\Membership;

use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class PlanFeature extends Model
{
		use Sortable; // Attach the Sortable trait to the model

    protected $fillable = ["plan_id","feature_id","value","description","status"];
    protected $sortable = ["plan_id","feature_id","value","description","status","created_at","updated_at"];

    protected $with = ['feature'];

    /**
     * Get the all plan features.
     */
    public function feature()
    {
      return $this->belongsTo(\App\Models\Membership\Feature::class);
    }
}
