<?php

namespace App\Models\Membership;

use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;
use Cviebrock\EloquentSluggable\Sluggable;

class Plan extends Model
{
  use Sortable; // Attach the Sortable trait to the model
  use Sluggable; // Attach the Sluggable trait to the model

  protected $fillable = ['title', 'description', 'live_plan_id', 'title', 'ordering', 'project_allowed', 'stripe_plan_id', 'stripe_plan_response', "trial_days", 'status', 'product_id', "slug", "plan_icon", "plan_sorting", "description","voucher_id","voucher_text"];

  public $sortable = ['id', 'title', 'status', 'created_at', 'updated_at'];

  /**
   * Return the sluggable configuration array for this model.
   *
   * @return array
   */
  public function sluggable()
  {
    return [
      'slug' => [
        'source' => 'title',
        'unique' => true,
        'separator' => '-',
        'onUpdate' => true,
      ]
    ];
  }

  /**
   * Scope a query to include active only.
   *
   * @param \Illuminate\Database\Eloquent\Builder $query
   * @return \Illuminate\Database\Eloquent\Builder
   */
  public function scopeActive($query)
  {
    $query->where('status', 1);
    return $query;
  }

  /**
   * Scope a query to according to status.
   *
   * @param \Illuminate\Database\Eloquent\Builder $query
   * @return \Illuminate\Database\Eloquent\Builder
   */
  public function scopeStatus($query, $status = null)
  {
    if ($status === 0 || $status == 1) {
      $query->where('status', $status);
    }
    return $query;
  }

  /**
   * Scope a query to filter by keyword.
   *
   * @param \Illuminate\Database\Eloquent\Builder $query
   * @return \Illuminate\Database\Eloquent\Builder
   */
  public function scopeFilter($query, $keyword)
  {
    if (!empty($keyword)) {
      $query->where(function ($query) use ($keyword) {
        $query->where('title', 'LIKE', '%' . $keyword . '%');
      });
    }
    return $query;
  }
  public function transactions()
  {
    return $this->belongsToMany(\App\Models\Membership\Transaction::class);
  }
  /**
   * Get the all plan features.
   */
  public function users()
  {
    return $this->hasMany(\Modules\UserManager\Entities\User::class);
  }

  /**
   * Get the all plan features.
   */
  public function plan_feature($feature_id = null)
  {
    return $this->hasMany(\App\Models\Membership\PlanFeature::class)->where("feature_id", $feature_id)->first();
  }

  /**
   * Get the all plan features.
   */
  public function plan_features()
  {
    return $this->hasMany(\App\Models\Membership\PlanFeature::class);
  }

   /**
   * Get the all plan features.
   */
  public function plan_categories_price($category_id = null)
  {
    
    return $this->hasMany(\App\Models\CategoryPlan::class)->where("business_category_id", $category_id)->first();
  }
  /**
   * Get the all plan features.
   */
  // public function plan_business_categories()
  // {
  //   return $this->hasMany(\App\Models\CategoryPlan::class);
  // }

  /**
   * Get the all plan sync details.
   */
  public function plan_sync()
  {
    return $this->morphOne(\App\Models\Membership\PlanSync::class, 'plansyncable');
  }

  /**
   * Get the only stripe product detail from plan sync.
   */
  public function plan_stripe_product()
  {
    return $this->morphOne(\App\Models\Membership\PlanSync::class, 'plansyncable')->where('plan_action', 1);
  }

  /**
   * Get the only stripe plan detail from plan sync.
   */
  public function plan_stripe_plan()
  {
    return $this->morphOne(\App\Models\Membership\PlanSync::class, 'plansyncable')->where('plan_action', 2);
  }

  /**
   * Get the only paypal product detail from plan sync.
   */
  public function plan_paypal_product()
  {
    return $this->morphOne(\App\Models\Membership\PlanSync::class, 'plansyncable')->where('plan_action', 3);
  }

  /**
   * Get the only paypal plan detail from plan sync.
   */
  public function plan_paypal_plan()
  {
    return $this->morphOne(\App\Models\Membership\PlanSync::class, 'plansyncable')->where('plan_action', 4);
  }

  public function business_category_plan(){
    return $this->belongsToMany(\App\Models\BusinessCategory::class,'business_category_plan')->withPivot('monthly_price', 'quaterly_price','half_yearly_price','business_category_id','special_monthly_price','special_quaterly_price','special_half_yearly_price');
  }

  public function PlanFeature(){
		return $this->belongsToMany(\App\Models\Membership\Feature::class,'plan_features')->withPivot('feature_id', 'plan_id','value','description');
	  }
}
