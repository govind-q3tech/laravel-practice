<?php

namespace App\Models\Membership;

use Illuminate\Database\Eloquent\Model;

class Feature extends Model
{
    protected $fillable = [];

    /**
      * Scope a query to according to status.
      *
      * @param \Illuminate\Database\Eloquent\Builder $query
      * @return \Illuminate\Database\Eloquent\Builder
		*/
   	public function scopeStatus($query, $status = null)
   	{
     	if ($status === 0 || $status == 1) {
       	$query->where('status', $status);
     	}
     	return $query;
   	}


	   

	   public function PlanFeature(){
		return $this->belongsToMany(\App\Models\Membership\Plan::class,'plan_features')->withPivot('feature_id', 'plan_id','value','description');
	  }
	  
}
