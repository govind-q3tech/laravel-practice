<?php

namespace App\Models\Membership;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    protected $fillable = [];

    public function user(){
		return $this->belongsTo(\App\Models\User::class,'user_id','id');
	  }
      public function package(){
		return $this->belongsTo(\App\Models\Membership\Plan::class,'package_id','id');
	  }
}
