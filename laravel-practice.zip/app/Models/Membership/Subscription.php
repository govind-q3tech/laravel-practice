<?php

namespace App\Models\Membership;

use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class Subscription extends Model
{
    use Sortable;
    protected $fillable = ["user_id", "plan_id", "type", "subscription_id", "plan_type", "amount", "category_id", "subscription_response", "start_date", "end_date", "status", "cancelled_at", "created_at", "updated_at"];

    protected $dates = ['start_date', 'end_date', 'cancelled_at'];

    /**
     * Get the users associated with the subscription.
     */
    public function users()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id', 'id');
    }

    /**
     * Get the plans associated with the subscription.
     */
    public function plans()
    {
        return $this->belongsTo(\App\Models\Membership\Plan::class, 'plan_id', 'id');
    }
    public function hotDeal()
    {
        return $this->belongsTo(\Modules\HotDealManager\Entities\Hotdeal::class, 'subscription_id', 'subscription_id');
    }
    public function business_category()
    {
        return $this->belongsTo(\App\Models\BusinessCategory::class, 'category_id', 'id');
    }

    public function restaurantOfTheDay()
    {
        return $this->belongsTo(\Modules\RestaurantManager\Entities\RestaurantOfTheDay::class, 'subscription_id', 'subscription_id');
    }

    public function scopeFilter($query, $keyword)
    {
        if (!empty($keyword)) {
            $query->where(function ($query) use ($keyword) {

                $query->Where('subscription_id', 'LIKE', '%' . $keyword . '%');
            });
            $query->orWhereHas('users', function ($query) use ($keyword) {
                $query->where('first_name', 'LIKE', '%' . $keyword . '%');
                $query->orWhere('first_name', 'LIKE', '%' . $keyword . '%');
                $query->orWhere('email', 'LIKE', '%' . $keyword . '%');
            });
            $query->orWhereHas('plans', function ($query) use ($keyword) {
                $query->where('amount', 'LIKE', '%' . $keyword . '%');
                $query->orwhere('title', 'LIKE', '%' . $keyword . '%');
            });
        }
        return $query;
    }

    public function scopeStatus($query, $status = null)
    {
        if ($status === 0 || $status == 1) {
            $query->where('status', $status);
        }
        return $query;
    }
}
