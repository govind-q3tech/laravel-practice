<?php

namespace App\Models\Membership;

use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class Transaction extends Model
{
    use Sortable;

    protected $fillable = ["user_id", "amount", "transaction_id", "transaction_response", "type", "status", "transction_type", "created_at", "updated_at"];

    public $sortable = ['user_id', 'amount', 'transaction_id', 'status', 'created_at', 'updated_at'];

    public function user()
    {
        return $this->belongsTo(\Modules\UserManager\Entities\User::class);
    }


    /**
     * Scope a query to only include filtered users.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeFilter($query, $keyword)
    {
        if (!empty($keyword)) {
            $query->where(function ($query) use ($keyword) {
                $query->where('amount', 'LIKE', '%' . $keyword . '%');
                $query->orWhere('transaction_id', 'LIKE', '%' . $keyword . '%');
            });
            $query->orWhereHas('user', function ($query) use ($keyword) {
                $query->where('first_name', 'LIKE', '%' . $keyword . '%');
                $query->orWhere('first_name', 'LIKE', '%' . $keyword . '%');
                $query->orWhere('email', 'LIKE', '%' . $keyword . '%');
            });
        }
        return $query;
    }
    /**
     * Get the booking time associated with the orderdetails.
     */
  /*
     public function orders()
    {
        return $this->belongsToMany(\Modules\OrderManager\Entities\Order::class);
    }

    public function hotDeals()
    {
        return $this->belongsToMany(\Modules\HotDealManager\Entities\HotDeal::class);
    }
    public function restaurantOfTheDays()
    {
        return $this->belongsToMany(\Modules\RestaurantManager\Entities\RestaurantOfTheDay::class);
    }
    public function restaurantBookings()
    {
        return $this->belongsToMany(\Modules\RestaurantManager\Entities\RestaurantBooking::class);
    }
*/
    public function plans()
    {
        return $this->belongsToMany(\App\Models\Membership\Plan::class);
    }

    /**
     * Scope a query to only include active users.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeStatus($query, $status = null)
    {
        if ($status === 0 || $status == 1) {
            $query->where('status', $status);
        }
        return $query;
    }
}
