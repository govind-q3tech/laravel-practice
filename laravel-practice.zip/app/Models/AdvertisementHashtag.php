<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AdvertisementHashtag extends Model
{
    use HasFactory;
    protected $fillable = ['hashtag_id'];

    public function getHashtags()
    {
        return $this->belongsTo('App\Models\HashTag','hashtag_id');
    }
}
