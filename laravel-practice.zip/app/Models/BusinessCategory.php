<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Kyslik\ColumnSortable\Sortable;

class BusinessCategory extends Model
{
    use HasFactory, Sluggable, Sortable;
    protected $fillable = ["title", "slug", "description", "status", "color", "meta_title", "meta_keyword", "meta_description", "parent_id", "icon", "priority", 'wp_cat_id', 'wp_parent_id'];

    public $sortable = ["title",  "slug", 'status', 'created_at', 'updated_at'];

    protected $appends = [
        'parents'
    ];
    /* Joining come here */

    /* End of Joining */

    /* SLUG Works come here */
    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'custom_slug',
                'unique' => true,
                'separator' => '-',
                'onUpdate' => true,
            ]
        ];
    }

    public function parent()
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function getParentsAttribute()
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function children()
    {
        return $this->hasMany(self::class, 'parent_id', 'id');
    }

    public function main_advertisements()
    {
        return $this->hasMany(\App\Models\Advertisement::class, 'business_category_id');
    }

    public function subscription()
    {
        return $this->hasMany(\App\Models\Subscription::class, 'category_id');
    }

    public function advertisements()
    {
        return $this->hasMany(\App\Models\Advertisement::class, 'sub_business_category_id');
    }

    public function attributs()
    {
        return $this->belongsToMany(\App\Models\Attribute::class, 'attribute_business_category', 'category_id', 'attribute_id');
    }

    public function businessCategoryPlan()
    {
        return $this->belongsToMany(\App\Models\BusinessCategory::class, 'business_category_plan')->withPivot('monthly_price', 'quaterly_price', 'half_yearly_price', 'business_category_id');
    }

    // recursive, loads all descendants
    public function childrenRecursive()
    {
        return $this->children()->with('childrenRecursive');
    }

    public function plan()
    {
        return $this->belongsToMany(\App\Models\Membership\Plan::class);
    }

    public function isParent()
    {
        return !$this->category_id ? true : false; // if category_id is null => is a Parent Category
    }
    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function getCustomSlugAttribute()
    {
        if (empty($this->slug)) {
            return strtoupper(trim($this->title));
        } else {
            return strtoupper(trim($this->slug));
        }
    }

    /* End of slug */


    public function scopeFilter($query, $keyword)
    {
        if (!empty($keyword)) {
            $query->where(function ($query) use ($keyword) {
                $query->where('title', 'LIKE', '%' . $keyword . '%');
            });
        }
        return $query;
    }


    public function scopeStatus($query, $status = 1)
    {
        $query->where(function ($query) use ($status) {
            $query->where('status', $status);
        });
        return $query;
    }


    /**
     * The slug filter used for filter the result on the basis of slug.
     *
     * @return query object
     */
    public function scopeSlug($query, $slug)
    {
        if (!empty($slug)) {
            $query->where(function ($query) use ($slug) {
                $query->where('slug',  $slug);
            });
        }
        return $query;
    }
}
