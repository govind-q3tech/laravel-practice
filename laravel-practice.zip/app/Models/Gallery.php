<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Kyslik\ColumnSortable\Sortable;

class Gallery extends Model
{
    use HasFactory, Sluggable, Sortable;

    protected $table = 'gallaries';

    protected $fillable = ["title","slug", "status",'image_link'];

    /*joing come here */

    public function images()
    {
        return $this->hasMany('\App\Models\GalleryImage', 'gallery_id', 'id');
    }

    public function scopeFilter($query, $keyword)
    {
        if (!empty($keyword)) {
            $query->where(function ($query) use ($keyword) {
                $query->where('name', 'LIKE', '%' . $keyword . '%');
            });
        }
        return $query;
    }

    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'title',
                'unique' => true,
                'separator' => '-',
                'onUpdate' => true,
            ]
        ];
    }

    /**
   * Scope a query to include active only.
   *
   * @param \Illuminate\Database\Eloquent\Builder $query
   * @return \Illuminate\Database\Eloquent\Builder
   */
    public function scopeActive($query)
    {
        $query->where('status', 1);
        return $query;
    }

}
