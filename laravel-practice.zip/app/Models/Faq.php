<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class Faq extends Model
{
    use HasFactory,  Sortable; 
    protected $fillable = ["question","answer","ordering","status"];

    public $sortable = [ "ordering", 'status', 'created_at', 'updated_at'];    


    public function scopeFilter($query, $keyword) {
        if (!empty($keyword)) {
            $query->where(function($query) use ($keyword) {
                $query->where('question', 'LIKE', '%' . $keyword . '%');
            });
        }
        return $query;
    }


    public function scopeStatus($query, $status = 1) {
        if (!empty($keyword)) {
            $query->where(function($query) use ($status) {
                $query->where('status', $status);
            });
        }
        return $query;
    }

    public function ScopeFaqs($query){

        return $query->where('status',1)->orderBy('ordering','Asc');
    }



    
}