<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class Metatag extends Model
{
    use HasFactory, Sortable;

    protected $fillable = ["location_id", "category_id", "cat_loc", "meta_title", "meta_keyword", "meta_description", "subtitle", "description"];

    public $sortable = ["title",  "slug", 'status', 'created_at', 'updated_at'];

    public function location()
    {
        return $this->belongsTo(\App\Models\Location::class);
    }

    public function category()
    {
        return $this->belongsTo(\App\Models\Category::class);
    }

         /**
     * Get the only lender detail from existing crm.
     * Nee to delete after remove from all places and use xero_contact instead of this method
     */
    public function data_metatag()
    {
        return $this->morphOne(\App\Models\DataSync::class, 'datasyncable')->where('table_type', 7);
    }


    public function scopeFilter($query, $queryString)
    {
        if (!empty($queryString)) {
            $query->where(function ($query) use ($queryString) {
                if(isset($queryString['location_id']))
                $query->where('location_id',$queryString['location_id']);                
                if(isset($queryString['category_id']))
                $query->where('category_id',$queryString['category_id']);
            });
        }
        return $query;
    }

}