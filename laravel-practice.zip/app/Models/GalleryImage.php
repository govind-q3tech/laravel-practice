<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\ServiceManager\Entities\Service;
use Kyslik\ColumnSortable\Sortable;

class GalleryImage extends Model
{
    use HasFactory, Sortable;
    protected $fillable = ["title", "gallery_id", "image", "image_name"];




    /**
     * The gallery that belong to the houses.
     */
    public function gallery()
    {
        return $this->belongsTo(App\Models\Gallery::class);
    }

    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */

    public function scopeFilter($query, $keyword, $service_id = null)
    {
        if (!empty($keyword)) {
            $query->where(function ($query) use ($keyword) {
                $query->where('title', 'LIKE', '%' . $keyword . '%');
            });
        }
        return $query;
    }
}
