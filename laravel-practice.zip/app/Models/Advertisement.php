<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Kyslik\ColumnSortable\Sortable;
use App\Models\UserWishlist;


class Advertisement extends Model
{
    use HasFactory;
    use Sortable;
    use Sluggable;

    protected $fillable = ["user_id", "title", "slug", "description", "short_description", "lat", "lng", "location_id", "area_id", "city_id", "business_category_id", "sub_business_category_id", "price_type", "fixed_price", "min_price", "max_price", "hashtag", "status", "admin_approve", "is_publish", "show_at_home", "sponsored", 'sort_order', 'wp_post_id'];

    /**
     * The sortable used for column sort.
     *
     * @var array
     */
    public $sortable = ["id","title", "user_id", "slug", "description", "admin_approve", 'created_at', 'updated_at','fixed_price'];
   // public $sortable = ["title", "user_id", "slug", "description", "admin_approve", 'created_at', 'updated_at',"fixed_price", "min_price", "max_price"];

    protected $appends = ['advertisment_url'];


    /* SLUG Works come here */
    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'custom_slug',
                'unique' => true,
                'separator' => '-',
                'onUpdate' => true,
            ]
        ];
    }

    /*joing come here */
    // this is a recommended way to declare event handlers
    public static function boot()
    {
        parent::boot();

        static::deleting(function ($advertisement) { // before delete() method call this
            $advertisement->advertisement_images()->delete();
            $advertisement->advertisement_hashtags()->delete();
            $advertisement->advertisement_attributes()->delete();
            $advertisement->user_reviews()->delete();
            // do the rest of the cleanup...
        });
    }

    //  public function getIswishlistedAttribute()
    // {  
     
    //     $user_wishlist = UserWishlist::where(['advertisement_id' => $this->id, 'user_id' => $this->user_id])->count();
    //     if ($user_wishlist > 0) {
    //      return 1;
    //     } else {
    //         return 0;
    //     }

    // }

       public function getAdvertismentURLAttribute(){  
        if(!empty($this->slug)){
         $url = url('/').'/advertisement/'.$this->slug;
         // $url ="https://gitau.24livehost.com/advertisement/test-5";
        }else{
            $url = '';
        }
      
        return $url;

    }


    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }

    public function sellerDetail()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }

    public function location()
    {
        return $this->belongsTo(\App\Models\Location::class, 'location_id', 'id');
    }

    public function area()
    {
        return $this->belongsTo(\App\Models\Area::class, 'area_id', 'id');
    }

    public function city()
    {
        return $this->belongsTo(\App\Models\City::class, 'city_id', 'id');
    }

    public function business_category()
    {
        return $this->belongsTo(\App\Models\BusinessCategory::class, 'business_category_id', 'id');
    }

    public function sub_business_category()
    {
        return $this->belongsTo(\App\Models\BusinessCategory::class, 'sub_business_category_id', 'id');
    }

    public function advertisement_images()
    {
        return $this->hasMany(\App\Models\AdvertisementImage::class, 'advertisement_id');
    }

    public function advertisement_hashtags()
    {
        return $this->hasMany(\App\Models\AdvertisementHashtag::class, 'advertisement_id');
    }

    public function advertisement_attributes()
    {
        return $this->hasMany(\App\Models\AdvertisementAttribute::class, 'advertisement_id');
    }




    public function user_reviews()
    {
        return $this->hasMany(\App\Models\UserReview::class, 'advertisement_id');
    }


    public function approveReview()
    {
        return $this->userreview()->where('admin_approve', '1');
    }

    public function user_wishlist()
    {
        return $this->hasMany(\App\Models\UserWishlist::class, 'advertisement_id');
    }


    /**
     * Get the only lender detail from existing crm.
     * Nee to delete after remove from all places and use xero_contact instead of this method
     */
    public function data_listing()
    {
        return $this->morphOne(\App\Models\DataSync::class, 'datasyncable')->where('table_type', 3);
    }

    public function avgRating()
    {
        return $this->approveReview()
            ->selectRaw('avg(rating) as aggregate, listing_id')
            ->groupBy('listing_id');
    }

    public function getAvgRatingAttribute()
    {
        if (!array_key_exists('avgRating', $this->relations)) {
            $this->load('avgRating');
        }

        $relation = $this->getRelation('avgRating')->first();

        return ($relation) ? $relation->aggregate : null;
    }

    /* end of joining */


    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function getCustomSlugAttribute()
    {
        if (empty($this->slug)) {
            return strtoupper(trim($this->title));
        } else {
            return strtoupper(trim($this->slug));
        }
    }

    /* End of slug */

    /**
     * The scope filter used for filter the result on the basis of search keyword.
     *
     * @return query object
     */
    public function scopeFilter($query, $keyword)
    {
        if (!empty($keyword)) {
            $query->where('status',  $keyword);
            // $query->where(function ($query) use ($keyword) {

            // if($keyword == 1)

            // if($keyword == 2)
            // $query->where('admin_approve',  '1');

            // if($keyword == 3)
            // $query->whereIn('admin_approve',  ['2','0']);
            // // $query->where('status',  '1');

            // if($keyword == 4)
            // $query->where('status',  '0');
            // });
        }
        return $query;
    }


    /**
     * The slug filter used for filter the result on the basis of slug.
     *
     * @return query object
     */
    public function scopeSlug($query, $slug)
    {
        if (!empty($slug)) {
            $query->where(function ($query) use ($slug) {
                $query->where('slug',  $slug);
            });
        }
        return $query;
    }

    public function scopeStatus($query, $status = null)
    {
        $query->where(function ($query) use ($status) {
            $query->where('status', $status);
        });
        return $query;
    }

    public function scopeFeature($query)
    {

        $query->where(function ($query) {
            $query->where('is_featured', 1);
        });
        return $query;
    }

    public function scopeIsUser($query)
    {

        $query->where(function ($query) {
            $query->where('user_id', \Auth::user()->id);
        });
        return $query;
    }

    public function scopeSorting($query, $sorting)
    {
        if ($sorting == 'old') {
            $query->orderBy('id',  'ASC');
        } elseif ($sorting == 'min_price') {
            $query->orderBy('fixed_price',  'ASC');
        } elseif ($sorting == 'max_price') {
            $query->orderBy('fixed_price',  'DESC');
        } else {
            $query->orderBy('id',  'DESC');
        }
        return $query;
    }

    public function scopeCategory($query, $category_id)
    {

        $query->where(function ($query) use ($category_id) {
            $query->where('sub_business_category_id', $category_id)
                ->orWhere('business_category_id', $category_id);
        });
        return $query;
    }

    public function scopeFrontFilter($adsQuery, $requestKeyword)
    {

        /*Keyword Filter*/
        if (isset($requestKeyword->keyword)) {
            $search = $requestKeyword->keyword;
            $adsQuery->orWhere('title', 'like', '%' . $search . '%')->orWhere('description', 'like', '%' . $search . '%');
        }

        /*Price Filter*/
        if (isset($requestKeyword->price)) {
            $rPrice = $requestKeyword->price;
            $bothPrice = explode('-', $rPrice);
            if (count($bothPrice) == 2) {
                $minprice = $bothPrice[0];
                $maxprice = $bothPrice[1];
                $adsQuery->where('fixed_price', '>=', $minprice);
                $adsQuery->where('fixed_price', '<=', $maxprice);
            } else {
                if ($requestKeyword->price == 'more') {
                    $adsQuery->where('fixed_price', '>=', 20000);
                } elseif ($requestKeyword->price == '500') {
                    $adsQuery->where('fixed_price', '<', $requestKeyword->price);
                }
            }
        }

        /*Location filter*/
        if (isset($requestKeyword->location)) {
            if ($requestKeyword->l_all == 'allcity') {
                $adsQuery->where('city_id', $requestKeyword->location);
            } elseif ($requestKeyword->l_all == 'allarea') {
                $adsQuery->Where('area_id', $requestKeyword->location);
            } else {
                $adsQuery->Where('location_id', $requestKeyword->location);
            }
        }

        /* Filter use in mobile */
        if (isset($requestKeyword->area)) {
            $adsQuery->where('area_id', $requestKeyword->area);
        }
        if (isset($requestKeyword->city)) {
            $adsQuery->Where('city_id', $requestKeyword->city);
        }
        /* Filter use in mobile */

        /*Sorting*/
        if (isset($requestKeyword->sortby)) {
            if ($requestKeyword->sortby == 'old') {
                $adsQuery->orderBy('created_at', 'ASC');
            } elseif ($requestKeyword->sortby == 'min_price') {
                $adsQuery->orderBy('fixed_price', 'ASC');
            } elseif ($requestKeyword->sortby == 'max_price') {
                $adsQuery->orderBy('fixed_price', 'DESC');
            } else {
                $adsQuery->orderBy('created_at', 'DESC');
            }
        } else {
            $adsQuery->orderBy('created_at', 'DESC');
        }
        return $adsQuery;
    }
}
