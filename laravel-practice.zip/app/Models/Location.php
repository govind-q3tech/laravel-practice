<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Kyslik\ColumnSortable\Sortable;

class Location extends Model
{
    use HasFactory, Sluggable, Sortable;
    protected $fillable = ["title", "area_id", "slug", "description", "lat", "lng", "status", "meta_title", "meta_keyword", "meta_description", "postcode", "type", "country_id"];

    public $sortable = ["title",  "slug", 'status', 'created_at', 'updated_at'];

    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'title',
                'unique' => true,
                'separator' => '-',
                'onUpdate' => true,
            ]
        ];
    }


    /* Joining come here */

    public function area()
    {
        return $this->belongsTo(\App\Models\Area::class, 'area_id', 'id');
    }

    public function advertisements()
    {
        return $this->hasMany(\App\Models\Advertisement::class, 'location_id');
    }



    /**
     * Get the only lender detail from existing crm.
     * Nee to delete after remove from all places and use xero_contact instead of this method
     */
    public function data_location()
    {
        return $this->morphOne(\App\Models\DataSync::class, 'datasyncable')->where('table_type', 7);
    }



    /* End of Joining */

    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function getCustomSlugAttribute()
    {
        if (empty($this->slug)) {
            return strtoupper(trim($this->title));
        } else {
            return strtoupper(trim($this->slug));
        }
    }

    /* End of slug */


    public function scopeFilter($query, $keyword)
    {
        if (!empty($keyword)) {
            $query->where(function ($query) use ($keyword) {
                $query->where('title', 'LIKE', '%' . $keyword . '%');
            });
        }
        return $query;
    }


    public function scopeStatus($query, $status = 1)
    {

        $query->where(function ($query) use ($status) {
            $query->where('status', $status);
        });
        return $query;
    }
}
