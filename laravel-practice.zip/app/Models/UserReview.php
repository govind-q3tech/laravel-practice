<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class UserReview extends Model
{
    use HasFactory, Sortable;

    protected $fillable = ['advertisement_id','user_id','email','rating','title','review','status','admin_approve', 'reply' ];

    public function advertisement()
    {
        return $this->belongsTo(\App\Models\Advertisement::class, 'advertisement_id');
    }    

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }
    public function user_is_approve()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id')->where('is_approved',1);
    }

     /**
   * Scope a query to include active only.
   *
   * @param \Illuminate\Database\Eloquent\Builder $query
   * @return \Illuminate\Database\Eloquent\Builder
   */
    public function scopeActive($query)
    {
        $query->where('status', 1);
       return $query;
    }
}