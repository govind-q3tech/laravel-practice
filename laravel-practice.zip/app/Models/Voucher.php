<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Kyslik\ColumnSortable\Sortable;

class Voucher extends Model
{
    use HasFactory, Sortable;
    protected $fillable = ["title", "vouchercode", "type", "value", "from_date", "to_date", "status", "max_users"];

    public $sortable = ["title",  "vouchercode", 'status', 'created_at', 'updated_at'];








    /* End of Joining */






    /* SLUG Works come here */
    public function sluggable()
    {
        return [
            'slug' => [
                'source' => 'custom_slug',
                'unique' => true,
                'separator' => '-',
                'onUpdate' => true,
            ]
        ];
    }




    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function getCustomSlugAttribute()
    {
        if (empty($this->slug)) {
            return strtoupper(trim($this->title));
        } else {
            return strtoupper(trim($this->slug));
        }
    }

    /* End of slug */


    public function scopeFilter($query, $keyword)
    {
        if (!empty($keyword)) {
            $query->where(function ($query) use ($keyword) {
                $query->where('title', 'LIKE', '%' . $keyword . '%');
            });
        }
        return $query;
    }


    public function scopeStatus($query, $status = 1)
    {
        if (!empty($keyword)) {
            $query->where(function ($query) use ($status) {
                $query->where('status', $status);
            });
        }
        return $query;
    }


}
