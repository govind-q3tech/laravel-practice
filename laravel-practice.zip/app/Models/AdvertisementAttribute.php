<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\ServiceManager\Entities\Service;

class AdvertisementAttribute extends Model
{

    protected $fillable = ["advertisement_id", "attribute_id", "value"];

    /**
     * The Advertisement Attribute that belong to the Advertisements.
     */
    public function advertisement()
    {
        return $this->belongsTo(\App\Models\Advertisement::class, 'advertisement_id');
    }

    /**
     * The Advertisement Attribute that belong to the Attribute.
     */
    public function attribute()
    {
        return $this->belongsTo(\App\Models\Attribute::class, 'attribute_id');
    }

   
}
