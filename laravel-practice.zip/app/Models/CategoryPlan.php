<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CategoryPlan extends Model
{
    use HasFactory;
    protected $table='business_category_plan';

    protected $fillable = ["plan_id", "business_category_id", "half_yearly_price","monthly_price","quaterly_price",'special_monthly_price','special_quaterly_price','special_half_yearly_price'];

    public function business_category()
    {
        return $this->belongsTo(\App\Models\BusinessCategory::class);
    }

    public function Plan(){
        return $this->belongsTo(\App\Models\Membership\Plan::class, 'plan_id', 'id');
    }
}
