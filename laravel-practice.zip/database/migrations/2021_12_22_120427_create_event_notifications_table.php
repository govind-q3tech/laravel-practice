<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEventNotificationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('event_notifications', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('sender_id');
            $table->enum('sender_type',['U','A'])->comment('A:Admin, U:User');
            $table->unsignedInteger('receiver_id');
            $table->enum('receiver_type',['U','A'])->comment('A:Admin, U:User');
            $table->enum('events',['A','B','C','D'])->comment('A: When admin approved Advert posts, B:When visitors submit their review on Advert posts, C:When Advertiser/user recevies a new message.,D:When Subscribtion is about to expire.');
            $table->boolean('is_read')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('event_notifications');
    }
}
