<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddSocialLinksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('listings', function (Blueprint $table) {
            $table->string('facebook')->nullable()->after('phone');
            $table->string('twitter')->nullable()->after('phone');        
            $table->string('instagram')->nullable()->after('phone');        
        
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('listings', function (Blueprint $table) {
            $table->dropColumn('facebook');
            $table->dropColumn('twitter');  
            $table->dropColumn('instagram'); 
        });
    }
}
