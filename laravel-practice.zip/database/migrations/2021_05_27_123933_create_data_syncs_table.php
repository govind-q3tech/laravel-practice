<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDataSyncsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('data_syncs', function (Blueprint $table) {
            $table->id();
            $table->integer('table_type')->comment('1:users, 2:categories, 3: listings, 4: page, 5: contacts, 6: review');
            $table->smallInteger('data_status')->comment('1: updated on our crm, 0: need to re update');
            $table->string('response_id',200)->nullable()->comment('This is uniqeue id those returned fron twenty');
            $table->longText('response_data')->nullable();
            $table->mediumText('error')->nullable();
            $table->integer('retries')->nullable();
            $table->nullableMorphs('datasyncable');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('data_syncs');
    }
}
