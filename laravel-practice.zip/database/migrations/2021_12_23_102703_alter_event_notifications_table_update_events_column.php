<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterEventNotificationsTableUpdateEventsColumn extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::table('event_notifications', function (Blueprint $table) {
            $table->dropColumn('events');
        });
        Schema::table('event_notifications', function (Blueprint $table) {
            $table->enum('events',['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P'])->comment('A: When admin approved Advert posts, B:When visitors submit their review on Advert posts, C:When Advertiser/user recevies a new message.,D:When Subscribtion is about to expire.,E:Your ad is under review please wait for the next update.,F:You have a new ad for the reviewing.,G:Edit Advertisement.,H:Advertisement has been edited.,I:New Review Added.,J:Send message to advertiser to chat.,K:Advertisement accepted.,L:Advertisement declined.,M:Subscription expire notification.,N:Subscription plan expired,O:Subscription plan purchased,P:Subscription plan updated')->after('receiver_type');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('event_notifications', function (Blueprint $table) {
            //
        });
    }
}
