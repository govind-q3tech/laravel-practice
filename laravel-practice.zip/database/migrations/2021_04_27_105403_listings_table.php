<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ListingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('listings', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('title', 200);
            $table->string('slug', 200);
            $table->longText('description')->nullable();
            $table->string('location', 200);
            $table->string('lat', 200);
            $table->string('lng', 200);
            $table->string('email', 200);
            $table->string('phone', 200)->nullable();
            $table->string('website', 200);
            $table->string('image', 200);
            $table->string('tagline', 200)->nullable();
            $table->boolean('status')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('listings');
    }
}
