<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\BusinessCategory;
use App\Models\DataSync;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $table_type = 2;
        $categories = DB::connection('existingcrm')->table('category')->get(); 
        $inc = 0;
        foreach($categories as $category){
            $response_id = $category->category_id;
            $existClient = DataSync::where('response_id', $response_id)->where('table_type', $table_type)->with('datasyncable')->first();
            if(!$existClient){
                DB::beginTransaction();
                try {
                    $client = $existClient->datasyncable ?? new BusinessCategory;

                    $client->title = $category->category_name;
                    $client->slug = $category->category_slug;
                    $client->priority = $category->category_priority;
                    $client->icon = $category->category_icon;
                    //$client->connected_cat = '';
                    $client->description = $category->category_desc;
                    $client->status = 1;
                    $client->created_at = date('Y-m-d H:i:s');
                    $client->updated_at = date('Y-m-d H:i:s');
                    $client->save();

                                   
                    $ret = isset($client->data_category->retries) ? $client->data_category->retries : 0;
                    $morphy = $client->data_category ?: new DataSync;
                    $morphy->table_type = $table_type;
                    $morphy->data_status = 1;
                    $morphy->response_id = $response_id;
                    $morphy->response_data = json_encode($category);
                    $morphy->error = NULL;
                    $morphy->retries = $ret+1;
                    $client->data_category()->save($morphy);
                    DB::commit();
                    $inc++;
                } catch (\Illuminate\Database\QueryException $e) {
                    DB::rollBack();
                    DB::table('data_syncs')->insert(
                        ['table_type' => $table_type, 'data_status' => 0, 'response_id' => $response_id, 'response_data' => json_encode($category), 'error' => json_encode($e->getMessage())]
                    );
                    Log::channel('datasync-crons')->info("Client Error: ". $e->getMessage()."\n");
                }
                echo $inc. ": records\n";
            }
            
        }
    }
}
