<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\Listing;
use App\Models\Gallery;
use App\Models\DataSync;
use Illuminate\Support\Facades\Storage;

class ListingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */



    public function run1()
    {

        $table_type = 3;
        $listings = DB::connection('existingcrm')->table('listing')->get();
        // dd(storage_path() ); die;

        foreach ($listings as $index => $listing) {


            if ($listing->listing_images == '') {
                continue;
            }



            $url = "http://localhost:8084/classified/public/uploads/gallery/" . $listing->listing_id . "/" . $listing->listing_images;
              
            $data = $this->file_get_contents_curl($url);
            
            if(file_exists("public".  DIRECTORY_SEPARATOR ."uploads" . DIRECTORY_SEPARATOR . "gallery" . DIRECTORY_SEPARATOR . $listing->listing_id . DIRECTORY_SEPARATOR . $listing->listing_images) && $listing->listing_images != ''){
                file_put_contents(storage_path() . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'listing' . DIRECTORY_SEPARATOR . 'profile' . DIRECTORY_SEPARATOR . $listing->listing_images, $data);
            }
            

            $response_id = $listing->listing_id;
            $listingImages = DB::connection('existingcrm')->table('listing_images')->where('listing_id', $response_id)->get();
            foreach ($listingImages as $img) {
                $img->image_name;
                $url = "http://localhost:8084/classified/public/uploads/gallery/" . $listing->listing_id . "/" . $img->image_name;
                

                $data = $this->file_get_contents_curl($url);
                
                if(file_exists("public".  DIRECTORY_SEPARATOR ."uploads" . DIRECTORY_SEPARATOR . "gallery" . DIRECTORY_SEPARATOR . $listing->listing_id . DIRECTORY_SEPARATOR . $img->image_name) && $img->image_name != ''){
                    file_put_contents(storage_path() . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'listing' . DIRECTORY_SEPARATOR . 'gallery' . DIRECTORY_SEPARATOR . $img->image_name, $data);
                }
                
               
            }

        }
    }

    function file_get_contents_curl($url)
    {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $url);

        $data = curl_exec($ch);
        curl_close($ch);

        return $data;
    }

    public function run()
    {
        $table_type = 3;
        $listings = DB::connection('existingcrm')->table('listing')->get();
        $categoryController = \App\Models\BusinessCategory::with('data_category')->get()->pluck("id", 'data_category.response_id');
    //    dd($categoryController);
        $inc = 0;
        foreach ($listings as $listing) {
            if ($listing->listing_name == '') {
                continue;
            }
            $response_id = $listing->listing_id;
            $listingImages = DB::connection('existingcrm')->table('listing_images')->where('listing_id', $response_id)->get();
            $categoryListings = DB::connection('existingcrm')->table('listing_category')->where('listing_id', $response_id)->get();
            $dataCat = [];

            $existClient = DataSync::where('response_id', $response_id)->where('table_type', $table_type)->with('datasyncable')->first();
            if (!$existClient) {
            //    DB::beginTransaction();
                try {
                    $listingData = $existClient->datasyncable ?? new Listing;
                    $userController = \App\Models\User::with('data_user')->whereHas('data_user',  function ($q) use ($listing) {
                        $q->where('response_id', '=', $listing->register_id);
                    })->first();
                    if (!isset($userController->id)) {
                        echo "**\n" . $listing->register_id . "\n**";
                        continue;
                    }
                    //  dd($userController->id);
                    $listingData->user_id = $userController->id;
                    // $listingData->user_id = $listing->register_id;
                    $listingData->title = $listing->listing_name;
                    $listingData->slug = $listing->listing_slug;
                    $listingData->description = $listing->listing_desc;
                    $listingData->short_description = $listing->listing_name;
                    $listingData->location = $listing->listing_location;
                    $listingData->lat = $listing->location_latitude;
                    $listingData->lng = $listing->location_longitude;
                    $listingData->email = $listing->listing_email;
                    $listingData->phone = $listing->listing_phone;
                    $listingData->instagram = $listing->instagram_address;
                    $listingData->twitter = $listing->twitter_username;
                    $listingData->facebook = $listing->facebook_address;
                    $listingData->website = $listing->listing_website;
                    $listingData->image = $listing->listing_images;
                    $listingData->tagline = $listing->listing_tagline;
                    $listingData->status = 1;
                    $listingData->created_at = date('Y-m-d H:i:s');
                    $listingData->updated_at = date('Y-m-d H:i:s');
                    $listingData->save();

                    foreach ($listingImages as $img) {
                        $dataImg['images'] = $img->image_name;
                        $gallery =  new Gallery($dataImg);
                        $listingData->galleries()->save($gallery);
                    }

                    foreach ($categoryListings as $category) {
                        $dataCat[]['category_id'] = $categoryController[$category->category_id];
                    }

                    $listingData->categories()->sync($dataCat);



                    $ret = isset($listingData->data_listing->retries) ? $listingData->data_listing->retries : 0;
                    $morphy = $listingData->data_listing ?: new DataSync;
                    $morphy->table_type = $table_type;
                    $morphy->data_status = 1;
                    $morphy->response_id = $response_id;
                    $morphy->response_data = json_encode($listing);
                    $morphy->error = NULL;
                    $morphy->retries = $ret + 1;
                    $listingData->data_listing()->save($morphy);
              //      DB::commit();
                    $inc++;
                } catch (\Illuminate\Database\QueryException $e) {
               //     DB::rollBack();
                    DB::table('data_syncs')->insert(
                        ['table_type' => $table_type, 'data_status' => 0, 'response_id' => $response_id, 'response_data' => json_encode($listing), 'error' => json_encode($e->getMessage())]
                    );
                    dd($e->getMessage());
                    Log::channel('datasync-crons')->info("Client Error: " . $e->getMessage() . "\n");
                }
                echo $inc . ": records";
            }
        }
    }
}
