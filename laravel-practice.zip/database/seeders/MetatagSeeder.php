<?php

namespace Database\Seeders;

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\Location;
use App\Models\Category;
use App\Models\Metatag;

use App\Models\DataSync;

class MetatagSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $table_type = 8;
        $categories = DB::connection('existingcrm')->table('page')->orderBy('page_parent', 'ASC')->get(); 

        
        $inc = 0;
        $categoryArr = Category::pluck("id","slug");

        $parentCat = [];
        
        $locationArr = Location::pluck("id","slug");
        foreach($categories as $record){
            if(empty($record->page_parent) || $record->page_parent == 0){
                $parentCat[$record->page_id] = $record->page_slug;
                continue;
            }
           
            $response_id = $record->page_id ;
            $existClient = DataSync::where('response_id', $response_id)->where('table_type', $table_type)->with('datasyncable')->first();
            if(!$existClient){
              //  DB::beginTransaction();
                try {
                    
                    
                    if(!isset($parentCat[$record->page_parent])){
                        continue;
                    }
                    
                    if(!isset($categoryArr[$record->page_slug]) || !isset($locationArr[$parentCat[$record->page_parent]])){
                        continue;
                    }

                    $client = $existClient->datasyncable ?? new Metatag;
                    $client->location_id = $locationArr[$parentCat[$record->page_parent]];
                    $client->category_id = $categoryArr[$record->page_slug];
                    $client->cat_loc = $categoryArr[$record->page_slug].'_'.$locationArr[$parentCat[$record->page_parent]];
                    
                    $client->meta_title = $record->page_title;
                    $client->meta_keyword = $record->page_keyword;
                    //$client->connected_cat = '';
                    $client->meta_description = $record->page_content;
                    $client->subtitle = $record->page_subtitle;
                  //  $client->status = 1;
                    $client->created_at = date('Y-m-d H:i:s');
                    $client->updated_at = date('Y-m-d H:i:s');
                    $client->save();
                  //  dd($client);
                                   
                    $ret = isset($client->data_metatag->retries) ? $client->data_metatag->retries : 0;
                    $morphy = $client->data_metatag ?: new DataSync;
                    $morphy->table_type = $table_type;
                    $morphy->data_status = 1;
                    $morphy->response_id = $response_id;
                    $morphy->response_data = json_encode($record);
                    $morphy->error = NULL;
                    $morphy->retries = $ret+1;
                    $client->data_metatag()->save($morphy);
                    //DB::commit();
                    $inc++;
                } catch (\Illuminate\Database\QueryException $e) {
                   // DB::rollBack();
                    DB::table('data_syncs')->insert(
                        ['table_type' => $table_type, 'data_status' => 0, 'response_id' => $response_id, 'response_data' => json_encode($record), 'error' => json_encode($e->getMessage())]
                    );
                    echo  $e->getMessage()."\n";
                    Log::channel('datasync-crons')->info("Client Error: ". $e->getMessage()."\n");
                }
                echo $inc. ": records\n";
            }
            
        }

        dd( $parentCat);
    }
}
