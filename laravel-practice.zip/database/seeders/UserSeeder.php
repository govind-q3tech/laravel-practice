<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\DataSync;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $table_type = 1;
        $registrations = DB::connection('existingcrm')->table('registration')->get(); 
        $inc = 0;
        foreach($registrations as $oldClient){
            $existClient = DataSync::where('response_id', $oldClient->register_id)->where('table_type', $table_type)->with('datasyncable')->first();
            if(!$existClient){
                DB::beginTransaction();
                try {
                    $client = $existClient->datasyncable ?? new User;
                   
                    $client->name = $oldClient->register_firstname;
                    $client->last_name = $oldClient->register_lastname;
                    $client->email = $oldClient->register_email;;
                    $client->username = $oldClient->register_login;
                    $client->phone = $oldClient->register_phone;
                    $client->billing_address_1 = $oldClient->register_shipping_address1;
                    $client->billing_address_2 = $oldClient->register_shipping_address2;
                    $client->billing_town = $oldClient->register_shipping_town;
                    $client->billing_postcode = $oldClient->register_shipping_post;
                    $client->billing_country = $oldClient->register_shipping_country;
                    $client->email_verified_at = date("Y-m-d H:i:s");
                    $client->password = $oldClient->register_status;
                    $client->status = $oldClient->register_status;
                    $client->created_at = $oldClient->register_date;
                    $client->updated_at = $oldClient->register_date;
                    // $client->stripe_customer_id = $oldClient->register_date;
                    // $client->is_subscribed = $oldClient->register_date;
                    // $client->plan_id = $oldClient->register_date;
                    // $client->subscription_id = $oldClient->register_date;
                    $client->save();

                                   
                    $ret = isset($client->data_user->retries) ? $client->data_user->retries : 0;
                    $morphy = $client->data_user ?: new DataSync;
                    $morphy->table_type = $table_type;
                    $morphy->data_status = 1;
                    $morphy->response_id = $oldClient->register_id;
                    $morphy->response_data = json_encode($oldClient);
                    $morphy->error = NULL;
                    $morphy->retries = $ret+1;
                    $client->data_user()->save($morphy);
                    DB::commit();
                    $inc++;
                } catch (\Illuminate\Database\QueryException $e) {
                    DB::rollBack();
                    DB::table('data_syncs')->insert(
                        ['table_type' => $table_type, 'data_status' => 0, 'response_id' => $oldClient->register_id, 'response_data' => json_encode($oldClient), 'error' => json_encode($e->getMessage())]
                    );
                    Log::channel('datasync-crons')->info("Client Error: ". $e->getMessage()."\n");
                }
                echo $inc. ": records<br>";
            }
            
        }
    }
}
