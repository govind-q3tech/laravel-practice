<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\Location;
use App\Models\DataSync;

class LocationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $table_type = 7;
        $categories = DB::connection('existingcrm')->table('region')->get(); 
        $inc = 0;
        foreach($categories as $record){
            $response_id = $record->region_id;
            $existClient = DataSync::where('response_id', $response_id)->where('table_type', $table_type)->with('datasyncable')->first();
            if(!$existClient){
                DB::beginTransaction();
                try {
                    $client = $existClient->datasyncable ?? new Location;
                    $client->id = $record->region_id;
                    $client->title = $record->region_name;
                    $client->slug = $record->region_slug;
                    $client->parent_id = $record->region_parent;
                    //$client->connected_cat = '';
                    $client->description = $record->region_desc;
                    $client->status = 1;
                    $client->created_at = date('Y-m-d H:i:s');
                    $client->updated_at = date('Y-m-d H:i:s');
                    $client->save();

                                   
                    $ret = isset($client->data_location->retries) ? $client->data_location->retries : 0;
                    $morphy = $client->data_location ?: new DataSync;
                    $morphy->table_type = $table_type;
                    $morphy->data_status = 1;
                    $morphy->response_id = $response_id;
                    $morphy->response_data = json_encode($record);
                    $morphy->error = NULL;
                    $morphy->retries = $ret+1;
                    $client->data_location()->save($morphy);
                    DB::commit();
                    $inc++;
                } catch (\Illuminate\Database\QueryException $e) {
                    DB::rollBack();
                    DB::table('data_syncs')->insert(
                        ['table_type' => $table_type, 'data_status' => 0, 'response_id' => $response_id, 'response_data' => json_encode($record), 'error' => json_encode($e->getMessage())]
                    );
                    Log::channel('datasync-crons')->info("Client Error: ". $e->getMessage()."\n");
                }
                echo $inc. ": records\n";
            }
            
        }
    }
}
