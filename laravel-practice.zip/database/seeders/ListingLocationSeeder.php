<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ListingLocationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         $locationCategory = DB::connection('existingcrm')->table('listing_region')->join('region','region.region_id','=','listing_region.region_id')->get(); 
         

         foreach($locationCategory as $locCat){
            $listingController = \App\Models\Listing::with('data_listing')->whereHas('data_listing',  function ($q) use ($locCat) {
                $q->where('response_id', '=', $locCat->listing_id);
            })->first();
          //  echo "<pre>";
          //  print_r($listingController); die;
            if(!empty($listingController->id)){
                
                $location = \App\Models\Location::where("title","like","%".$locCat->region_name."%")->where("id", ">", "251")->first();
                $locationId = isset($location->id)?$location->id:$locCat->region_name;
               
                if(isset($location->id)){
                    echo $listingController->id."-".$listingController->data_listing->response_id."-".$locationId."\n";
                    DB::table("listing_location")->insert(["listing_id"=>$listingController->id, "location_id"=>$location->id]);
                }
            }else{

                continue ;
            }
            
         }
    }
}
